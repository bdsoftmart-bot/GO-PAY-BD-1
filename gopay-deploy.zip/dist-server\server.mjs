// server.ts
import fs3 from "fs";
import path4 from "path";
import express from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import helmet from "helmet";

// server/config/env.ts
import crypto from "crypto";
import path from "path";
import dotenv from "dotenv";
dotenv.config();
var isProd = process.env.NODE_ENV === "production";
var PLACEHOLDER_SECRET_RE = /replace_with|changeme|your_secret|your_long_random|example_secret|default_secret/i;
function resolveSessionSecret() {
  const raw = String(process.env.SESSION_SECRET || "").trim();
  if (isProd) {
    if (!raw || raw.length < 32 || PLACEHOLDER_SECRET_RE.test(raw)) {
      throw new Error(
        "[GO PAY BD] FATAL CONFIGURATION ERROR: A persistent, non-placeholder SESSION_SECRET (at least 32 characters) is required when NODE_ENV=production."
      );
    }
    return raw;
  }
  if (raw && raw.length >= 16) {
    return raw;
  }
  return crypto.randomBytes(32).toString("hex");
}
function buildAllowedOrigins() {
  const origins = /* @__PURE__ */ new Set();
  const candidates = [
    process.env.APP_URL || "",
    process.env.FRONTEND_URL || "",
    ...(process.env.ALLOWED_ORIGINS || "").split(",")
  ];
  for (const item of candidates) {
    const trimmed = item.trim();
    if (!trimmed) continue;
    try {
      const parsed = new URL(trimmed);
      if ((parsed.protocol === "http:" || parsed.protocol === "https:") && parsed.origin !== "null") {
        origins.add(parsed.origin);
      }
    } catch {
    }
  }
  return origins;
}
function resolveCookieSameSite() {
  const val = String(process.env.COOKIE_SAME_SITE || "lax").trim().toLowerCase();
  if (val === "strict" || val === "none" || val === "lax") {
    return val;
  }
  return "lax";
}
var sessionSecret = resolveSessionSecret();
var allowedOrigins = buildAllowedOrigins();
var env = {
  nodeEnv: process.env.NODE_ENV || "development",
  isProd,
  port: Math.max(1, Number(process.env.PORT) || 3e3),
  appUrl: (process.env.APP_URL || "").replace(/\/+$/, ""),
  frontendUrl: (process.env.FRONTEND_URL || process.env.APP_URL || "").replace(/\/+$/, ""),
  allowedOrigins,
  // MySQL Database
  dbHost: process.env.DB_HOST || "localhost",
  dbPort: Number(process.env.DB_PORT) || 3306,
  dbName: process.env.DB_NAME || "",
  dbUser: process.env.DB_USER || "",
  dbPassword: process.env.DB_PASSWORD || "",
  dbConfigured: Boolean(process.env.DB_NAME && process.env.DB_USER),
  // Sessions & Auth
  sessionSecret,
  sessionTtlDays: Math.max(1, Number(process.env.SESSION_TTL_DAYS) || 7),
  cookieSameSite: resolveCookieSameSite(),
  adminPassword: process.env.ADMIN_PASSWORD || "",
  // Uploads (always resolved outside src/)
  uploadDir: path.resolve(process.cwd(), process.env.UPLOAD_DIR || "uploads"),
  // Optional Google OAuth (strictly server-side secret)
  googleClientId: process.env.GOOGLE_CLIENT_ID || "",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
  googleCallbackUrl: process.env.GOOGLE_CALLBACK_URL || "",
  get googleOAuthConfigured() {
    return Boolean(this.googleClientId && this.googleClientSecret);
  },
  // Optional SMTP
  smtpHost: process.env.SMTP_HOST || "",
  smtpPort: Number(process.env.SMTP_PORT) || 587,
  smtpUser: process.env.SMTP_USER || "",
  smtpPass: process.env.SMTP_PASS || "",
  smtpFrom: process.env.SMTP_FROM || "no-reply@gopaybd.store"
};

// server/database/pool.ts
import fs from "fs";
import path2 from "path";
import mysql from "mysql2/promise";
var pool = null;
var dbReady = false;
var lastDbError = null;
var DatabaseUnavailableError = class extends Error {
  constructor(message = "Database service is currently unavailable. Please configure MySQL connection settings.") {
    super(message);
    this.status = 503;
    this.name = "DatabaseUnavailableError";
  }
};
function getPool() {
  if (!env.dbConfigured) {
    throw new DatabaseUnavailableError(
      "MySQL database is not configured yet. Please set DB_HOST, DB_NAME, DB_USER, and DB_PASSWORD in your environment."
    );
  }
  if (!pool) {
    pool = mysql.createPool({
      host: env.dbHost,
      port: env.dbPort,
      database: env.dbName,
      user: env.dbUser,
      password: env.dbPassword,
      waitForConnections: true,
      connectionLimit: 10,
      maxIdle: 5,
      idleTimeout: 6e4,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 1e4,
      multipleStatements: false,
      timezone: "Z",
      decimalNumbers: true
    });
  }
  return pool;
}
async function query(sql, params = []) {
  const p = getPool();
  try {
    const [rows] = await p.execute(sql, params);
    dbReady = true;
    lastDbError = null;
    return rows;
  } catch (err) {
    if (err?.code === "ECONNREFUSED" || err?.code === "ER_ACCESS_DENIED_ERROR" || err?.code === "ER_BAD_DB_ERROR") {
      dbReady = false;
      lastDbError = err.code;
      throw new DatabaseUnavailableError("Unable to reach MySQL database. Verify cPanel MySQL credentials and host.");
    }
    throw err;
  }
}
async function execute(sql, params = []) {
  const p = getPool();
  try {
    const [result] = await p.execute(sql, params);
    dbReady = true;
    lastDbError = null;
    return result;
  } catch (err) {
    if (err?.code === "ECONNREFUSED" || err?.code === "ER_ACCESS_DENIED_ERROR" || err?.code === "ER_BAD_DB_ERROR") {
      dbReady = false;
      lastDbError = err.code;
      throw new DatabaseUnavailableError("Unable to reach MySQL database. Verify cPanel MySQL credentials and host.");
    }
    throw err;
  }
}
async function withTransaction(fn) {
  const p = getPool();
  let conn;
  try {
    conn = await p.getConnection();
  } catch (err) {
    dbReady = false;
    lastDbError = err?.code || "CONN_ERROR";
    throw new DatabaseUnavailableError("Unable to open MySQL transaction connection.");
  }
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    dbReady = true;
    lastDbError = null;
    return result;
  } catch (err) {
    try {
      await conn.rollback();
    } catch {
    }
    throw err;
  } finally {
    conn.release();
  }
}
function splitSqlStatements(sqlContent) {
  const statements = [];
  let current = "";
  let inSingle = false;
  let inDouble = false;
  let inBacktick = false;
  let inLineComment = false;
  let inBlockComment = false;
  for (let i = 0; i < sqlContent.length; i++) {
    const ch = sqlContent[i];
    const next = sqlContent[i + 1] || "";
    if (inLineComment) {
      if (ch === "\n") {
        inLineComment = false;
        current += "\n";
      }
      continue;
    }
    if (inBlockComment) {
      if (ch === "*" && next === "/") {
        inBlockComment = false;
        i++;
      }
      continue;
    }
    if (!inSingle && !inDouble && !inBacktick) {
      if (ch === "-" && next === "-" && (sqlContent[i + 2] === " " || sqlContent[i + 2] === "	" || sqlContent[i + 2] === "\r" || sqlContent[i + 2] === "\n")) {
        inLineComment = true;
        i++;
        continue;
      }
      if (ch === "#") {
        inLineComment = true;
        continue;
      }
      if (ch === "/" && next === "*") {
        inBlockComment = true;
        i++;
        continue;
      }
    }
    if (ch === "\\" && (inSingle || inDouble)) {
      current += ch + next;
      i++;
      continue;
    }
    if (ch === "'" && !inDouble && !inBacktick) {
      if (inSingle && next === "'") {
        current += "''";
        i++;
        continue;
      }
      inSingle = !inSingle;
      current += ch;
      continue;
    }
    if (ch === '"' && !inSingle && !inBacktick) {
      inDouble = !inDouble;
      current += ch;
      continue;
    }
    if (ch === "`" && !inSingle && !inDouble) {
      inBacktick = !inBacktick;
      current += ch;
      continue;
    }
    if (ch === ";" && !inSingle && !inDouble && !inBacktick) {
      const trimmed = current.trim();
      if (trimmed.length > 0 && !/^SET\s+/i.test(trimmed)) {
        statements.push(trimmed);
      }
      current = "";
      continue;
    }
    current += ch;
  }
  const tail = current.trim();
  if (tail.length > 0 && !/^SET\s+/i.test(tail)) {
    statements.push(tail);
  }
  return statements;
}
async function ensureSchemaUpgrades(conn) {
  const columnAdditions = [
    {
      table: "users",
      column: "admin_note",
      ddl: "ALTER TABLE `users` ADD COLUMN `admin_note` TEXT NULL AFTER `notification_inapp`"
    },
    {
      table: "payment_settings",
      column: "withdrawal_enabled",
      ddl: "ALTER TABLE `payment_settings` ADD COLUMN `withdrawal_enabled` TINYINT(1) NOT NULL DEFAULT 1 AFTER `is_active`"
    },
    {
      table: "deposits",
      column: "processing_eta",
      ddl: "ALTER TABLE `deposits` ADD COLUMN `processing_eta` VARCHAR(120) NULL AFTER `admin_note`"
    },
    {
      table: "payment_methods",
      column: "notes",
      ddl: "ALTER TABLE `payment_methods` ADD COLUMN `notes` TEXT NULL AFTER `routing_number`"
    },
    {
      table: "payment_methods",
      column: "verification_status",
      ddl: "ALTER TABLE `payment_methods` ADD COLUMN `verification_status` VARCHAR(32) NOT NULL DEFAULT 'active' AFTER `is_default`"
    },
    {
      table: "payment_methods",
      column: "pin_hash",
      ddl: "ALTER TABLE `payment_methods` ADD COLUMN `pin_hash` VARCHAR(255) NULL AFTER `verification_status`"
    },
    {
      table: "withdrawals",
      column: "paid_amount_paisa",
      ddl: "ALTER TABLE `withdrawals` ADD COLUMN `paid_amount_paisa` BIGINT NULL AFTER `net_amount_paisa`"
    },
    {
      table: "withdrawals",
      column: "payment_date",
      ddl: "ALTER TABLE `withdrawals` ADD COLUMN `payment_date` DATE NULL AFTER `paid_at`"
    },
    {
      table: "invoices",
      column: "due_date",
      ddl: "ALTER TABLE `invoices` ADD COLUMN `due_date` DATE NULL AFTER `issued_at`"
    },
    {
      table: "invoices",
      column: "tax_paisa",
      ddl: "ALTER TABLE `invoices` ADD COLUMN `tax_paisa` BIGINT NOT NULL DEFAULT 0 AFTER `fee_paisa`"
    },
    {
      table: "invoices",
      column: "invoice_status",
      ddl: "ALTER TABLE `invoices` ADD COLUMN `invoice_status` ENUM('draft', 'issued', 'paid', 'void') NOT NULL DEFAULT 'paid' AFTER `payment_status`"
    },
    {
      table: "support_tickets",
      column: "internal_note",
      ddl: "ALTER TABLE `support_tickets` ADD COLUMN `internal_note` TEXT NULL AFTER `assigned_admin_id`"
    }
  ];
  for (const item of columnAdditions) {
    const [cols] = await conn.execute(
      `SELECT COUNT(*) AS cnt
       FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
      [item.table, item.column]
    );
    if (Number(cols[0]?.cnt || 0) === 0) {
      await conn.query(item.ddl);
    }
  }
  const [wdCols] = await conn.execute(
    `SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'withdrawals' AND COLUMN_NAME = 'status'`
  );
  if (wdCols.length && !String(wdCols[0].COLUMN_TYPE || "").includes("'processing'")) {
    await conn.query(
      "ALTER TABLE `withdrawals` MODIFY COLUMN `status` ENUM('pending', 'processing', 'approved', 'paid', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending'"
    );
  }
  const [stCols] = await conn.execute(
    `SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'support_tickets' AND COLUMN_NAME = 'status'`
  );
  if (stCols.length && !String(stCols[0].COLUMN_TYPE || "").includes("'answered'")) {
    await conn.query(
      "ALTER TABLE `support_tickets` MODIFY COLUMN `status` ENUM('open', 'in_progress', 'answered', 'resolved', 'closed') NOT NULL DEFAULT 'open'"
    );
  }
}
async function initializeDatabase() {
  if (!env.dbConfigured) {
    dbReady = false;
    lastDbError = "DB_NOT_CONFIGURED";
    console.warn("[DB] MySQL environment variables (DB_NAME / DB_USER) are not set. Running in standby mode until configured.");
    return { connected: false, error: "DB_NOT_CONFIGURED" };
  }
  try {
    const p = getPool();
    const conn = await p.getConnection();
    try {
      await conn.ping();
      const schemaPath = path2.resolve(process.cwd(), "database", "schema.sql");
      if (fs.existsSync(schemaPath)) {
        const schemaSql = fs.readFileSync(schemaPath, "utf8");
        for (const stmt of splitSqlStatements(schemaSql)) {
          await conn.query(stmt);
        }
      }
      await ensureSchemaUpgrades(conn);
      const seedPath = path2.resolve(process.cwd(), "database", "seed.sql");
      if (fs.existsSync(seedPath)) {
        const seedSql = fs.readFileSync(seedPath, "utf8");
        for (const stmt of splitSqlStatements(seedSql)) {
          await conn.query(stmt);
        }
      }
      await conn.execute("DELETE FROM sessions WHERE expires_at < UTC_TIMESTAMP()");
    } finally {
      conn.release();
    }
    dbReady = true;
    lastDbError = null;
    console.log(`[DB] Connected to MySQL (${env.dbHost}:${env.dbPort}/${env.dbName}) and verified schema.`);
    return { connected: true };
  } catch (err) {
    dbReady = false;
    lastDbError = err?.code || "CONNECTION_FAILED";
    console.error(`[DB] Startup connection failed (${lastDbError}). Check DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD.`);
    return { connected: false, error: lastDbError || void 0 };
  }
}
async function checkDatabaseHealth() {
  if (!env.dbConfigured) {
    return { connected: false, configured: false };
  }
  try {
    const p = getPool();
    await p.query("SELECT 1");
    dbReady = true;
    lastDbError = null;
    return { connected: true, configured: true };
  } catch {
    dbReady = false;
    return { connected: false, configured: true };
  }
}
async function closeDatabasePool() {
  if (pool) {
    try {
      await pool.end();
    } catch {
    }
    pool = null;
    dbReady = false;
  }
}

// server/middleware/auth.ts
import rateLimit from "express-rate-limit";

// server/utils/helpers.ts
import crypto2 from "crypto";
import bcrypt from "bcryptjs";
var BCRYPT_ROUNDS = 12;
var DEFAULT_SECURITY_DEPOSIT_1_BDT = 825;
var DEFAULT_SECURITY_DEPOSIT_2_BDT = 1825;
var DEFAULT_SECURITY_DEPOSIT_EXTRA_BDT = 1e3;
var DEFAULT_PUBLIC_SETTINGS = {
  site_name: "GO PAY BD",
  site_tagline: "Manage. Earn. Connect.",
  currency_code: "BDT",
  currency_symbol: "\u09F3",
  support_email: "support@gopaybd.com",
  support_phone: "+880 1700-000000",
  telegram_link: "https://t.me/gopaybd",
  whatsapp_link: "https://wa.me/8801700000000",
  facebook_link: "https://facebook.com/gopaybd",
  footer_text: "\xA9 2026 GO PAY BD. Verified Bangladesh Digital Wallet, Referral & Financial Ledger Platform.",
  announcement_banner: "Welcome to GO PAY BD \u2014 Instant wallet ledger, verified deposits & transparent referral commissions.",
  min_deposit: "100",
  max_deposit: "500000",
  min_withdrawal: "300",
  max_withdrawal: "200000",
  withdrawal_fee_type: "percentage",
  withdrawal_fee: "1.5",
  daily_withdrawal_limit: "100000",
  withdrawal_processing_time: "15\u201360 minutes during business hours",
  deposit_enabled: "true",
  withdrawal_enabled: "true",
  registration_enabled: "true",
  commission_type: "percentage",
  level_1_commission: "7",
  level_2_commission: "3",
  min_qualifying_order: "100",
  commission_cap: "50000",
  commission_approval_mode: "auto",
  referral_enabled: "true",
  commission_enabled: "true",
  maintenance_mode: "false",
  invoice_prefix: "GPBD-INV",
  security_deposit_enabled: "true",
  security_deposit_1_account: String(DEFAULT_SECURITY_DEPOSIT_1_BDT),
  security_deposit_2_accounts: String(DEFAULT_SECURITY_DEPOSIT_2_BDT),
  security_deposit_extra_account: String(DEFAULT_SECURITY_DEPOSIT_EXTRA_BDT)
};
function toPaisa(amount) {
  const num = typeof amount === "string" ? Number(amount.trim()) : amount;
  if (!Number.isFinite(num)) return 0;
  return Math.round(num * 100);
}
function fromPaisa(paisa) {
  const val = Number(paisa || 0);
  if (!Number.isFinite(val)) return 0;
  return Number((val / 100).toFixed(2));
}
function sanitizeText(value, maxLen = 500) {
  if (value === null || value === void 0) return "";
  return String(value).replace(/\0/g, "").trim().slice(0, maxLen);
}
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
}
function isValidBdPhone(phone) {
  const cleaned = phone.replace(/[\s-]/g, "");
  return /^(\+?8801|01)[3-9]\d{8}$/.test(cleaned);
}
function isValidAccountNumber(methodType, accountNumber) {
  const cleaned = accountNumber.replace(/[\s-]/g, "");
  const m = methodType.toLowerCase();
  if (m.includes("bank")) {
    return /^[0-9A-Za-z]{6,32}$/.test(cleaned);
  }
  if (m.includes("rocket")) {
    return /^(\+?88)?01[3-9]\d{8,9}$/.test(cleaned);
  }
  return /^(\+?88)?01[3-9]\d{8}$/.test(cleaned);
}
function genId(prefix = "id") {
  return `${prefix}_${crypto2.randomBytes(10).toString("hex")}`;
}
function genCode(prefix, digits = 6) {
  const rand = crypto2.randomInt(Math.pow(10, digits - 1), Math.pow(10, digits));
  return `${prefix}-${rand}`;
}
function genReferralCode(username) {
  const base = username.replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, 6) || "GPBD";
  const suffix = crypto2.randomBytes(2).toString("hex").toUpperCase();
  return `${base}${suffix}`;
}
function normalizeTrxKey(trx) {
  return trx.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 120);
}
function hashToken(rawToken) {
  return crypto2.createHash("sha256").update(rawToken).digest("hex");
}
function generateSessionToken() {
  return crypto2.randomBytes(32).toString("hex");
}
async function hashPassword(plain) {
  return bcrypt.hash(plain, BCRYPT_ROUNDS);
}
async function verifyPassword(plain, hash) {
  if (!plain || !hash) return false;
  try {
    return await bcrypt.compare(plain, hash);
  } catch {
    return false;
  }
}
function createVaultPasscodeHash(passcode) {
  const salt = crypto2.randomBytes(16).toString("hex");
  const hash = crypto2.pbkdf2Sync(passcode, salt, 12e4, 32, "sha256").toString("hex");
  return { salt, hash };
}
function verifyVaultPasscode(passcode, salt, expectedHash) {
  if (!passcode || !salt || !expectedHash) return false;
  try {
    const derived = crypto2.pbkdf2Sync(passcode, salt, 12e4, 32, "sha256");
    const expected = Buffer.from(expectedHash, "hex");
    if (derived.length !== expected.length) return false;
    return crypto2.timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}
function timingSafeStringEqual(a, b) {
  const ha = crypto2.createHash("sha256").update(a).digest();
  const hb = crypto2.createHash("sha256").update(b).digest();
  return crypto2.timingSafeEqual(ha, hb);
}
function computeSecurityDepositRequirement(existingActiveCount, settings) {
  const enabled = settings.security_deposit_enabled !== "false";
  const nextSlot = existingActiveCount + 1;
  if (!enabled) {
    return { enabled: false, requiredBdt: 0, requiredPaisa: 0, nextSlot };
  }
  const tier1 = Math.max(0, Number(settings.security_deposit_1_account ?? DEFAULT_SECURITY_DEPOSIT_1_BDT) || DEFAULT_SECURITY_DEPOSIT_1_BDT);
  const tier2 = Math.max(0, Number(settings.security_deposit_2_accounts ?? DEFAULT_SECURITY_DEPOSIT_2_BDT) || DEFAULT_SECURITY_DEPOSIT_2_BDT);
  const extra = Math.max(0, Number(settings.security_deposit_extra_account ?? DEFAULT_SECURITY_DEPOSIT_EXTRA_BDT) || DEFAULT_SECURITY_DEPOSIT_EXTRA_BDT);
  let requiredBdt = tier1;
  if (nextSlot === 1) {
    requiredBdt = tier1;
  } else if (nextSlot === 2) {
    requiredBdt = tier2;
  } else {
    requiredBdt = tier2 + (nextSlot - 2) * extra;
  }
  return {
    enabled: true,
    requiredBdt,
    requiredPaisa: toPaisa(requiredBdt),
    nextSlot
  };
}
function toIso(val) {
  if (!val) return null;
  if (val instanceof Date) return val.toISOString();
  const str = String(val);
  if (str.includes("T")) return str;
  return (/* @__PURE__ */ new Date(str.replace(" ", "T") + "Z")).toISOString();
}
function getClientIp(req) {
  const fwd = req.headers?.["x-forwarded-for"];
  if (typeof fwd === "string" && fwd.length > 0) {
    return fwd.split(",")[0].trim().slice(0, 64);
  }
  return String(req.ip || req.socket?.remoteAddress || "unknown").slice(0, 64);
}
function parsePermissions(jsonText) {
  if (!jsonText) return [];
  try {
    const parsed = JSON.parse(jsonText);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}
function mapWallet(w, extra) {
  const bal = fromPaisa(w?.balance_paisa);
  const locked = fromPaisa(w?.locked_balance_paisa);
  const pendingComm = fromPaisa(extra?.pendingCommissionPaisa ?? w?.pending_commission_paisa ?? 0);
  const totalDeposited = fromPaisa(w?.total_deposited_paisa);
  const totalWithdrawn = fromPaisa(w?.total_withdrawn_paisa);
  const totalCommission = fromPaisa(w?.total_commission_paisa);
  return {
    user_id: w?.user_id || "",
    balance: bal,
    available_balance: bal,
    locked_balance: locked,
    pending_balance: locked,
    pending_withdrawal: locked,
    pending_commission: pendingComm,
    total_balance: Number((bal + locked).toFixed(2)),
    total_deposited: totalDeposited,
    total_deposits: totalDeposited,
    total_withdrawn: totalWithdrawn,
    total_withdrawals: totalWithdrawn,
    total_commission: totalCommission,
    total_earnings: totalCommission,
    total_spent: fromPaisa(w?.total_spent_paisa),
    updated_at: toIso(w?.updated_at)
  };
}
function mapUserPublic(u) {
  return {
    id: u.id,
    uid: u.uid,
    full_name: u.full_name,
    username: u.username,
    email: u.email,
    phone: u.phone,
    referral_code: u.referral_code,
    referred_by: u.referred_by || null,
    sponsor_uid: u.sponsor_uid || null,
    sponsor_username: u.sponsor_username || null,
    status: u.status,
    role: u.role || "user",
    preferred_language: u.preferred_language || "en",
    avatar_url: u.avatar_url || null,
    admin_note: u.admin_note || "",
    last_login_at: toIso(u.last_login_at),
    created_at: toIso(u.created_at)
  };
}
function mapTransaction(t) {
  const before = fromPaisa(t.balance_before_paisa);
  const after = fromPaisa(t.balance_after_paisa);
  return {
    id: t.id,
    tx_uid: t.tx_uid,
    user_id: t.user_id,
    full_name: t.full_name,
    user_name: t.full_name,
    username: t.username,
    user_uid: t.user_uid,
    type: t.type,
    tx_type: t.type,
    direction: t.direction,
    amount: fromPaisa(t.amount_paisa),
    balance_before: before,
    previous_balance: before,
    balance_after: after,
    new_balance: after,
    reference_type: t.reference_type,
    reference_id: t.reference_id,
    payment_method: t.payment_method,
    sender_number: t.sender_number,
    receiver_number: t.receiver_number,
    receiving_number: t.receiver_number,
    description: t.description,
    status: t.status,
    created_at: toIso(t.created_at)
  };
}
function mapDeposit(d) {
  const processedAt = toIso(d.reviewed_at);
  return {
    id: d.id,
    deposit_uid: d.deposit_uid,
    user_id: d.user_id,
    full_name: d.full_name,
    user_name: d.full_name,
    username: d.username,
    user_uid: d.user_uid,
    email: d.email,
    payment_method: d.payment_method,
    payment_setting_id: d.payment_setting_id,
    account_type: d.account_type,
    amount: fromPaisa(d.amount_paisa),
    sender_number: d.sender_number,
    receiver_number: d.receiver_number,
    receiving_number: d.receiver_number,
    transaction_id: d.transaction_id,
    screenshot_url: d.screenshot_url || null,
    screenshot_path: d.screenshot_url || null,
    note: d.note || "",
    user_note: d.note || "",
    status: d.status,
    admin_note: d.admin_note || "",
    processing_eta: d.processing_eta || "",
    rejection_reason: d.status === "rejected" ? d.admin_note || "" : "",
    reviewed_by: d.reviewed_by || null,
    reviewed_at: processedAt,
    processed_at: processedAt,
    processed_by_name: d.reviewed_by_name || null,
    created_at: toIso(d.created_at),
    updated_at: toIso(d.updated_at)
  };
}
function mapWithdrawal(w) {
  const paidDateStr = w.payment_date ? String(w.payment_date).slice(0, 10) : w.paid_at ? toIso(w.paid_at)?.slice(0, 10) || null : null;
  return {
    id: w.id,
    withdrawal_uid: w.withdrawal_uid,
    user_id: w.user_id,
    full_name: w.full_name,
    user_name: w.full_name,
    username: w.username,
    user_uid: w.user_uid,
    email: w.email,
    payment_method_id: w.payment_method_id,
    payment_method: w.payment_method,
    account_number: w.account_number,
    account_holder_name: w.account_holder_name,
    account_type: w.account_type,
    amount: fromPaisa(w.amount_paisa),
    fee: fromPaisa(w.fee_paisa),
    net_amount: fromPaisa(w.net_amount_paisa),
    paid_amount: fromPaisa(w.paid_amount_paisa ?? w.net_amount_paisa),
    status: w.status,
    payout_reference: w.payout_reference || "",
    payout_tx_id: w.payout_reference || "",
    admin_note: w.admin_note || "",
    rejection_reason: w.status === "rejected" ? w.admin_note || "" : "",
    reviewed_by: w.reviewed_by || null,
    reviewed_at: toIso(w.reviewed_at),
    paid_at: toIso(w.paid_at),
    payment_date: paidDateStr,
    created_at: toIso(w.created_at),
    updated_at: toIso(w.updated_at)
  };
}
function mapPaymentSetting(ps) {
  const active = Boolean(ps.is_active);
  const wdEnabled = ps.withdrawal_enabled === void 0 ? true : Boolean(ps.withdrawal_enabled);
  return {
    id: ps.id,
    method_type: ps.method_type,
    method_name: ps.method_type,
    account_title: ps.account_title,
    account_holder_name: ps.account_title,
    account_number: ps.account_number,
    receiving_number: ps.account_number,
    account_type: ps.account_type,
    bank_name: ps.bank_name || "",
    branch_name: ps.branch_name || "",
    routing_number: ps.routing_number || "",
    instructions: ps.instructions || "",
    min_deposit: fromPaisa(ps.min_deposit_paisa),
    max_deposit: fromPaisa(ps.max_deposit_paisa),
    is_active: active,
    deposit_enabled: active,
    withdrawal_enabled: wdEnabled,
    display_order: Number(ps.display_order || 0),
    created_at: toIso(ps.created_at),
    updated_at: toIso(ps.updated_at)
  };
}
function mapPaymentMethod(pm) {
  return {
    id: pm.id,
    user_id: pm.user_id,
    full_name: pm.full_name,
    user_name: pm.full_name,
    username: pm.username,
    user_uid: pm.user_uid,
    method_type: pm.method_type,
    method_name: pm.method_type,
    account_label: pm.account_label,
    account_number: pm.account_number,
    account_holder_name: pm.account_holder_name,
    account_type: pm.account_type,
    bank_name: pm.bank_name || "",
    branch_name: pm.branch_name || "",
    routing_number: pm.routing_number || "",
    notes: pm.notes || "",
    is_default: Boolean(pm.is_default),
    verification_status: pm.verification_status || "active",
    has_pin: Boolean(pm.pin_hash),
    status: pm.status,
    created_at: toIso(pm.created_at),
    updated_at: toIso(pm.updated_at)
  };
}
function mapOrder(o) {
  const total = fromPaisa(o.total_amount_paisa);
  return {
    id: o.id,
    order_uid: o.order_uid,
    order_number: o.order_uid,
    user_id: o.user_id,
    full_name: o.full_name,
    user_name: o.full_name,
    username: o.username,
    user_uid: o.user_uid,
    product_id: o.product_id,
    product_name: o.product_name,
    quantity: Number(o.quantity || 1),
    unit_price: fromPaisa(o.unit_price_paisa),
    subtotal: fromPaisa(o.subtotal_paisa),
    discount: fromPaisa(o.discount_paisa),
    fee: fromPaisa(o.fee_paisa),
    total_amount: total,
    total,
    payment_source: o.payment_source,
    payment_status: o.status === "refunded" ? "refunded" : o.status === "cancelled" ? "cancelled" : "paid",
    status: o.status,
    order_status: o.status,
    commission_status: o.commission_status || "none",
    notes: o.notes || "",
    admin_note: o.notes || "",
    invoice_id: o.invoice_id || null,
    invoice_number: o.invoice_number || null,
    created_at: toIso(o.created_at),
    updated_at: toIso(o.updated_at)
  };
}
function mapInvoice(inv) {
  let rawItems = [];
  try {
    rawItems = typeof inv.items_json === "string" ? JSON.parse(inv.items_json) : inv.items_json || [];
  } catch {
    rawItems = [];
  }
  const items = Array.isArray(rawItems) ? rawItems.map((it, idx) => ({
    id: it?.id ?? idx + 1,
    sku: it?.sku || "",
    item_name: it?.item_name || it?.name || "Service Item",
    name: it?.name || it?.item_name || "Service Item",
    quantity: Number(it?.quantity || 1),
    unit_price: Number(it?.unit_price || 0),
    line_total: Number(it?.line_total ?? it?.subtotal ?? 0),
    subtotal: Number(it?.subtotal ?? it?.line_total ?? 0)
  })) : [];
  const issuedIso = toIso(inv.issued_at);
  const dueStr = inv.due_date ? String(inv.due_date).slice(0, 10) : issuedIso ? issuedIso.slice(0, 10) : "";
  return {
    id: inv.id,
    invoice_number: inv.invoice_number,
    order_id: inv.order_id,
    order_uid: inv.order_uid || null,
    order_number: inv.order_uid || null,
    user_id: inv.user_id,
    customer_uid: inv.customer_uid || inv.user_uid || "",
    customer_name: inv.customer_name,
    customer_email: inv.customer_email,
    customer_phone: inv.customer_phone,
    customer_contact: inv.customer_contact || inv.customer_phone || inv.customer_email || "",
    items,
    subtotal: fromPaisa(inv.subtotal_paisa),
    discount: fromPaisa(inv.discount_paisa),
    fee: fromPaisa(inv.fee_paisa),
    tax: fromPaisa(inv.tax_paisa),
    total: fromPaisa(inv.total_paisa),
    payment_status: inv.payment_status,
    invoice_status: inv.invoice_status || inv.payment_status || "paid",
    payment_method: inv.payment_method || "wallet",
    invoice_date: issuedIso ? issuedIso.slice(0, 10) : "",
    due_date: dueStr,
    issued_at: issuedIso,
    notes: inv.notes || "",
    created_at: toIso(inv.created_at)
  };
}
function mapCommission(c) {
  const amt = fromPaisa(c.commission_amount_paisa);
  const base = fromPaisa(c.base_amount_paisa);
  return {
    id: c.id,
    commission_uid: c.commission_uid,
    earner_user_id: c.earner_user_id,
    earner_name: c.earner_name,
    earner_username: c.earner_username,
    beneficiary_username: c.earner_username || c.beneficiary_username || "",
    source_user_id: c.source_user_id,
    source_name: c.source_name,
    source_username: c.source_username,
    order_id: c.order_id,
    order_uid: c.order_uid || null,
    order_number: c.order_uid || "MANUAL",
    level: Number(c.level || 1),
    referral_level: Number(c.level || 1),
    rate_percent: Number(c.rate_percent || 0),
    rate_value: Number(c.rate_percent || 0),
    rate_type: "percentage",
    base_amount: base,
    order_amount: base,
    commission_amount: amt,
    status: c.status,
    note: c.note || "",
    admin_note: c.note || "",
    credited_at: toIso(c.credited_at),
    created_at: toIso(c.created_at)
  };
}

// server/middleware/auth.ts
var USER_COOKIE_NAME = "gpbd_user_session";
var ADMIN_COOKIE_NAME = "gpbd_admin_session";
function isSecureRequest(req) {
  if (env.isProd) return true;
  if (req.secure) return true;
  if (req.headers["x-forwarded-proto"] === "https") return true;
  return false;
}
function getCookieSameSite(secure) {
  if (env.cookieSameSite === "none") {
    return secure ? "none" : "lax";
  }
  return env.cookieSameSite;
}
function setSessionCookie(req, res, cookieName, rawToken) {
  const secure = isSecureRequest(req);
  const maxAgeMs = env.sessionTtlDays * 24 * 60 * 60 * 1e3;
  res.cookie(cookieName, rawToken, {
    httpOnly: true,
    secure,
    sameSite: getCookieSameSite(secure),
    path: "/",
    maxAge: maxAgeMs
  });
}
function clearSessionCookie(req, res, cookieName) {
  const secure = isSecureRequest(req);
  res.clearCookie(cookieName, {
    httpOnly: true,
    secure,
    sameSite: getCookieSameSite(secure),
    path: "/"
  });
}
async function createDbSession(req, actorType, actorId) {
  const rawToken = generateSessionToken();
  const tokenHash = hashToken(rawToken);
  const id = genId("sess");
  const ip = getClientIp(req);
  const ua = String(req.headers["user-agent"] || "").slice(0, 250);
  await execute(
    `INSERT INTO sessions (id, token_hash, actor_type, actor_id, ip_address, user_agent, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? DAY), UTC_TIMESTAMP())`,
    [id, tokenHash, actorType, actorId, ip, ua, env.sessionTtlDays]
  );
  return rawToken;
}
async function deleteDbSessionByRawToken(rawToken) {
  if (!rawToken) return;
  const tokenHash = hashToken(rawToken);
  await execute("DELETE FROM sessions WHERE token_hash = ?", [tokenHash]);
}
function extractToken(req, cookieName, headerName, allowQueryToken = false) {
  const cookieToken = req.cookies?.[cookieName];
  if (typeof cookieToken === "string" && cookieToken.length >= 32) {
    return cookieToken;
  }
  const customHeader = req.headers[headerName];
  if (typeof customHeader === "string" && customHeader.length >= 32) {
    return customHeader.trim();
  }
  const authHeader = req.headers.authorization;
  if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
    const token = authHeader.slice(7).trim();
    if (token.length >= 32) return token;
  }
  if (allowQueryToken && typeof req.query?.token === "string" && req.query.token.trim().length >= 32) {
    return req.query.token.trim();
  }
  return null;
}
async function resolveUserFromRequest(req, options) {
  const rawToken = extractToken(req, USER_COOKIE_NAME, "x-user-session", Boolean(options?.allowQueryToken));
  if (!rawToken) return null;
  const tokenHash = hashToken(rawToken);
  const rows = await query(
    `SELECT u.*
     FROM sessions s
     INNER JOIN users u ON u.id = s.actor_id
     WHERE s.token_hash = ?
       AND s.actor_type = 'user'
       AND s.expires_at > UTC_TIMESTAMP()
     LIMIT 1`,
    [tokenHash]
  );
  if (!rows.length) return null;
  req.sessionTokenHash = tokenHash;
  return rows[0];
}
async function resolveAdminFromRequest(req, options) {
  const rawToken = extractToken(req, ADMIN_COOKIE_NAME, "x-admin-session", Boolean(options?.allowQueryToken));
  if (!rawToken) return null;
  const tokenHash = hashToken(rawToken);
  const rows = await query(
    `SELECT a.id, a.admin_uid, a.full_name, a.email, a.role_id, a.status,
            r.slug AS role_slug, r.name AS role_name, r.permissions_json
     FROM sessions s
     INNER JOIN admins a ON a.id = s.actor_id
     INNER JOIN admin_roles r ON r.id = a.role_id
     WHERE s.token_hash = ?
       AND s.actor_type = 'admin'
       AND s.expires_at > UTC_TIMESTAMP()
     LIMIT 1`,
    [tokenHash]
  );
  if (!rows.length) return null;
  const row = rows[0];
  req.sessionTokenHash = tokenHash;
  return {
    id: row.id,
    admin_uid: row.admin_uid,
    full_name: row.full_name,
    email: row.email,
    role_id: Number(row.role_id),
    role_slug: row.role_slug,
    role_name: row.role_name,
    permissions: parsePermissions(row.permissions_json),
    status: row.status
  };
}
async function requireUser(req, res, next) {
  try {
    const user = await resolveUserFromRequest(req);
    if (!user) {
      res.status(401).json({ success: false, message: "Authentication required. Please log in." });
      return;
    }
    if (user.status === "suspended") {
      res.status(403).json({
        success: false,
        message: "Your account has been suspended. Please contact GO PAY BD support."
      });
      return;
    }
    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}
async function requireAdmin(req, res, next) {
  try {
    const admin = await resolveAdminFromRequest(req);
    if (!admin) {
      res.status(401).json({ success: false, message: "Administrator authentication required." });
      return;
    }
    if (admin.status !== "active") {
      res.status(403).json({ success: false, message: "This administrator account is suspended." });
      return;
    }
    req.admin = admin;
    next();
  } catch (err) {
    next(err);
  }
}
function requirePermission(permission) {
  return (req, res, next) => {
    const admin = req.admin;
    if (!admin) {
      res.status(401).json({ success: false, message: "Administrator authentication required." });
      return;
    }
    if (admin.permissions.includes("*") || admin.permissions.includes(permission)) {
      next();
      return;
    }
    res.status(403).json({
      success: false,
      message: `Permission denied: requires "${permission}" capability.`
    });
  };
}
function isTrustedOrigin(rawOriginOrReferer, req) {
  if (!rawOriginOrReferer) return false;
  try {
    const parsed = new URL(rawOriginOrReferer);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return false;
    }
    if (env.allowedOrigins.has(parsed.origin)) {
      return true;
    }
    if (!env.isProd) {
      const hostName = parsed.hostname.toLowerCase();
      if (hostName === "localhost" || hostName === "127.0.0.1" || hostName === "::1" || hostName === "0.0.0.0") {
        return true;
      }
      const reqHost = req?.headers?.host;
      if (reqHost && parsed.host === reqHost) {
        return true;
      }
    }
    return false;
  } catch {
    return false;
  }
}
function csrfProtection(req, res, next) {
  const method = req.method.toUpperCase();
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") {
    next();
    return;
  }
  const origin = typeof req.headers.origin === "string" ? req.headers.origin.trim() : "";
  const referer = typeof req.headers.referer === "string" ? req.headers.referer.trim() : "";
  if (origin) {
    if (!isTrustedOrigin(origin, req)) {
      res.status(403).json({
        success: false,
        message: "Cross-site request blocked: untrusted Origin."
      });
      return;
    }
    next();
    return;
  }
  if (referer) {
    if (!isTrustedOrigin(referer, req)) {
      res.status(403).json({
        success: false,
        message: "Cross-site request blocked: untrusted Referer."
      });
      return;
    }
    const xrw2 = req.headers["x-requested-with"];
    if (xrw2 === "XMLHttpRequest" || xrw2 === "GoPayBD") {
      next();
      return;
    }
  }
  const xrw = req.headers["x-requested-with"];
  if (!origin && !referer && (xrw === "XMLHttpRequest" || xrw === "GoPayBD")) {
    next();
    return;
  }
  res.status(403).json({
    success: false,
    message: "Cross-site request blocked for your protection."
  });
}
var generalApiLimiter = rateLimit({
  windowMs: 60 * 1e3,
  limit: 240,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests. Please slow down briefly." }
});
var authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  limit: 25,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many login or registration attempts. Please try again in 15 minutes." }
});
var adminLoginRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  limit: 12,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many admin unlock attempts. Please wait 15 minutes before retrying." }
});
async function recordLoginLog(req, actorType, actorId, identifier, success) {
  try {
    await execute(
      `INSERT INTO login_logs (id, actor_type, actor_id, identifier, success, ip_address, user_agent, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())`,
      [
        genId("llog"),
        actorType,
        actorId,
        identifier.slice(0, 190),
        success ? 1 : 0,
        getClientIp(req),
        String(req.headers["user-agent"] || "").slice(0, 250)
      ]
    );
  } catch {
  }
}
async function recordAuditLog(params) {
  try {
    await execute(
      `INSERT INTO audit_logs
         (id, actor_type, actor_id, actor_name, action, entity_type, entity_id, old_values, new_values, ip_address, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())`,
      [
        genId("aud"),
        params.actorType,
        params.actorId,
        params.actorName.slice(0, 160),
        params.action.slice(0, 128),
        params.entityType.slice(0, 64),
        params.entityId || null,
        params.oldValues !== void 0 ? JSON.stringify(params.oldValues) : null,
        params.newValues !== void 0 ? JSON.stringify(params.newValues) : null,
        getClientIp(params.req)
      ]
    );
  } catch {
  }
}

// server/middleware/upload.ts
import crypto3 from "crypto";
import fs2 from "fs";
import path3 from "path";
import multer from "multer";
var ALLOWED_IMAGE_MIMES = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp"]);
var ALLOWED_ATTACHMENT_MIMES = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp", "application/pdf"]);
var MIME_EXT = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "application/pdf": ".pdf"
};
function ensureUploadSubdir(subdir) {
  const safeSubdir = subdir.replace(/[^a-z0-9_-]/gi, "");
  const targetDir = path3.resolve(env.uploadDir, safeSubdir);
  if (!targetDir.startsWith(env.uploadDir + path3.sep) && targetDir !== env.uploadDir) {
    throw new Error("Invalid upload directory");
  }
  fs2.mkdirSync(targetDir, { recursive: true });
  return targetDir;
}
function createDiskUpload(subdir, allowPdf, maxSizeBytes) {
  const allowed = allowPdf ? ALLOWED_ATTACHMENT_MIMES : ALLOWED_IMAGE_MIMES;
  const storage = multer.diskStorage({
    destination: (_req, _file, cb) => {
      try {
        const dir = ensureUploadSubdir(subdir);
        cb(null, dir);
      } catch (err) {
        cb(err, env.uploadDir);
      }
    },
    filename: (_req, file, cb) => {
      const ext = MIME_EXT[file.mimetype] || ".bin";
      const randomName = `${Date.now()}_${crypto3.randomBytes(12).toString("hex")}${ext}`;
      cb(null, randomName);
    }
  });
  return multer({
    storage,
    limits: { fileSize: maxSizeBytes, files: 1 },
    fileFilter: (_req, file, cb) => {
      if (!allowed.has(file.mimetype)) {
        cb(new Error(allowPdf ? "Only JPG, PNG, WEBP, or PDF files are allowed." : "Only JPG, PNG, or WEBP image files are allowed."));
        return;
      }
      cb(null, true);
    }
  });
}
var depositScreenshotUpload = createDiskUpload("deposits", false, 5 * 1024 * 1024);
var supportAttachmentUpload = createDiskUpload("support", true, 5 * 1024 * 1024);
var profileAvatarUpload = createDiskUpload("avatars", false, 3 * 1024 * 1024);
function toPublicUploadUrl(subdir, filename) {
  if (!filename) return null;
  const safeSub = subdir.replace(/[^a-z0-9_-]/gi, "");
  const safeName = path3.basename(filename);
  return `/uploads/${safeSub}/${safeName}`;
}
function resolveSafeUploadPath(subdir, filename) {
  const safeSub = subdir.replace(/[^a-z0-9_-]/gi, "");
  const safeName = path3.basename(filename);
  const fullPath = path3.resolve(env.uploadDir, safeSub, safeName);
  const allowedBase = path3.resolve(env.uploadDir) + path3.sep;
  if (!fullPath.startsWith(allowedBase)) {
    return null;
  }
  return fullPath;
}

// server/routes/publicRoutes.ts
import { Router } from "express";

// server/services/platformService.ts
async function getPlatformSettings(conn) {
  const merged = { ...DEFAULT_PUBLIC_SETTINGS };
  try {
    const rows = conn ? (await conn.execute("SELECT setting_key, setting_value FROM platform_settings"))[0] : await query("SELECT setting_key, setting_value FROM platform_settings");
    for (const row of rows) {
      if (row.setting_key) {
        merged[String(row.setting_key)] = String(row.setting_value ?? "");
      }
    }
  } catch {
  }
  return merged;
}
async function createUserNotification(conn, params) {
  const sql = `
    INSERT INTO notifications (id, user_id, type, title, message, link, is_read, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 0, UTC_TIMESTAMP())
  `;
  const values = [
    genId("ntf"),
    params.userId,
    params.type || "system",
    params.title.slice(0, 200),
    params.message,
    params.link || null
  ];
  if (conn) {
    await conn.execute(sql, values);
  } else {
    await execute(sql, values);
  }
}
async function createAdminNotification(conn, params) {
  const sql = `
    INSERT INTO admin_notifications (id, type, title, message, link, is_read, created_at)
    VALUES (?, ?, ?, ?, ?, 0, UTC_TIMESTAMP())
  `;
  const values = [
    genId("antf"),
    params.type || "system",
    params.title.slice(0, 200),
    params.message,
    params.link || null
  ];
  if (conn) {
    await conn.execute(sql, values);
  } else {
    await execute(sql, values);
  }
}
async function insertWalletTransaction(conn, params) {
  const id = genId("tx");
  const txUid = genCode("TXN", 8);
  await conn.execute(
    `INSERT INTO wallet_transactions
       (id, tx_uid, user_id, type, direction, amount_paisa, balance_before_paisa, balance_after_paisa,
        reference_type, reference_id, payment_method, sender_number, receiver_number, description,
        status, created_by_admin_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())`,
    [
      id,
      txUid,
      params.userId,
      params.type,
      params.direction,
      params.amountPaisa,
      params.balanceBeforePaisa,
      params.balanceAfterPaisa,
      params.referenceType || null,
      params.referenceId || null,
      params.paymentMethod || null,
      params.senderNumber || null,
      params.receiverNumber || null,
      params.description || "",
      params.status || "completed",
      params.createdByAdminId || null
    ]
  );
  return id;
}
async function nextInvoiceNumber(conn, prefix) {
  await conn.execute(
    `INSERT INTO counters (counter_key, current_value, updated_at)
     VALUES ('invoice_seq', 1000, UTC_TIMESTAMP())
     ON DUPLICATE KEY UPDATE counter_key = counter_key`
  );
  const [rows] = await conn.execute(
    `SELECT current_value FROM counters WHERE counter_key = 'invoice_seq' FOR UPDATE`
  );
  const nextVal = Number(rows[0]?.current_value || 1e3) + 1;
  await conn.execute(
    `UPDATE counters SET current_value = ?, updated_at = UTC_TIMESTAMP() WHERE counter_key = 'invoice_seq'`,
    [nextVal]
  );
  const cleanPrefix = (prefix || "GPBD-INV").replace(/[^A-Za-z0-9-]/g, "").slice(0, 16) || "GPBD-INV";
  const year = (/* @__PURE__ */ new Date()).getUTCFullYear();
  return `${cleanPrefix}-${year}-${String(nextVal).padStart(5, "0")}`;
}

// server/routes/publicRoutes.ts
var router = Router();
router.get("/health", async (_req, res) => {
  const db = await checkDatabaseHealth();
  const status = db.connected ? "ok" : db.configured ? "degraded" : "standby";
  const healthy = db.connected || !env.isProd && !db.configured;
  res.status(healthy ? 200 : 503).json({
    success: healthy,
    status,
    database: db.connected ? "connected" : db.configured ? "disconnected" : "not_configured",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
router.get("/public/settings", async (_req, res) => {
  try {
    const settings = await getPlatformSettings();
    res.json({ success: true, data: settings });
  } catch {
    res.json({ success: true, data: DEFAULT_PUBLIC_SETTINGS });
  }
});
router.get("/public/catalog", async (_req, res, next) => {
  try {
    const rows = await query(
      `SELECT id, sku, name, category, description, price_paisa, commission_eligible, is_active
       FROM catalog_products
       WHERE is_active = 1
       ORDER BY price_paisa ASC`
    );
    res.json({
      success: true,
      data: rows.map((p) => {
        const price = fromPaisa(p.price_paisa);
        return {
          id: p.id,
          sku: p.sku,
          name: p.name,
          category: p.category,
          description: p.description || "",
          price,
          unit_price: price,
          commission_eligible: Boolean(p.commission_eligible),
          is_active: Boolean(p.is_active)
        };
      })
    });
  } catch (err) {
    if (err?.status === 503) {
      res.json({ success: true, data: [] });
      return;
    }
    next(err);
  }
});
router.post("/public/referral-click", async (req, res, next) => {
  try {
    const code = sanitizeText(req.body?.code || req.body?.referral_code, 64).toUpperCase();
    if (!code) {
      res.status(400).json({ success: false, message: "Referral code is required." });
      return;
    }
    const rows = await query(
      `SELECT referral_code, username, full_name FROM public_referrals WHERE UPPER(referral_code) = ? LIMIT 1`,
      [code]
    );
    if (!rows.length) {
      res.status(404).json({ success: false, message: "Referral code not found." });
      return;
    }
    await execute(
      `UPDATE public_referrals SET clicks = clicks + 1, updated_at = UTC_TIMESTAMP() WHERE referral_code = ?`,
      [rows[0].referral_code]
    );
    res.json({
      success: true,
      data: {
        referral_code: rows[0].referral_code,
        sponsor_username: rows[0].username,
        sponsor_name: rows[0].full_name
      }
    });
  } catch (err) {
    next(err);
  }
});
router.post("/public/contact", async (req, res, next) => {
  try {
    const name = sanitizeText(req.body?.name, 160);
    const email = sanitizeText(req.body?.email, 190).toLowerCase();
    const phone = sanitizeText(req.body?.phone, 32);
    const subject = sanitizeText(req.body?.subject || "General Inquiry", 200);
    const message = sanitizeText(req.body?.message, 2500);
    if (!name || !isValidEmail(email) || message.length < 5) {
      res.status(400).json({
        success: false,
        message: "Please provide your name, a valid email address, and a message."
      });
      return;
    }
    const id = genId("cmsg");
    await execute(
      `INSERT INTO contact_messages (id, name, email, phone, subject, message, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'new', UTC_TIMESTAMP())`,
      [id, name, email, phone || null, subject, message]
    );
    await createAdminNotification(null, {
      type: "contact",
      title: `New Contact Message: ${subject}`,
      message: `${name} (${email}) sent an inquiry.`,
      link: "/admin/support"
    });
    res.status(201).json({
      success: true,
      message: "Your message has been submitted. Our support team will reply shortly.",
      data: { id }
    });
  } catch (err) {
    next(err);
  }
});
var publicRoutes_default = router;

// server/routes/authRoutes.ts
import crypto4 from "crypto";
import { Router as Router2 } from "express";
var router2 = Router2();
var GOOGLE_STATE_COOKIE = "gpbd_google_oauth_state";
function getGoogleRedirectUri(req) {
  if (env.googleCallbackUrl) return env.googleCallbackUrl;
  const base = env.appUrl || `${isSecureRequest(req) ? "https" : "http"}://${req.headers.host}`;
  return `${base.replace(/\/+$/, "")}/auth/google/callback`;
}
router2.post("/register", authRateLimiter, async (req, res, next) => {
  try {
    const settings = await getPlatformSettings();
    if (settings.registration_enabled === "false") {
      res.status(403).json({
        success: false,
        message: "New member registrations are temporarily paused."
      });
      return;
    }
    const fullName = sanitizeText(req.body?.full_name, 160);
    const rawUsername = sanitizeText(req.body?.username, 64).toLowerCase().replace(/[^a-z0-9._-]/g, "");
    const email = sanitizeText(req.body?.email, 190).toLowerCase();
    const phone = sanitizeText(req.body?.phone, 32);
    const password = String(req.body?.password || "");
    const confirmPassword = req.body?.confirm_password;
    const referralCodeInput = sanitizeText(req.body?.referral_code, 64).toUpperCase();
    if (fullName.length < 2) {
      res.status(400).json({ success: false, message: "Please enter your full name." });
      return;
    }
    if (rawUsername.length < 3 || rawUsername.length > 32) {
      res.status(400).json({ success: false, message: "Username must be between 3 and 32 characters." });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ success: false, message: "Please provide a valid email address." });
      return;
    }
    if (!isValidBdPhone(phone)) {
      res.status(400).json({ success: false, message: "Please provide a valid Bangladesh mobile number (01XXXXXXXXX)." });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ success: false, message: "Password must be at least 8 characters long." });
      return;
    }
    if (confirmPassword !== void 0 && password !== String(confirmPassword)) {
      res.status(400).json({ success: false, message: "Passwords do not match." });
      return;
    }
    const passwordHash = await hashPassword(password);
    const created = await withTransaction(async (conn) => {
      const [existing] = await conn.execute(
        `SELECT id, email, username FROM users WHERE LOWER(email) = ? OR LOWER(username) = ? LIMIT 1`,
        [email, rawUsername]
      );
      if (existing.length > 0) {
        if (String(existing[0].email).toLowerCase() === email) {
          throw Object.assign(new Error("An account with this email address already exists."), { status: 409 });
        }
        throw Object.assign(new Error("This username is already taken. Please choose another."), { status: 409 });
      }
      let sponsorId = null;
      let sponsorUsername = null;
      let level2SponsorId = null;
      if (referralCodeInput && settings.referral_enabled !== "false") {
        const [sponsors] = await conn.execute(
          `SELECT id, username, referred_by FROM users WHERE UPPER(referral_code) = ? OR UPPER(username) = ? LIMIT 1`,
          [referralCodeInput, referralCodeInput]
        );
        if (sponsors.length > 0) {
          sponsorId = sponsors[0].id;
          sponsorUsername = sponsors[0].username;
          if (sponsors[0].referred_by) {
            level2SponsorId = sponsors[0].referred_by;
          }
        }
      }
      const userId = genId("usr");
      const uid = genCode("GPBD", 6);
      const myReferralCode = genReferralCode(rawUsername);
      await conn.execute(
        `INSERT INTO users
           (id, uid, full_name, username, email, phone, password_hash, password_reset_required,
            referral_code, referred_by, sponsor_username, status, role, preferred_language,
            last_login_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, 'active', 'user', 'en', UTC_TIMESTAMP(), UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [
          userId,
          uid,
          fullName,
          rawUsername,
          email,
          phone,
          passwordHash,
          myReferralCode,
          sponsorId,
          sponsorUsername
        ]
      );
      await conn.execute(
        `INSERT INTO wallets
           (user_id, balance_paisa, locked_balance_paisa, total_deposited_paisa, total_withdrawn_paisa,
            total_commission_paisa, total_spent_paisa, updated_at)
         VALUES (?, 0, 0, 0, 0, 0, 0, UTC_TIMESTAMP())`,
        [userId]
      );
      await conn.execute(
        `INSERT INTO public_referrals (referral_code, user_id, username, full_name, clicks, updated_at)
         VALUES (?, ?, ?, ?, 0, UTC_TIMESTAMP())`,
        [myReferralCode, userId, rawUsername, fullName]
      );
      if (sponsorId) {
        await conn.execute(
          `INSERT IGNORE INTO referrals (id, referrer_user_id, referred_user_id, level, status, created_at)
           VALUES (?, ?, ?, 1, 'active', UTC_TIMESTAMP())`,
          [genId("ref"), sponsorId, userId]
        );
        await createUserNotification(conn, {
          userId: sponsorId,
          type: "referral",
          title: "New Direct Referral Joined!",
          message: `${fullName} (@${rawUsername}) registered using your referral code.`,
          link: "/referrals"
        });
      }
      if (level2SponsorId && level2SponsorId !== sponsorId && level2SponsorId !== userId) {
        await conn.execute(
          `INSERT IGNORE INTO referrals (id, referrer_user_id, referred_user_id, level, status, created_at)
           VALUES (?, ?, ?, 2, 'active', UTC_TIMESTAMP())`,
          [genId("ref"), level2SponsorId, userId]
        );
      }
      await createUserNotification(conn, {
        userId,
        type: "system",
        title: "Welcome to GO PAY BD!",
        message: "Your verified member account and wallet ledger are ready.",
        link: "/dashboard"
      });
      await createAdminNotification(conn, {
        type: "user",
        title: "New Member Registered",
        message: `${fullName} (@${rawUsername} \xB7 ${uid}) joined GO PAY BD.`,
        link: `/admin/users/${userId}`
      });
      const [uRows] = await conn.execute("SELECT * FROM users WHERE id = ?", [userId]);
      const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ?", [userId]);
      return { user: uRows[0], wallet: wRows[0] };
    });
    const rawToken = await createDbSession(req, "user", created.user.id);
    setSessionCookie(req, res, USER_COOKIE_NAME, rawToken);
    await recordLoginLog(req, "user", created.user.id, email, true);
    res.status(201).json({
      success: true,
      message: "Account created successfully.",
      data: {
        user: mapUserPublic(created.user),
        wallet: mapWallet(created.wallet),
        unread_notifications: 1,
        session_token: rawToken
      }
    });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router2.post("/login", authRateLimiter, async (req, res, next) => {
  try {
    const identifier = sanitizeText(req.body?.identifier || req.body?.email, 190).toLowerCase();
    const password = String(req.body?.password || "");
    if (!identifier || !password) {
      res.status(400).json({ success: false, message: "Email/username and password are required." });
      return;
    }
    const rows = await query(
      `SELECT * FROM users
       WHERE LOWER(email) = ? OR LOWER(username) = ? OR phone = ?
       LIMIT 1`,
      [identifier, identifier, identifier]
    );
    if (!rows.length) {
      await recordLoginLog(req, "user", null, identifier, false);
      res.status(401).json({ success: false, message: "Invalid email/username or password." });
      return;
    }
    const user = rows[0];
    if (user.status === "suspended") {
      await recordLoginLog(req, "user", user.id, identifier, false);
      res.status(403).json({
        success: false,
        message: "This account has been suspended. Please contact GO PAY BD support."
      });
      return;
    }
    if (user.locked_until && new Date(user.locked_until).getTime() > Date.now()) {
      await recordLoginLog(req, "user", user.id, identifier, false);
      res.status(429).json({
        success: false,
        message: "Too many failed login attempts. Please wait 15 minutes or reset your password."
      });
      return;
    }
    if (Number(user.password_reset_required) === 1 || !user.password_hash) {
      res.status(403).json({
        success: false,
        code: "PASSWORD_RESET_REQUIRED",
        message: 'We upgraded our security system. Please use "Forgot Password" to set a fresh password for your account \u2014 all your wallet balance and history are safely preserved.'
      });
      return;
    }
    const valid = await verifyPassword(password, user.password_hash);
    if (!valid) {
      const nextAttempts = Number(user.failed_attempts || 0) + 1;
      const shouldLock = nextAttempts >= 5;
      await execute(
        `UPDATE users
         SET failed_attempts = ?,
             locked_until = IF(?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE), locked_until)
         WHERE id = ?`,
        [nextAttempts, shouldLock ? 1 : 0, user.id]
      );
      await recordLoginLog(req, "user", user.id, identifier, false);
      res.status(401).json({
        success: false,
        message: shouldLock ? "Account temporarily locked for 15 minutes due to multiple failed attempts." : "Invalid email/username or password."
      });
      return;
    }
    await execute(
      `UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = UTC_TIMESTAMP() WHERE id = ?`,
      [user.id]
    );
    const [walletRows, notifRows] = await Promise.all([
      query("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [user.id]),
      query("SELECT COUNT(*) AS cnt FROM notifications WHERE user_id = ? AND is_read = 0", [user.id])
    ]);
    const rawToken = await createDbSession(req, "user", user.id);
    setSessionCookie(req, res, USER_COOKIE_NAME, rawToken);
    await recordLoginLog(req, "user", user.id, identifier, true);
    res.json({
      success: true,
      message: "Signed in successfully.",
      data: {
        user: mapUserPublic(user),
        wallet: mapWallet(walletRows[0] || { user_id: user.id }),
        unread_notifications: Number(notifRows[0]?.cnt || 0),
        session_token: rawToken
      }
    });
  } catch (err) {
    next(err);
  }
});
router2.post("/logout", async (req, res, next) => {
  try {
    const rawCookie = req.cookies?.[USER_COOKIE_NAME];
    const headerToken = typeof req.headers["x-user-session"] === "string" ? req.headers["x-user-session"] : void 0;
    await deleteDbSessionByRawToken(rawCookie || headerToken);
    clearSessionCookie(req, res, USER_COOKIE_NAME);
    res.json({ success: true, message: "Logged out successfully." });
  } catch (err) {
    next(err);
  }
});
router2.get("/me", async (req, res, next) => {
  try {
    const user = await resolveUserFromRequest(req);
    if (!user) {
      res.status(401).json({ success: false, message: "Not authenticated." });
      return;
    }
    if (user.status === "suspended") {
      clearSessionCookie(req, res, USER_COOKIE_NAME);
      res.status(403).json({ success: false, message: "Account suspended." });
      return;
    }
    const [walletRows, notifRows] = await Promise.all([
      query("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [user.id]),
      query("SELECT COUNT(*) AS cnt FROM notifications WHERE user_id = ? AND is_read = 0", [user.id])
    ]);
    res.json({
      success: true,
      data: {
        user: mapUserPublic(user),
        wallet: mapWallet(walletRows[0] || { user_id: user.id }),
        unread_notifications: Number(notifRows[0]?.cnt || 0)
      }
    });
  } catch (err) {
    next(err);
  }
});
router2.post("/forgot-password", authRateLimiter, async (req, res, next) => {
  try {
    const email = sanitizeText(req.body?.email, 190).toLowerCase();
    if (!isValidEmail(email)) {
      res.status(400).json({ success: false, message: "Please enter a valid email address." });
      return;
    }
    const rows = await query("SELECT id, email, full_name FROM users WHERE LOWER(email) = ? LIMIT 1", [
      email
    ]);
    if (rows.length > 0) {
      const user = rows[0];
      const rawResetToken = crypto4.randomBytes(32).toString("hex");
      const tokenHash = hashToken(rawResetToken);
      await execute("UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() WHERE user_id = ? AND used_at IS NULL", [
        user.id
      ]);
      await execute(
        `INSERT INTO password_reset_tokens (id, user_id, token_hash, expires_at, created_at)
         VALUES (?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 60 MINUTE), UTC_TIMESTAMP())`,
        [genId("prt"), user.id, tokenHash]
      );
      await createAdminNotification(null, {
        type: "security",
        title: "Password Reset Requested",
        message: `Member ${user.full_name} (${user.email}) requested a password reset.`,
        link: `/admin/users/${user.id}`
      });
    }
    res.json({
      success: true,
      message: "If an account exists for that email, a password reset link/instructions have been issued. You may also contact support if you do not receive an email."
    });
  } catch (err) {
    next(err);
  }
});
router2.post("/reset-password", authRateLimiter, async (req, res, next) => {
  try {
    const token = sanitizeText(req.body?.token, 128);
    const newPassword = String(req.body?.new_password || req.body?.password || "");
    const confirmPassword = req.body?.confirm_password;
    if (!token || token.length < 16) {
      res.status(400).json({ success: false, message: "A valid password reset token is required." });
      return;
    }
    if (newPassword.length < 8) {
      res.status(400).json({ success: false, message: "New password must be at least 8 characters long." });
      return;
    }
    if (confirmPassword !== void 0 && newPassword !== String(confirmPassword)) {
      res.status(400).json({ success: false, message: "Passwords do not match." });
      return;
    }
    const tokenHash = hashToken(token);
    const newHash = await hashPassword(newPassword);
    await withTransaction(async (conn) => {
      const [rows] = await conn.execute(
        `SELECT id, user_id FROM password_reset_tokens
         WHERE token_hash = ? AND used_at IS NULL AND expires_at > UTC_TIMESTAMP()
         LIMIT 1 FOR UPDATE`,
        [tokenHash]
      );
      if (!rows.length) {
        throw Object.assign(new Error("Reset link is invalid or has expired. Please request a new one."), { status: 400 });
      }
      const prt = rows[0];
      await conn.execute(
        `UPDATE users
         SET password_hash = ?, password_reset_required = 0, failed_attempts = 0, locked_until = NULL, updated_at = UTC_TIMESTAMP()
         WHERE id = ?`,
        [newHash, prt.user_id]
      );
      await conn.execute("UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() WHERE id = ?", [prt.id]);
      await conn.execute(`DELETE FROM sessions WHERE actor_type = 'user' AND actor_id = ?`, [prt.user_id]);
    });
    res.json({
      success: true,
      message: "Password updated successfully. You can now sign in with your new password."
    });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router2.get("/google/status", (_req, res) => {
  res.json({
    success: true,
    data: {
      enabled: env.googleOAuthConfigured
    }
  });
});
router2.get("/google/url", (req, res) => {
  if (!env.googleOAuthConfigured) {
    res.status(503).json({
      success: false,
      message: "Google Sign-In is not configured on this server. Please sign in using Email & Password."
    });
    return;
  }
  const referralCode = sanitizeText(req.query.ref, 64).toUpperCase();
  const nonce = crypto4.randomBytes(16).toString("hex");
  const statePayload = Buffer.from(JSON.stringify({ n: nonce, ref: referralCode })).toString("base64url");
  const sig = crypto4.createHmac("sha256", env.sessionSecret).update(statePayload).digest("hex");
  const signedState = `${statePayload}.${sig}`;
  const secure = isSecureRequest(req);
  res.cookie(GOOGLE_STATE_COOKIE, nonce, {
    httpOnly: true,
    secure,
    sameSite: getCookieSameSite(secure),
    path: "/",
    maxAge: 10 * 60 * 1e3
  });
  const redirectUri = getGoogleRedirectUri(req);
  const params = new URLSearchParams({
    client_id: env.googleClientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "openid email profile",
    state: signedState,
    prompt: "select_account"
  });
  res.json({
    success: true,
    data: {
      url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`
    }
  });
});
async function handleGoogleOAuthCallback(req, res) {
  const sendPopupHtml = (ok, payload) => {
    const safeJson = JSON.stringify(payload).replace(/</g, "\\u003c");
    res.status(ok ? 200 : 400).setHeader("Content-Type", "text/html; charset=utf-8").send(`<!doctype html>
<html>
<head><title>GO PAY BD Authentication</title></head>
<body style="font-family:system-ui,sans-serif;padding:24px;text-align:center;color:#0F172A;">
  <p>${ok ? "Authentication successful! Closing window..." : "Authentication could not be completed."}</p>
  <script>
    (function() {
      var data = ${safeJson};
      if (window.opener && !window.opener.closed) {
        window.opener.postMessage(data, '*');
        window.close();
      } else {
        window.location.href = ${ok ? "'/dashboard'" : "'/login'"};
      }
    })();
  </script>
</body>
</html>`);
  };
  try {
    if (!env.googleOAuthConfigured) {
      sendPopupHtml(false, { type: "OAUTH_AUTH_ERROR", message: "Google OAuth is not configured." });
      return;
    }
    const code = sanitizeText(req.query.code, 512);
    const state = sanitizeText(req.query.state, 512);
    if (!code || !state || !state.includes(".")) {
      sendPopupHtml(false, { type: "OAUTH_AUTH_ERROR", message: "Invalid OAuth callback parameters." });
      return;
    }
    const [statePayload, sig] = state.split(".");
    const expectedSig = crypto4.createHmac("sha256", env.sessionSecret).update(statePayload).digest("hex");
    if (sig.length !== expectedSig.length || !crypto4.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) {
      sendPopupHtml(false, { type: "OAUTH_AUTH_ERROR", message: "OAuth state verification failed." });
      return;
    }
    const parsedState = JSON.parse(Buffer.from(statePayload, "base64url").toString("utf8"));
    const cookieNonce = req.cookies?.[GOOGLE_STATE_COOKIE];
    if (cookieNonce && cookieNonce !== parsedState.n) {
      sendPopupHtml(false, { type: "OAUTH_AUTH_ERROR", message: "OAuth session mismatch." });
      return;
    }
    res.clearCookie(GOOGLE_STATE_COOKIE, { path: "/" });
    const redirectUri = getGoogleRedirectUri(req);
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: env.googleClientId,
        client_secret: env.googleClientSecret,
        redirect_uri: redirectUri,
        grant_type: "authorization_code"
      })
    });
    const tokenJson = await tokenRes.json();
    if (!tokenRes.ok || !tokenJson.access_token) {
      sendPopupHtml(false, { type: "OAUTH_AUTH_ERROR", message: "Failed to exchange Google OAuth code." });
      return;
    }
    const profileRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${tokenJson.access_token}` }
    });
    const profile = await profileRes.json();
    const email = sanitizeText(profile?.email, 190).toLowerCase();
    const googleSub = sanitizeText(profile?.sub, 190);
    const fullName = sanitizeText(profile?.name || email.split("@")[0], 160);
    const picture = sanitizeText(profile?.picture, 500);
    if (!email || !googleSub) {
      sendPopupHtml(false, { type: "OAUTH_AUTH_ERROR", message: "Google account did not provide an email." });
      return;
    }
    const userRecord = await withTransaction(async (conn) => {
      const [existing] = await conn.execute(
        `SELECT * FROM users WHERE google_id = ? OR LOWER(email) = ? LIMIT 1`,
        [googleSub, email]
      );
      if (existing.length > 0) {
        const u = existing[0];
        if (u.status === "suspended") {
          throw new Error("Your account is suspended.");
        }
        await conn.execute(
          `UPDATE users SET google_id = ?, avatar_url = COALESCE(avatar_url, ?), last_login_at = UTC_TIMESTAMP() WHERE id = ?`,
          [googleSub, picture || null, u.id]
        );
        return u;
      }
      const settings = await getPlatformSettings(conn);
      if (settings.registration_enabled === "false") {
        throw new Error("New registrations are temporarily paused.");
      }
      const userId = genId("usr");
      const uid = genCode("GPBD", 6);
      const baseUsername = email.split("@")[0].replace(/[^a-z0-9]/g, "").slice(0, 16) || "member";
      const username = `${baseUsername}${crypto4.randomInt(100, 999)}`;
      const myReferralCode = genReferralCode(username);
      let sponsorId = null;
      let sponsorUsername = null;
      let level2SponsorId = null;
      const refCode = sanitizeText(parsedState.ref, 64).toUpperCase();
      if (refCode) {
        const [sponsors] = await conn.execute(
          `SELECT id, username, referred_by FROM users WHERE UPPER(referral_code) = ? LIMIT 1`,
          [refCode]
        );
        if (sponsors.length > 0) {
          sponsorId = sponsors[0].id;
          sponsorUsername = sponsors[0].username;
          level2SponsorId = sponsors[0].referred_by || null;
        }
      }
      await conn.execute(
        `INSERT INTO users
           (id, uid, full_name, username, email, phone, password_hash, password_reset_required,
            google_id, referral_code, referred_by, sponsor_username, status, role, avatar_url,
            last_login_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, '', NULL, 0, ?, ?, ?, ?, 'active', 'user', ?, UTC_TIMESTAMP(), UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [userId, uid, fullName, username, email, googleSub, myReferralCode, sponsorId, sponsorUsername, picture || null]
      );
      await conn.execute(
        `INSERT INTO wallets (user_id, balance_paisa, locked_balance_paisa, total_deposited_paisa, total_withdrawn_paisa, total_commission_paisa, total_spent_paisa, updated_at)
         VALUES (?, 0, 0, 0, 0, 0, 0, UTC_TIMESTAMP())`,
        [userId]
      );
      await conn.execute(
        `INSERT INTO public_referrals (referral_code, user_id, username, full_name, clicks, updated_at)
         VALUES (?, ?, ?, ?, 0, UTC_TIMESTAMP())`,
        [myReferralCode, userId, username, fullName]
      );
      if (sponsorId) {
        await conn.execute(
          `INSERT IGNORE INTO referrals (id, referrer_user_id, referred_user_id, level, status, created_at)
           VALUES (?, ?, ?, 1, 'active', UTC_TIMESTAMP())`,
          [genId("ref"), sponsorId, userId]
        );
      }
      if (level2SponsorId && level2SponsorId !== sponsorId) {
        await conn.execute(
          `INSERT IGNORE INTO referrals (id, referrer_user_id, referred_user_id, level, status, created_at)
           VALUES (?, ?, ?, 2, 'active', UTC_TIMESTAMP())`,
          [genId("ref"), level2SponsorId, userId]
        );
      }
      const [fresh] = await conn.execute("SELECT * FROM users WHERE id = ?", [userId]);
      return fresh[0];
    });
    const rawToken = await createDbSession(req, "user", userRecord.id);
    setSessionCookie(req, res, USER_COOKIE_NAME, rawToken);
    await recordLoginLog(req, "user", userRecord.id, email, true);
    sendPopupHtml(true, { type: "OAUTH_AUTH_SUCCESS", session_token: rawToken });
  } catch (err) {
    sendPopupHtml(false, {
      type: "OAUTH_AUTH_ERROR",
      message: err?.message || "Google authentication failed."
    });
  }
}
var authRoutes_default = router2;

// server/routes/userRoutes.ts
import { Router as Router3 } from "express";
var router3 = Router3();
router3.use(requireUser);
router3.get("/dashboard", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const [
      walletRows,
      pendingDepRows,
      refCountRows,
      orderStatRows,
      recentTx,
      recentDeps,
      recentWds,
      recentOrds,
      recentComms,
      depMonthly,
      wdMonthly,
      commMonthly
    ] = await Promise.all([
      query("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [userId]),
      query(
        `SELECT COALESCE(SUM(amount_paisa), 0) AS total FROM deposits WHERE user_id = ? AND status IN ('pending','processing')`,
        [userId]
      ),
      query(
        `SELECT
           SUM(CASE WHEN level = 1 THEN 1 ELSE 0 END) AS l1,
           SUM(CASE WHEN level = 2 THEN 1 ELSE 0 END) AS l2
         FROM referrals WHERE referrer_user_id = ?`,
        [userId]
      ),
      query(
        `SELECT COUNT(*) AS cnt, COALESCE(SUM(total_amount_paisa), 0) AS vol
         FROM orders WHERE user_id = ? AND status IN ('completed','processing','pending')`,
        [userId]
      ),
      query(
        `SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10`,
        [userId]
      ),
      query(
        `SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 10`,
        [userId]
      ),
      query(
        `SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 10`,
        [userId]
      ),
      query(
        `SELECT o.*,
                COALESCE(
                  (SELECT c.status FROM commissions c WHERE c.order_id = o.id ORDER BY c.created_at DESC LIMIT 1),
                  'none'
                ) AS commission_status
         FROM orders o WHERE o.user_id = ? ORDER BY o.created_at DESC LIMIT 10`,
        [userId]
      ),
      query(
        `SELECT c.*, o.order_uid, eu.username AS earner_username, eu.full_name AS earner_name
         FROM commissions c
         LEFT JOIN orders o ON o.id = c.order_id
         LEFT JOIN users eu ON eu.id = c.earner_user_id
         WHERE c.earner_user_id = ?
         ORDER BY c.created_at DESC LIMIT 10`,
        [userId]
      ),
      query(
        `SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, COALESCE(SUM(amount_paisa), 0) AS total
         FROM deposits WHERE user_id = ? AND status = 'approved'
           AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 6 MONTH)
         GROUP BY ym`,
        [userId]
      ),
      query(
        `SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, COALESCE(SUM(net_amount_paisa), 0) AS total
         FROM withdrawals WHERE user_id = ? AND status = 'paid'
           AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 6 MONTH)
         GROUP BY ym`,
        [userId]
      ),
      query(
        `SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, COALESCE(SUM(commission_amount_paisa), 0) AS total
         FROM commissions WHERE earner_user_id = ? AND status = 'credited'
           AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 6 MONTH)
         GROUP BY ym`,
        [userId]
      )
    ]);
    const [pendingCommRow] = await query(
      `SELECT COALESCE(SUM(commission_amount_paisa), 0) AS total
       FROM commissions WHERE earner_user_id = ? AND status IN ('pending','approved')`,
      [userId]
    );
    const wallet = mapWallet(walletRows[0] || { user_id: userId }, {
      pendingCommissionPaisa: pendingCommRow?.total
    });
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const depMap = new Map(depMonthly.map((r) => [String(r.ym), fromPaisa(r.total)]));
    const wdMap = new Map(wdMonthly.map((r) => [String(r.ym), fromPaisa(r.total)]));
    const commMap = new Map(commMonthly.map((r) => [String(r.ym), fromPaisa(r.total)]));
    const analytics = [];
    const now = /* @__PURE__ */ new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
      const ym = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
      analytics.push({
        month: `${monthNames[d.getUTCMonth()]} ${String(d.getUTCFullYear()).slice(2)}`,
        deposits: depMap.get(ym) || 0,
        withdrawals: wdMap.get(ym) || 0,
        commissions: commMap.get(ym) || 0
      });
    }
    res.json({
      success: true,
      data: {
        summary: {
          total_balance: wallet.total_balance,
          available_balance: wallet.available_balance,
          pending_balance: wallet.pending_balance,
          pending_deposits: fromPaisa(pendingDepRows[0]?.total),
          total_deposits: wallet.total_deposited,
          total_withdrawals: wallet.total_withdrawn,
          total_earnings: wallet.total_commission,
          total_commission: wallet.total_commission,
          direct_referrals: Number(refCountRows[0]?.l1 || 0),
          level2_referrals: Number(refCountRows[0]?.l2 || 0),
          total_orders: Number(orderStatRows[0]?.cnt || 0),
          total_order_value: fromPaisa(orderStatRows[0]?.vol)
        },
        wallet,
        analytics,
        recent: {
          transactions: recentTx.map(mapTransaction),
          deposits: recentDeps.map(mapDeposit),
          withdrawals: recentWds.map(mapWithdrawal),
          orders: recentOrds.map(mapOrder),
          commissions: recentComms.map(mapCommission)
        }
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/wallet", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const [walletRows, recentRows, pendingCommRows, activePmRows, settings] = await Promise.all([
      query("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [userId]),
      query(
        "SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20",
        [userId]
      ),
      query(
        `SELECT COALESCE(SUM(commission_amount_paisa), 0) AS total
         FROM commissions WHERE earner_user_id = ? AND status IN ('pending','approved')`,
        [userId]
      ),
      query(
        `SELECT COUNT(*) AS cnt FROM payment_methods WHERE user_id = ? AND status = 'active'`,
        [userId]
      ),
      getPlatformSettings()
    ]);
    const linkedCount = Number(activePmRows[0]?.cnt || 0);
    const reqDeposit = computeSecurityDepositRequirement(linkedCount, settings);
    const walletMapped = mapWallet(walletRows[0] || { user_id: userId }, {
      pendingCommissionPaisa: pendingCommRows[0]?.total
    });
    res.json({
      success: true,
      data: {
        ...walletMapped,
        wallet: walletMapped,
        recent_transactions: recentRows.map(mapTransaction),
        security_deposit_enabled: reqDeposit.enabled,
        security_deposit_1_account: Number(settings.security_deposit_1_account || 825),
        security_deposit_2_accounts: Number(settings.security_deposit_2_accounts || 1825),
        security_deposit_extra_account: Number(settings.security_deposit_extra_account || 1e3),
        linked_accounts_count: linkedCount,
        next_account_number: reqDeposit.nextSlot,
        required_security_deposit: reqDeposit.requiredBdt
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/wallet/transactions", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
    const offset = (page - 1) * limit;
    const whereParts = ["user_id = ?"];
    const params = [userId];
    const typeFilter = sanitizeText(req.query.type || req.query.tx_type, 64);
    if (typeFilter && typeFilter !== "all") {
      whereParts.push("type = ?");
      params.push(typeFilter);
    }
    const statusFilter = sanitizeText(req.query.status, 32);
    if (statusFilter && statusFilter !== "all") {
      whereParts.push("status = ?");
      params.push(statusFilter);
    }
    const methodFilter = sanitizeText(req.query.payment_method, 64);
    if (methodFilter && methodFilter !== "all") {
      whereParts.push("payment_method = ?");
      params.push(methodFilter);
    }
    const dirFilter = sanitizeText(req.query.direction, 16);
    if (dirFilter === "credit" || dirFilter === "debit") {
      whereParts.push("direction = ?");
      params.push(dirFilter);
    }
    const minAmtRaw = req.query.min_amount !== void 0 && req.query.min_amount !== "" ? Number(req.query.min_amount) : null;
    if (minAmtRaw !== null && Number.isFinite(minAmtRaw)) {
      whereParts.push("amount_paisa >= ?");
      params.push(toPaisa(minAmtRaw));
    }
    const maxAmtRaw = req.query.max_amount !== void 0 && req.query.max_amount !== "" ? Number(req.query.max_amount) : null;
    if (maxAmtRaw !== null && Number.isFinite(maxAmtRaw)) {
      whereParts.push("amount_paisa <= ?");
      params.push(toPaisa(maxAmtRaw));
    }
    const search = sanitizeText(req.query.search, 120);
    if (search) {
      whereParts.push("(tx_uid LIKE ? OR description LIKE ? OR reference_id LIKE ? OR sender_number LIKE ? OR receiver_number LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like, like, like);
    }
    const dateFrom = sanitizeText(req.query.date_from, 20);
    if (dateFrom) {
      whereParts.push("DATE(created_at) >= ?");
      params.push(dateFrom);
    }
    const dateTo = sanitizeText(req.query.date_to, 20);
    if (dateTo) {
      whereParts.push("DATE(created_at) <= ?");
      params.push(dateTo);
    }
    const whereSql = whereParts.join(" AND ");
    const [countRows, rows] = await Promise.all([
      query(`SELECT COUNT(*) AS cnt FROM wallet_transactions WHERE ${whereSql}`, params),
      query(
        `SELECT * FROM wallet_transactions WHERE ${whereSql} ORDER BY created_at DESC LIMIT ${limit} OFFSET ${offset}`,
        params
      )
    ]);
    const total = Number(countRows[0]?.cnt || 0);
    res.json({
      success: true,
      data: {
        items: rows.map(mapTransaction),
        pagination: {
          page,
          limit,
          total,
          total_pages: Math.max(1, Math.ceil(total / limit))
        }
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/deposit-methods", async (_req, res, next) => {
  try {
    const [rows, settings] = await Promise.all([
      query(
        `SELECT * FROM payment_settings WHERE is_active = 1 ORDER BY display_order ASC, created_at ASC`
      ),
      getPlatformSettings()
    ]);
    const depEnabled = settings.deposit_enabled !== "false";
    const minDep = Number(settings.min_deposit || 100);
    const maxDep = Number(settings.max_deposit || 5e5);
    res.json({
      success: true,
      data: {
        methods: rows.map(mapPaymentSetting),
        deposit_enabled: depEnabled,
        global_min_deposit: minDep,
        global_max_deposit: maxDep,
        min_deposit: minDep,
        max_deposit: maxDep,
        rules: {
          deposit_enabled: depEnabled,
          min_deposit: minDep,
          max_deposit: maxDep
        }
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/deposits", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const status = sanitizeText(req.query.status, 32);
    const params = [userId];
    let sql = "SELECT * FROM deposits WHERE user_id = ?";
    if (status && status !== "all") {
      sql += " AND status = ?";
      params.push(status);
    }
    sql += " ORDER BY created_at DESC LIMIT 100";
    const rows = await query(sql, params);
    res.json({ success: true, data: rows.map(mapDeposit) });
  } catch (err) {
    next(err);
  }
});
router3.post("/deposits", depositScreenshotUpload.single("screenshot"), async (req, res, next) => {
  try {
    const user = req.user;
    const settings = await getPlatformSettings();
    if (settings.deposit_enabled === "false") {
      res.status(403).json({ success: false, message: "Deposits are temporarily disabled." });
      return;
    }
    const paymentSettingId = sanitizeText(req.body?.payment_setting_id, 128);
    const amount = Number(req.body?.amount);
    const senderNumber = sanitizeText(req.body?.sender_number, 64);
    const rawTrx = sanitizeText(req.body?.transaction_id, 120);
    const note = sanitizeText(req.body?.note, 500);
    const minDep = Number(settings.min_deposit || 100);
    const maxDep = Number(settings.max_deposit || 5e5);
    if (!Number.isFinite(amount) || amount < minDep || amount > maxDep) {
      res.status(400).json({
        success: false,
        message: `Deposit amount must be between \u09F3${minDep} and \u09F3${maxDep}.`
      });
      return;
    }
    if (senderNumber.length < 6) {
      res.status(400).json({ success: false, message: "Please enter a valid sender number." });
      return;
    }
    const trxKey = normalizeTrxKey(rawTrx);
    if (trxKey.length < 4) {
      res.status(400).json({ success: false, message: "Please enter a valid Transaction ID (TrxID)." });
      return;
    }
    const amountPaisa = toPaisa(amount);
    const screenshotUrl = toPublicUploadUrl("deposits", req.file?.filename);
    const created = await withTransaction(async (conn) => {
      let paymentMethod = sanitizeText(req.body?.payment_method, 64) || "bKash";
      let receiverNumber = sanitizeText(req.body?.receiver_number || req.body?.receiving_number, 64);
      let accountType = "personal";
      if (paymentSettingId) {
        const [psRows] = await conn.execute(
          "SELECT * FROM payment_settings WHERE id = ? AND is_active = 1 LIMIT 1",
          [paymentSettingId]
        );
        if (!psRows.length) {
          throw Object.assign(new Error("Selected receiving payment channel is no longer active."), { status: 400 });
        }
        const ps = psRows[0];
        paymentMethod = ps.method_type;
        receiverNumber = ps.account_number;
        accountType = ps.account_type || "personal";
        if (amountPaisa < Number(ps.min_deposit_paisa || 0) || amountPaisa > Number(ps.max_deposit_paisa || 5e8)) {
          throw Object.assign(
            new Error(
              `Amount for ${ps.method_type} must be between \u09F3${fromPaisa(ps.min_deposit_paisa)} and \u09F3${fromPaisa(ps.max_deposit_paisa)}.`
            ),
            { status: 400 }
          );
        }
      }
      const [existingLock] = await conn.execute(
        "SELECT transaction_id FROM deposit_transaction_locks WHERE transaction_id = ? LIMIT 1 FOR UPDATE",
        [trxKey]
      );
      if (existingLock.length > 0) {
        throw Object.assign(
          new Error("This Transaction ID (TrxID) has already been submitted. Duplicate claims are blocked."),
          { status: 409 }
        );
      }
      const depId = genId("dep");
      const depositUid = genCode("DEP", 7);
      await conn.execute(
        `INSERT INTO deposit_transaction_locks (transaction_id, deposit_id, user_id, created_at)
         VALUES (?, ?, ?, UTC_TIMESTAMP())`,
        [trxKey, depId, user.id]
      );
      await conn.execute(
        `INSERT INTO deposits
           (id, deposit_uid, user_id, payment_method, payment_setting_id, account_type,
            amount_paisa, sender_number, receiver_number, transaction_id, screenshot_url, note,
            status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [
          depId,
          depositUid,
          user.id,
          paymentMethod,
          paymentSettingId || null,
          accountType,
          amountPaisa,
          senderNumber,
          receiverNumber || "Official Account",
          trxKey,
          screenshotUrl,
          note
        ]
      );
      await createAdminNotification(conn, {
        type: "deposit",
        title: `New Deposit Request: \u09F3${amount.toFixed(2)}`,
        message: `${user.full_name} (@${user.username}) submitted ${paymentMethod} TrxID ${trxKey} from ${senderNumber}.`,
        link: "/admin/deposits"
      });
      const [depRows] = await conn.execute("SELECT * FROM deposits WHERE id = ?", [depId]);
      return depRows[0];
    });
    res.status(201).json({
      success: true,
      message: "Deposit request submitted and queued for verification.",
      data: mapDeposit(created)
    });
  } catch (err) {
    if (err?.code === "ER_DUP_ENTRY") {
      res.status(409).json({
        success: false,
        message: "This Transaction ID (TrxID) has already been submitted."
      });
      return;
    }
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router3.get("/payment-methods", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      `SELECT * FROM payment_methods WHERE user_id = ? AND status != 'deleted' ORDER BY is_default DESC, created_at DESC`,
      [userId]
    );
    res.json({ success: true, data: rows.map(mapPaymentMethod) });
  } catch (err) {
    next(err);
  }
});
router3.post("/payment-methods", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const methodType = sanitizeText(req.body?.method_name || req.body?.method_type, 64);
    const accountLabel = sanitizeText(req.body?.account_label || `${methodType} Wallet`, 160);
    const accountNumber = sanitizeText(req.body?.account_number, 64);
    const accountHolderName = sanitizeText(req.body?.account_holder_name || req.user.full_name, 160);
    const accountType = sanitizeText(req.body?.account_type || "personal", 32);
    const bankName = sanitizeText(req.body?.bank_name, 160);
    const branchName = sanitizeText(req.body?.branch_name, 160);
    const routingNumber = sanitizeText(req.body?.routing_number, 64);
    const notes = sanitizeText(req.body?.notes, 500);
    const verificationStatus = sanitizeText(req.body?.verification_status || "active", 32) || "active";
    const rawPinHash = sanitizeText(req.body?.pin_hash, 255);
    const rawPinPlain = sanitizeText(req.body?.pin, 16);
    const pinHash = rawPinHash || (rawPinPlain ? await hashPassword(rawPinPlain) : null);
    const isDefaultReq = Boolean(req.body?.is_default);
    if (!methodType || !accountNumber || !isValidAccountNumber(methodType, accountNumber)) {
      res.status(400).json({
        success: false,
        message: "Please enter a valid payment method and account number."
      });
      return;
    }
    const created = await withTransaction(async (conn) => {
      const settings = await getPlatformSettings(conn);
      const [walletRows] = await conn.execute(
        "SELECT * FROM wallets WHERE user_id = ? FOR UPDATE",
        [userId]
      );
      const wallet = walletRows[0] || { total_deposited_paisa: 0, balance_paisa: 0 };
      const [existingRows] = await conn.execute(
        `SELECT id, account_number, method_type FROM payment_methods WHERE user_id = ? AND status = 'active'`,
        [userId]
      );
      const dup = existingRows.find(
        (r) => String(r.account_number) === accountNumber && String(r.method_type).toLowerCase() === methodType.toLowerCase()
      );
      if (dup) {
        throw Object.assign(new Error("This wallet account number is already linked to your profile."), { status: 409 });
      }
      const reqDeposit = computeSecurityDepositRequirement(existingRows.length, settings);
      const qualifyingDepositPaisa = Math.max(
        Number(wallet.total_deposited_paisa || 0),
        Number(wallet.balance_paisa || 0)
      );
      if (reqDeposit.enabled && qualifyingDepositPaisa < reqDeposit.requiredPaisa) {
        const shortfallBdt = fromPaisa(reqDeposit.requiredPaisa - qualifyingDepositPaisa);
        throw Object.assign(
          new Error(
            `\u09A8\u09BF\u09B0\u09BE\u09AA\u09A4\u09CD\u09A4\u09BE \u099C\u09BE\u09AE\u09BE\u09A8\u09A4 \u09AA\u09CD\u09B0\u09AF\u09BC\u09CB\u099C\u09A8: ${reqDeposit.nextSlot} \u09A8\u0982 \u0993\u09DF\u09BE\u09B2\u09C7\u099F \u0985\u09CD\u09AF\u09BE\u0995\u09BE\u0989\u09A8\u09CD\u099F \u09AF\u09C1\u0995\u09CD\u09A4 \u0995\u09B0\u09A4\u09C7 \u09A8\u09CD\u09AF\u09C2\u09A8\u09A4\u09AE \u09F3${reqDeposit.requiredBdt.toLocaleString()} \u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7\u0964 \u0986\u09AA\u09A8\u09BE\u09B0 \u0986\u09B0\u0993 \u09F3${shortfallBdt.toLocaleString()} \u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F \u09AA\u09CD\u09B0\u09DF\u09CB\u099C\u09A8\u0964 (Security deposit of \u09F3${reqDeposit.requiredBdt} required for account #${reqDeposit.nextSlot}.)`
          ),
          { status: 403 }
        );
      }
      const makeDefault = isDefaultReq || existingRows.length === 0;
      if (makeDefault) {
        await conn.execute("UPDATE payment_methods SET is_default = 0 WHERE user_id = ?", [userId]);
      }
      const pmId = genId("pm");
      await conn.execute(
        `INSERT INTO payment_methods
           (id, user_id, method_type, account_label, account_number, account_holder_name, account_type,
            bank_name, branch_name, routing_number, notes, is_default, verification_status, pin_hash, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [
          pmId,
          userId,
          methodType,
          accountLabel,
          accountNumber,
          accountHolderName,
          accountType,
          bankName || null,
          branchName || null,
          routingNumber || null,
          notes || null,
          makeDefault ? 1 : 0,
          verificationStatus,
          pinHash
        ]
      );
      const [fresh] = await conn.execute("SELECT * FROM payment_methods WHERE id = ?", [pmId]);
      return fresh[0];
    });
    res.status(201).json({
      success: true,
      message: "Payment method linked successfully.",
      data: mapPaymentMethod(created)
    });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router3.post("/payment-methods/:id/default", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    await withTransaction(async (conn) => {
      const [rows] = await conn.execute(
        `SELECT id FROM payment_methods WHERE id = ? AND user_id = ? AND status = 'active' LIMIT 1`,
        [id, userId]
      );
      if (!rows.length) {
        throw Object.assign(new Error("Payment method not found."), { status: 404 });
      }
      await conn.execute("UPDATE payment_methods SET is_default = 0 WHERE user_id = ?", [userId]);
      await conn.execute("UPDATE payment_methods SET is_default = 1, updated_at = UTC_TIMESTAMP() WHERE id = ?", [id]);
    });
    res.json({ success: true, message: "Default withdrawal method updated." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router3.put("/payment-methods/:id", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    const existing = await query(
      `SELECT * FROM payment_methods WHERE id = ? AND user_id = ? AND status != 'deleted' LIMIT 1`,
      [id, userId]
    );
    if (!existing.length) {
      res.status(404).json({ success: false, message: "Payment method not found." });
      return;
    }
    const cur = existing[0];
    const methodType = sanitizeText(req.body?.method_name || req.body?.method_type || cur.method_type, 64);
    const accountLabel = sanitizeText(req.body?.account_label || cur.account_label, 160);
    const accountNumber = sanitizeText(req.body?.account_number || cur.account_number, 64);
    const accountHolderName = sanitizeText(req.body?.account_holder_name || cur.account_holder_name, 160);
    const accountType = sanitizeText(req.body?.account_type || cur.account_type, 32);
    const notes = req.body?.notes !== void 0 ? sanitizeText(req.body.notes, 500) : cur.notes;
    const verificationStatus = req.body?.verification_status !== void 0 ? sanitizeText(req.body.verification_status, 32) : cur.verification_status || "active";
    const rawPinHash = sanitizeText(req.body?.pin_hash, 255);
    const nextPinHash = rawPinHash || cur.pin_hash || null;
    if (!isValidAccountNumber(methodType, accountNumber)) {
      res.status(400).json({ success: false, message: "Invalid account number." });
      return;
    }
    await execute(
      `UPDATE payment_methods
       SET method_type = ?, account_label = ?, account_number = ?, account_holder_name = ?, account_type = ?,
           notes = ?, verification_status = ?, pin_hash = ?, updated_at = UTC_TIMESTAMP()
       WHERE id = ? AND user_id = ?`,
      [methodType, accountLabel, accountNumber, accountHolderName, accountType, notes || null, verificationStatus, nextPinHash, id, userId]
    );
    const [fresh] = await query("SELECT * FROM payment_methods WHERE id = ? LIMIT 1", [id]);
    res.json({ success: true, message: "Payment method updated.", data: fresh ? mapPaymentMethod(fresh) : null });
  } catch (err) {
    next(err);
  }
});
router3.delete("/payment-methods/:id", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    const result = await execute(
      `UPDATE payment_methods SET status = 'deleted', is_default = 0, updated_at = UTC_TIMESTAMP() WHERE id = ? AND user_id = ?`,
      [id, userId]
    );
    if (result.affectedRows === 0) {
      res.status(404).json({ success: false, message: "Payment method not found." });
      return;
    }
    res.json({ success: true, message: "Payment method removed." });
  } catch (err) {
    next(err);
  }
});
router3.get("/withdrawal-rules", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const [settings, walletRows, methodRows] = await Promise.all([
      getPlatformSettings(),
      query("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [userId]),
      query(
        `SELECT DISTINCT method_type FROM payment_settings WHERE is_active = 1 AND withdrawal_enabled = 1 ORDER BY display_order ASC`
      )
    ]);
    const dailyLimit = Number(settings.daily_withdrawal_limit || 1e5);
    const weeklyLimit = Number(settings.weekly_withdrawal_limit || dailyLimit * 5);
    const supportedMethods = methodRows.length ? methodRows.map((r) => String(r.method_type)) : ["bKash", "Nagad", "Rocket", "Upay", "Bank Transfer", "Card"];
    res.json({
      success: true,
      data: {
        withdrawal_enabled: settings.withdrawal_enabled !== "false",
        min_withdrawal: Number(settings.min_withdrawal || 300),
        max_withdrawal: Number(settings.max_withdrawal || 2e5),
        withdrawal_fee_type: settings.withdrawal_fee_type || "percentage",
        withdrawal_fee: Number(settings.withdrawal_fee || 1.5),
        daily_withdrawal_limit: dailyLimit,
        daily_limit: dailyLimit,
        weekly_limit: weeklyLimit,
        processing_time: settings.withdrawal_processing_time || "15\u201360 minutes",
        supported_methods: supportedMethods,
        wallet: mapWallet(walletRows[0] || { user_id: userId })
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/withdrawals", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      "SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 100",
      [userId]
    );
    res.json({ success: true, data: rows.map(mapWithdrawal) });
  } catch (err) {
    next(err);
  }
});
router3.post("/withdrawals", async (req, res, next) => {
  try {
    const user = req.user;
    const amount = Number(req.body?.amount);
    const paymentMethodId = sanitizeText(req.body?.payment_method_id, 128);
    const created = await withTransaction(async (conn) => {
      const settings = await getPlatformSettings(conn);
      if (settings.withdrawal_enabled === "false") {
        throw Object.assign(new Error("Withdrawals are temporarily paused."), { status: 403 });
      }
      const minWd = Number(settings.min_withdrawal || 300);
      const maxWd = Number(settings.max_withdrawal || 2e5);
      const dailyLimit = Number(settings.daily_withdrawal_limit || 1e5);
      if (!Number.isFinite(amount) || amount < minWd || amount > maxWd) {
        throw Object.assign(new Error(`Withdrawal amount must be between \u09F3${minWd} and \u09F3${maxWd}.`), { status: 400 });
      }
      let methodType = sanitizeText(req.body?.payment_method, 64);
      let accountNumber = sanitizeText(req.body?.account_number, 64);
      let accountHolderName = sanitizeText(req.body?.account_holder_name || user.full_name, 160);
      let accountType = sanitizeText(req.body?.account_type || "personal", 32);
      if (paymentMethodId) {
        const [pmRows] = await conn.execute(
          `SELECT * FROM payment_methods WHERE id = ? AND user_id = ? AND status = 'active' LIMIT 1`,
          [paymentMethodId, user.id]
        );
        if (!pmRows.length) {
          throw Object.assign(new Error("Selected withdrawal account not found."), { status: 404 });
        }
        methodType = pmRows[0].method_type;
        accountNumber = pmRows[0].account_number;
        accountHolderName = pmRows[0].account_holder_name;
        accountType = pmRows[0].account_type;
      }
      if (!methodType || !accountNumber) {
        throw Object.assign(new Error("Please select a saved withdrawal account."), { status: 400 });
      }
      const amountPaisa = toPaisa(amount);
      const [todayRows] = await conn.execute(
        `SELECT COALESCE(SUM(amount_paisa), 0) AS total
         FROM withdrawals
         WHERE user_id = ? AND status IN ('pending','processing','approved','paid') AND DATE(created_at) = UTC_DATE()`,
        [user.id]
      );
      if (Number(todayRows[0]?.total || 0) + amountPaisa > toPaisa(dailyLimit)) {
        throw Object.assign(
          new Error(`Daily withdrawal limit of \u09F3${dailyLimit.toLocaleString()} exceeded.`),
          { status: 400 }
        );
      }
      const [wRows] = await conn.execute(
        "SELECT * FROM wallets WHERE user_id = ? FOR UPDATE",
        [user.id]
      );
      if (!wRows.length) {
        throw Object.assign(new Error("Wallet not found."), { status: 404 });
      }
      const wallet = wRows[0];
      const balanceBefore = Number(wallet.balance_paisa);
      if (balanceBefore < amountPaisa) {
        throw Object.assign(new Error("Insufficient available wallet balance for this withdrawal."), { status: 400 });
      }
      const feeType = settings.withdrawal_fee_type || "percentage";
      const feeVal = Math.max(0, Number(settings.withdrawal_fee || 0));
      const feePaisa = feeType === "fixed" ? toPaisa(feeVal) : Math.round(amountPaisa * feeVal / 100);
      const netAmountPaisa = Math.max(0, amountPaisa - feePaisa);
      if (netAmountPaisa <= 0) {
        throw Object.assign(new Error("Withdrawal net payout must be greater than zero after fees."), { status: 400 });
      }
      const balanceAfter = balanceBefore - amountPaisa;
      const lockedAfter = Number(wallet.locked_balance_paisa) + amountPaisa;
      await conn.execute(
        `UPDATE wallets SET balance_paisa = ?, locked_balance_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
        [balanceAfter, lockedAfter, user.id]
      );
      const wdId = genId("wd");
      const wdUid = genCode("WDR", 7);
      await conn.execute(
        `INSERT INTO withdrawals
           (id, withdrawal_uid, user_id, payment_method_id, payment_method, account_number,
            account_holder_name, account_type, amount_paisa, fee_paisa, net_amount_paisa,
            status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [
          wdId,
          wdUid,
          user.id,
          paymentMethodId || null,
          methodType,
          accountNumber,
          accountHolderName,
          accountType,
          amountPaisa,
          feePaisa,
          netAmountPaisa
        ]
      );
      await insertWalletTransaction(conn, {
        userId: user.id,
        type: "withdrawal_request",
        direction: "debit",
        amountPaisa,
        balanceBeforePaisa: balanceBefore,
        balanceAfterPaisa: balanceAfter,
        referenceType: "withdrawal",
        referenceId: wdUid,
        paymentMethod: methodType,
        receiverNumber: accountNumber,
        description: `Withdrawal reserved (${wdUid}) to ${methodType} ${accountNumber}`,
        status: "pending"
      });
      await createAdminNotification(conn, {
        type: "withdrawal",
        title: `Withdrawal Request: \u09F3${amount.toFixed(2)}`,
        message: `${user.full_name} (@${user.username}) requested \u09F3${fromPaisa(netAmountPaisa)} net payout to ${methodType} ${accountNumber}.`,
        link: "/admin/withdrawals"
      });
      const [fresh] = await conn.execute("SELECT * FROM withdrawals WHERE id = ?", [wdId]);
      return fresh[0];
    });
    res.status(201).json({
      success: true,
      message: "Withdrawal request submitted and funds reserved safely.",
      data: mapWithdrawal(created)
    });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router3.post("/withdrawals/:id/cancel", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    await withTransaction(async (conn) => {
      const [wdRows] = await conn.execute(
        "SELECT * FROM withdrawals WHERE id = ? AND user_id = ? FOR UPDATE",
        [id, userId]
      );
      if (!wdRows.length) {
        throw Object.assign(new Error("Withdrawal request not found."), { status: 404 });
      }
      const wd = wdRows[0];
      if (wd.status !== "pending") {
        throw Object.assign(new Error("Only pending withdrawal requests can be cancelled."), { status: 400 });
      }
      const [wRows] = await conn.execute(
        "SELECT * FROM wallets WHERE user_id = ? FOR UPDATE",
        [userId]
      );
      const wallet = wRows[0];
      const amt = Number(wd.amount_paisa);
      const balanceBefore = Number(wallet.balance_paisa);
      const balanceAfter = balanceBefore + amt;
      const lockedAfter = Math.max(0, Number(wallet.locked_balance_paisa) - amt);
      await conn.execute(
        `UPDATE wallets SET balance_paisa = ?, locked_balance_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
        [balanceAfter, lockedAfter, userId]
      );
      await conn.execute(
        `UPDATE withdrawals SET status = 'cancelled', updated_at = UTC_TIMESTAMP() WHERE id = ?`,
        [id]
      );
      await insertWalletTransaction(conn, {
        userId,
        type: "withdrawal_cancelled",
        direction: "credit",
        amountPaisa: amt,
        balanceBeforePaisa: balanceBefore,
        balanceAfterPaisa: balanceAfter,
        referenceType: "withdrawal",
        referenceId: wd.withdrawal_uid,
        paymentMethod: wd.payment_method,
        receiverNumber: wd.account_number,
        description: `Cancelled withdrawal ${wd.withdrawal_uid} refunded to available balance`,
        status: "completed"
      });
    });
    res.json({ success: true, message: "Withdrawal cancelled and funds returned to your available balance." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router3.get("/referrals/summary", async (req, res, next) => {
  try {
    const user = req.user;
    const [refStats, commStats, clickRows, settings] = await Promise.all([
      query(
        `SELECT
           SUM(CASE WHEN r.level = 1 THEN 1 ELSE 0 END) AS l1,
           SUM(CASE WHEN r.level = 2 THEN 1 ELSE 0 END) AS l2,
           SUM(CASE WHEN u.status = 'active' THEN 1 ELSE 0 END) AS active_cnt
         FROM referrals r
         INNER JOIN users u ON u.id = r.referred_user_id
         WHERE r.referrer_user_id = ?`,
        [user.id]
      ),
      query(
        `SELECT
           COUNT(DISTINCT order_id) AS ref_orders,
           COALESCE(SUM(CASE WHEN status = 'credited' THEN commission_amount_paisa ELSE 0 END), 0) AS credited,
           COALESCE(SUM(CASE WHEN status IN ('pending','approved') THEN commission_amount_paisa ELSE 0 END), 0) AS pending
         FROM commissions
         WHERE earner_user_id = ?`,
        [user.id]
      ),
      query(
        "SELECT clicks FROM public_referrals WHERE user_id = ? LIMIT 1",
        [user.id]
      ),
      getPlatformSettings()
    ]);
    const l1 = Number(refStats[0]?.l1 || 0);
    const l2 = Number(refStats[0]?.l2 || 0);
    const clicks = Number(clickRows[0]?.clicks || 0);
    const conversionRate = clicks > 0 ? Number((l1 / clicks * 100).toFixed(1)) : 0;
    res.json({
      success: true,
      data: {
        referral_code: user.referral_code,
        total_level_1: l1,
        total_direct: l1,
        total_level_2: l2,
        active_referrals: Number(refStats[0]?.active_cnt || 0),
        referral_orders: Number(commStats[0]?.ref_orders || 0),
        referral_earnings: fromPaisa(commStats[0]?.credited),
        pending_earnings: fromPaisa(commStats[0]?.pending),
        clicks_count: clicks,
        conversion_rate: conversionRate,
        commission_type: settings.commission_type || "percentage",
        level_1_rate: settings.level_1_commission || "7",
        level_2_rate: settings.level_2_commission || "3",
        min_qualifying_order: Number(settings.min_qualifying_order || 100)
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/referrals", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      `SELECT
         r.id, r.level, r.created_at AS joined_at,
         u.uid AS user_uid, u.full_name, u.username, u.status AS user_status,
         (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id AND o.status = 'completed') AS order_count,
         (SELECT COALESCE(SUM(c.commission_amount_paisa), 0)
            FROM commissions c
            WHERE c.earner_user_id = r.referrer_user_id AND c.source_user_id = u.id AND c.status = 'credited') AS comm_paisa
       FROM referrals r
       INNER JOIN users u ON u.id = r.referred_user_id
       WHERE r.referrer_user_id = ?
       ORDER BY r.created_at DESC`,
      [userId]
    );
    res.json({
      success: true,
      data: rows.map((r) => ({
        id: r.id,
        user_uid: r.user_uid,
        full_name: r.full_name,
        username: r.username,
        level: Number(r.level),
        order_count: Number(r.order_count || 0),
        commission_generated: fromPaisa(r.comm_paisa),
        user_status: r.user_status,
        joined_at: toIso(r.joined_at)
      }))
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/referrals/earnings", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      `SELECT c.*, o.order_uid, su.username AS source_username, su.full_name AS source_name
       FROM commissions c
       LEFT JOIN orders o ON o.id = c.order_id
       LEFT JOIN users su ON su.id = c.source_user_id
       WHERE c.earner_user_id = ?
       ORDER BY c.created_at DESC LIMIT 200`,
      [userId]
    );
    res.json({ success: true, data: rows.map(mapCommission) });
  } catch (err) {
    next(err);
  }
});
router3.get("/orders", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      `SELECT o.*, i.id AS invoice_id, i.invoice_number,
              COALESCE(
                (SELECT c.status FROM commissions c WHERE c.order_id = o.id ORDER BY c.created_at DESC LIMIT 1),
                'none'
              ) AS commission_status
       FROM orders o
       LEFT JOIN invoices i ON i.order_id = o.id
       WHERE o.user_id = ?
       ORDER BY o.created_at DESC LIMIT 100`,
      [userId]
    );
    res.json({ success: true, data: rows.map(mapOrder) });
  } catch (err) {
    next(err);
  }
});
router3.get("/orders/:id", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    const rows = await query(
      `SELECT o.*, i.id AS invoice_id, i.invoice_number,
              COALESCE(
                (SELECT c.status FROM commissions c WHERE c.order_id = o.id ORDER BY c.created_at DESC LIMIT 1),
                'none'
              ) AS commission_status
       FROM orders o
       LEFT JOIN invoices i ON i.order_id = o.id
       WHERE o.id = ? AND o.user_id = ?
       LIMIT 1`,
      [id, userId]
    );
    if (!rows.length) {
      res.status(404).json({ success: false, message: "Order not found." });
      return;
    }
    const orderRow = rows[0];
    const [invRows, commRows] = await Promise.all([
      query(
        `SELECT i.*, u.uid AS customer_uid, o.order_uid, o.payment_source AS payment_method
         FROM invoices i
         INNER JOIN users u ON u.id = i.user_id
         LEFT JOIN orders o ON o.id = i.order_id
         WHERE i.order_id = ? LIMIT 1`,
        [id]
      ),
      query(
        `SELECT c.*, o.order_uid,
                eu.username AS earner_username, eu.full_name AS earner_name,
                su.username AS source_username, su.full_name AS source_name
         FROM commissions c
         LEFT JOIN orders o ON o.id = c.order_id
         LEFT JOIN users eu ON eu.id = c.earner_user_id
         LEFT JOIN users su ON su.id = c.source_user_id
         WHERE c.order_id = ?`,
        [id]
      )
    ]);
    res.json({
      success: true,
      data: {
        order: mapOrder(orderRow),
        items: [
          {
            id: orderRow.id,
            item_name: orderRow.product_name,
            quantity: Number(orderRow.quantity || 1),
            unit_price: fromPaisa(orderRow.unit_price_paisa),
            line_total: fromPaisa(orderRow.subtotal_paisa)
          }
        ],
        invoice: invRows[0] ? mapInvoice(invRows[0]) : null,
        commissions: commRows.map(mapCommission)
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.post("/orders", async (req, res, next) => {
  try {
    const user = req.user;
    const productId = sanitizeText(req.body?.product_id, 128);
    const quantity = Math.max(1, Math.min(50, Math.floor(Number(req.body?.quantity) || 1)));
    const notes = sanitizeText(req.body?.notes, 500);
    if (!productId) {
      res.status(400).json({ success: false, message: "Please select a service or product." });
      return;
    }
    const result = await withTransaction(async (conn) => {
      const settings = await getPlatformSettings(conn);
      const [prodRows] = await conn.execute(
        "SELECT * FROM catalog_products WHERE id = ? AND is_active = 1 LIMIT 1",
        [productId]
      );
      if (!prodRows.length) {
        throw Object.assign(new Error("Selected product or service is not available."), { status: 404 });
      }
      const product = prodRows[0];
      const unitPricePaisa = Number(product.price_paisa);
      const subtotalPaisa = unitPricePaisa * quantity;
      const totalPaisa = subtotalPaisa;
      const [wRows] = await conn.execute(
        "SELECT * FROM wallets WHERE user_id = ? FOR UPDATE",
        [user.id]
      );
      const wallet = wRows[0];
      if (!wallet || Number(wallet.balance_paisa) < totalPaisa) {
        throw Object.assign(new Error("Insufficient wallet balance. Please deposit funds first."), { status: 400 });
      }
      const balBefore = Number(wallet.balance_paisa);
      const balAfter = balBefore - totalPaisa;
      const spentAfter = Number(wallet.total_spent_paisa) + totalPaisa;
      await conn.execute(
        `UPDATE wallets SET balance_paisa = ?, total_spent_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
        [balAfter, spentAfter, user.id]
      );
      const orderId = genId("ord");
      const orderUid = genCode("ORD", 7);
      const invoiceId = genId("inv");
      const invoiceNumber = await nextInvoiceNumber(conn, settings.invoice_prefix || "GPBD-INV");
      await conn.execute(
        `INSERT INTO orders
           (id, order_uid, user_id, product_id, product_name, quantity, unit_price_paisa,
            subtotal_paisa, discount_paisa, fee_paisa, total_amount_paisa, payment_source, status, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, 'wallet', 'completed', ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [orderId, orderUid, user.id, product.id, product.name, quantity, unitPricePaisa, subtotalPaisa, totalPaisa, notes]
      );
      const itemsJson = JSON.stringify([
        {
          sku: product.sku,
          name: product.name,
          quantity,
          unit_price: fromPaisa(unitPricePaisa),
          subtotal: fromPaisa(subtotalPaisa)
        }
      ]);
      await conn.execute(
        `INSERT INTO invoices
           (id, invoice_number, order_id, user_id, customer_name, customer_email, customer_phone,
            items_json, subtotal_paisa, discount_paisa, fee_paisa, total_paisa, payment_status, issued_at, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, 'paid', UTC_TIMESTAMP(), ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [
          invoiceId,
          invoiceNumber,
          orderId,
          user.id,
          user.full_name,
          user.email,
          user.phone,
          itemsJson,
          subtotalPaisa,
          totalPaisa,
          notes
        ]
      );
      await insertWalletTransaction(conn, {
        userId: user.id,
        type: "order_payment",
        direction: "debit",
        amountPaisa: totalPaisa,
        balanceBeforePaisa: balBefore,
        balanceAfterPaisa: balAfter,
        referenceType: "order",
        referenceId: orderUid,
        paymentMethod: "wallet",
        description: `Order ${orderUid}: ${product.name} (x${quantity})`,
        status: "completed"
      });
      const commEnabled = settings.commission_enabled !== "false" && settings.referral_enabled !== "false";
      const minQualifyingPaisa = toPaisa(Number(settings.min_qualifying_order || 100));
      const commCapPaisa = toPaisa(Number(settings.commission_cap || 5e4));
      const autoCredit = (settings.commission_approval_mode || "auto") === "auto";
      const commType = settings.commission_type || "percentage";
      if (commEnabled && Boolean(product.commission_eligible) && totalPaisa >= minQualifyingPaisa) {
        const [refRows] = await conn.execute(
          `SELECT referrer_user_id, level FROM referrals WHERE referred_user_id = ? AND level IN (1, 2) ORDER BY level ASC`,
          [user.id]
        );
        for (const ref of refRows) {
          const earnerId = String(ref.referrer_user_id);
          if (earnerId === user.id) continue;
          const level = Number(ref.level);
          const rateVal = Number(level === 1 ? settings.level_1_commission || 7 : settings.level_2_commission || 3);
          if (rateVal <= 0) continue;
          let commPaisa = commType === "fixed" ? toPaisa(rateVal) : Math.round(totalPaisa * rateVal / 100);
          if (commCapPaisa > 0 && commPaisa > commCapPaisa) {
            commPaisa = commCapPaisa;
          }
          if (commPaisa <= 0) continue;
          const commId = genId("com");
          const commUid = genCode("COM", 7);
          await conn.execute(
            `INSERT INTO commissions
               (id, commission_uid, earner_user_id, source_user_id, order_id, level, rate_percent,
                base_amount_paisa, commission_amount_paisa, status, note, credited_at, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
            [
              commId,
              commUid,
              earnerId,
              user.id,
              orderId,
              level,
              rateVal,
              totalPaisa,
              commPaisa,
              autoCredit ? "credited" : "pending",
              `Level ${level} commission from order ${orderUid}`,
              autoCredit ? /* @__PURE__ */ new Date() : null
            ]
          );
          if (autoCredit) {
            const [ewRows] = await conn.execute(
              "SELECT * FROM wallets WHERE user_id = ? FOR UPDATE",
              [earnerId]
            );
            if (ewRows.length) {
              const eBalBefore = Number(ewRows[0].balance_paisa);
              const eBalAfter = eBalBefore + commPaisa;
              const eCommTotal = Number(ewRows[0].total_commission_paisa) + commPaisa;
              await conn.execute(
                `UPDATE wallets SET balance_paisa = ?, total_commission_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
                [eBalAfter, eCommTotal, earnerId]
              );
              await insertWalletTransaction(conn, {
                userId: earnerId,
                type: "referral_commission",
                direction: "credit",
                amountPaisa: commPaisa,
                balanceBeforePaisa: eBalBefore,
                balanceAfterPaisa: eBalAfter,
                referenceType: "commission",
                referenceId: commUid,
                description: `Level ${level} commission from @${user.username}'s order ${orderUid}`,
                status: "completed"
              });
            }
          }
          await createUserNotification(conn, {
            userId: earnerId,
            type: "commission",
            title: autoCredit ? `Commission Credited: \u09F3${fromPaisa(commPaisa)}` : `New Pending Commission: \u09F3${fromPaisa(commPaisa)}`,
            message: `Earned Level ${level} commission from order ${orderUid} by @${user.username}.`,
            link: "/dashboard/earnings"
          });
        }
      }
      const [freshOrder] = await conn.execute("SELECT * FROM orders WHERE id = ?", [orderId]);
      const [freshInv] = await conn.execute("SELECT * FROM invoices WHERE id = ?", [invoiceId]);
      return { order: freshOrder[0], invoice: freshInv[0] };
    });
    res.status(201).json({
      success: true,
      message: "Order placed and invoice generated successfully.",
      data: {
        order: mapOrder({ ...result.order, invoice_id: result.invoice.id, invoice_number: result.invoice.invoice_number }),
        invoice: mapInvoice(result.invoice)
      }
    });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router3.get("/invoices", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      `SELECT i.*, u.uid AS customer_uid, o.order_uid, o.payment_source AS payment_method
       FROM invoices i
       INNER JOIN users u ON u.id = i.user_id
       LEFT JOIN orders o ON o.id = i.order_id
       WHERE i.user_id = ?
       ORDER BY i.issued_at DESC LIMIT 100`,
      [userId]
    );
    res.json({ success: true, data: rows.map(mapInvoice) });
  } catch (err) {
    next(err);
  }
});
router3.get("/invoices/:id", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    const rows = await query(
      `SELECT i.*, u.uid AS customer_uid, o.order_uid, o.payment_source AS payment_method
       FROM invoices i
       INNER JOIN users u ON u.id = i.user_id
       LEFT JOIN orders o ON o.id = i.order_id
       WHERE i.id = ? AND i.user_id = ?
       LIMIT 1`,
      [id, userId]
    );
    if (!rows.length) {
      res.status(404).json({ success: false, message: "Invoice not found." });
      return;
    }
    const mapped = mapInvoice(rows[0]);
    res.json({ success: true, data: { invoice: mapped, items: mapped.items } });
  } catch (err) {
    next(err);
  }
});
router3.get("/notifications", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100",
      [userId]
    );
    const unread = rows.filter((n) => !n.is_read).length;
    res.json({
      success: true,
      data: {
        unread_count: unread,
        items: rows.map((n) => ({
          id: n.id,
          type: n.type,
          title: n.title,
          message: n.message,
          link: n.link || null,
          is_read: Boolean(n.is_read),
          created_at: toIso(n.created_at)
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.post("/notifications/read", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.body?.id, 128);
    if (id) {
      await execute("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", [id, userId]);
    } else {
      await execute("UPDATE notifications SET is_read = 1 WHERE user_id = ?", [userId]);
    }
    res.json({ success: true, message: "Notifications updated." });
  } catch (err) {
    next(err);
  }
});
router3.delete("/notifications/:id", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    await execute("DELETE FROM notifications WHERE id = ? AND user_id = ?", [id, userId]);
    res.json({ success: true, message: "Notification removed." });
  } catch (err) {
    next(err);
  }
});
router3.get("/support", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const rows = await query(
      "SELECT * FROM support_tickets WHERE user_id = ? ORDER BY updated_at DESC LIMIT 100",
      [userId]
    );
    res.json({
      success: true,
      data: rows.map((t) => ({
        id: t.id,
        ticket_uid: t.ticket_uid,
        subject: t.subject,
        category: t.category,
        priority: t.priority,
        status: t.status,
        created_at: toIso(t.created_at),
        updated_at: toIso(t.updated_at)
      }))
    });
  } catch (err) {
    next(err);
  }
});
router3.post("/support", supportAttachmentUpload.single("attachment"), async (req, res, next) => {
  try {
    const user = req.user;
    const subject = sanitizeText(req.body?.subject, 200);
    const category = sanitizeText(req.body?.category || "general", 64);
    const priorityRaw = sanitizeText(req.body?.priority || "medium", 16);
    const priority = ["low", "medium", "high", "urgent"].includes(priorityRaw) ? priorityRaw : "medium";
    const description = sanitizeText(req.body?.description, 3e3);
    if (subject.length < 3 || description.length < 5) {
      res.status(400).json({ success: false, message: "Subject and description are required." });
      return;
    }
    const attachmentUrl = toPublicUploadUrl("support", req.file?.filename);
    const ticketId = genId("tkt");
    const ticketUid = genCode("SUP", 6);
    await withTransaction(async (conn) => {
      await conn.execute(
        `INSERT INTO support_tickets (id, ticket_uid, user_id, subject, category, priority, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 'open', UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [ticketId, ticketUid, user.id, subject, category, priority]
      );
      await conn.execute(
        `INSERT INTO support_messages (id, ticket_id, sender_type, sender_id, sender_name, message, attachment_url, created_at)
         VALUES (?, ?, 'user', ?, ?, ?, ?, UTC_TIMESTAMP())`,
        [genId("smsg"), ticketId, user.id, user.full_name, description, attachmentUrl]
      );
      await createAdminNotification(conn, {
        type: "support",
        title: `New Support Ticket ${ticketUid}`,
        message: `${user.full_name} (@${user.username}): ${subject}`,
        link: "/admin/support"
      });
    });
    res.status(201).json({
      success: true,
      message: "Support ticket created.",
      data: { id: ticketId, ticket_uid: ticketUid }
    });
  } catch (err) {
    next(err);
  }
});
router3.get("/support/:id", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const id = sanitizeText(req.params.id, 128);
    const tickets = await query(
      "SELECT * FROM support_tickets WHERE id = ? AND user_id = ? LIMIT 1",
      [id, userId]
    );
    if (!tickets.length) {
      res.status(404).json({ success: false, message: "Support ticket not found." });
      return;
    }
    const msgs = await query(
      "SELECT * FROM support_messages WHERE ticket_id = ? ORDER BY created_at ASC",
      [id]
    );
    res.json({
      success: true,
      data: {
        ticket: {
          ...tickets[0],
          created_at: toIso(tickets[0].created_at),
          updated_at: toIso(tickets[0].updated_at)
        },
        messages: msgs.map((m) => ({
          id: m.id,
          sender_type: m.sender_type,
          sender_name: m.sender_name,
          message: m.message,
          attachment_url: m.attachment_url || null,
          created_at: toIso(m.created_at)
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.post("/support/:id/messages", supportAttachmentUpload.single("attachment"), async (req, res, next) => {
  try {
    const user = req.user;
    const id = sanitizeText(req.params.id, 128);
    const message = sanitizeText(req.body?.message, 3e3);
    if (!message) {
      res.status(400).json({ success: false, message: "Message cannot be empty." });
      return;
    }
    const tickets = await query(
      "SELECT id, status FROM support_tickets WHERE id = ? AND user_id = ? LIMIT 1",
      [id, user.id]
    );
    if (!tickets.length) {
      res.status(404).json({ success: false, message: "Support ticket not found." });
      return;
    }
    if (tickets[0].status === "closed") {
      res.status(400).json({ success: false, message: "This ticket is closed." });
      return;
    }
    const attachmentUrl = toPublicUploadUrl("support", req.file?.filename);
    await execute(
      `INSERT INTO support_messages (id, ticket_id, sender_type, sender_id, sender_name, message, attachment_url, created_at)
       VALUES (?, ?, 'user', ?, ?, ?, ?, UTC_TIMESTAMP())`,
      [genId("smsg"), id, user.id, user.full_name, message, attachmentUrl]
    );
    await execute("UPDATE support_tickets SET updated_at = UTC_TIMESTAMP() WHERE id = ?", [id]);
    res.status(201).json({ success: true, message: "Reply sent." });
  } catch (err) {
    next(err);
  }
});
router3.get("/profile", async (req, res, next) => {
  try {
    const user = req.user;
    const logs = await query(
      `SELECT id, ip_address, success, created_at
       FROM login_logs
       WHERE actor_type = 'user' AND actor_id = ?
       ORDER BY created_at DESC LIMIT 10`,
      [user.id]
    );
    res.json({
      success: true,
      data: {
        user: mapUserPublic(user),
        profile: {
          avatar_url: user.avatar_url || null,
          address: user.address || "",
          city: user.city || "",
          preferred_language: user.preferred_language || "en",
          notification_email: Boolean(user.notification_email),
          notification_inapp: Boolean(user.notification_inapp)
        },
        login_history: logs.map((l) => ({
          id: l.id,
          ip_address: l.ip_address,
          success: Boolean(l.success),
          created_at: toIso(l.created_at)
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router3.put("/profile", async (req, res, next) => {
  try {
    const user = req.user;
    const fullName = req.body?.full_name !== void 0 ? sanitizeText(req.body.full_name, 160) : user.full_name;
    const email = req.body?.email !== void 0 ? sanitizeText(req.body.email, 190).toLowerCase() : user.email;
    const phone = req.body?.phone !== void 0 ? sanitizeText(req.body.phone, 32) : user.phone;
    const address = req.body?.address !== void 0 ? sanitizeText(req.body.address, 255) : user.address;
    const city = req.body?.city !== void 0 ? sanitizeText(req.body.city, 120) : user.city;
    const prefLang = req.body?.preferred_language === "bn" ? "bn" : req.body?.preferred_language === "en" ? "en" : user.preferred_language;
    const notifEmail = req.body?.notification_email !== void 0 ? req.body.notification_email ? 1 : 0 : user.notification_email;
    const notifInapp = req.body?.notification_inapp !== void 0 ? req.body.notification_inapp ? 1 : 0 : user.notification_inapp;
    const sensitiveChanged = email !== user.email || phone !== user.phone;
    if (sensitiveChanged) {
      if (!isValidEmail(email)) {
        res.status(400).json({ success: false, message: "Invalid email address." });
        return;
      }
      if (phone && !isValidBdPhone(phone)) {
        res.status(400).json({ success: false, message: "Invalid Bangladesh phone number." });
        return;
      }
      const [uRow] = await query("SELECT password_hash FROM users WHERE id = ? LIMIT 1", [user.id]);
      if (uRow?.password_hash) {
        const currentPw = String(req.body?.current_password || "");
        const ok = await verifyPassword(currentPw, uRow.password_hash);
        if (!ok) {
          res.status(400).json({
            success: false,
            message: "Current password is required to update email or phone number."
          });
          return;
        }
      }
    }
    await execute(
      `UPDATE users
       SET full_name = ?, email = ?, phone = ?, address = ?, city = ?,
           preferred_language = ?, notification_email = ?, notification_inapp = ?, updated_at = UTC_TIMESTAMP()
       WHERE id = ?`,
      [fullName, email, phone, address, city, prefLang, notifEmail, notifInapp, user.id]
    );
    res.json({ success: true, message: "Profile updated successfully." });
  } catch (err) {
    if (err?.code === "ER_DUP_ENTRY") {
      res.status(409).json({ success: false, message: "That email address is already in use." });
      return;
    }
    next(err);
  }
});
router3.post("/profile/avatar", profileAvatarUpload.single("avatar"), async (req, res, next) => {
  try {
    if (!req.file) {
      res.status(400).json({ success: false, message: "Please upload a valid JPG, PNG, or WEBP image." });
      return;
    }
    const avatarUrl = toPublicUploadUrl("avatars", req.file.filename);
    await execute("UPDATE users SET avatar_url = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?", [
      avatarUrl,
      req.user.id
    ]);
    res.json({ success: true, message: "Profile photo updated.", data: { avatar_url: avatarUrl } });
  } catch (err) {
    next(err);
  }
});
router3.post("/profile/change-password", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const currentPassword = String(req.body?.current_password || "");
    const newPassword = String(req.body?.new_password || "");
    const confirmPassword = String(req.body?.confirm_password || "");
    if (newPassword.length < 8) {
      res.status(400).json({ success: false, message: "New password must be at least 8 characters long." });
      return;
    }
    if (newPassword !== confirmPassword) {
      res.status(400).json({ success: false, message: "New password and confirmation do not match." });
      return;
    }
    const rows = await query("SELECT password_hash FROM users WHERE id = ? LIMIT 1", [userId]);
    if (!rows.length) {
      res.status(404).json({ success: false, message: "User not found." });
      return;
    }
    if (rows[0].password_hash) {
      const ok = await verifyPassword(currentPassword, rows[0].password_hash);
      if (!ok) {
        res.status(400).json({ success: false, message: "Current password is incorrect." });
        return;
      }
    }
    const newHash = await hashPassword(newPassword);
    await execute(
      `UPDATE users SET password_hash = ?, password_reset_required = 0, updated_at = UTC_TIMESTAMP() WHERE id = ?`,
      [newHash, userId]
    );
    res.json({ success: true, message: "Password changed successfully." });
  } catch (err) {
    next(err);
  }
});
var userRoutes_default = router3;

// server/routes/adminRoutes.ts
import { Router as Router4 } from "express";
var router4 = Router4();
var PRIMARY_ADMIN_ID = "admin_primary";
async function ensurePrimaryAdminAccount() {
  const rows = await query(
    `SELECT a.*, r.slug AS role_slug, r.name AS role_name, r.permissions_json
     FROM admins a
     INNER JOIN admin_roles r ON r.id = a.role_id
     WHERE a.id = ? LIMIT 1`,
    [PRIMARY_ADMIN_ID]
  );
  if (rows.length > 0) return rows[0];
  const dummyHash = await hashPassword(genId("adm_init_pw"));
  await execute(
    `INSERT IGNORE INTO admins (id, admin_uid, full_name, email, password_hash, role_id, status, created_at, updated_at)
     VALUES (?, 'ADM-0001', 'GO PAY BD Control Admin', 'admin@gopaybd.local', ?, 1, 'active', UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
    [PRIMARY_ADMIN_ID, dummyHash]
  );
  const fresh = await query(
    `SELECT a.*, r.slug AS role_slug, r.name AS role_name, r.permissions_json
     FROM admins a
     INNER JOIN admin_roles r ON r.id = a.role_id
     WHERE a.id = ? LIMIT 1`,
    [PRIMARY_ADMIN_ID]
  );
  return fresh[0];
}
router4.get("/status", async (_req, res, next) => {
  try {
    const vaultRows = await query(
      `SELECT id FROM admin_security_vault WHERE id = 'master' LIMIT 1`
    );
    const hasVault = vaultRows.length > 0;
    const hasEnv = env.adminPassword.trim().length > 0;
    res.json({
      success: true,
      data: {
        setup_required: !hasVault && !hasEnv,
        has_admin: hasVault || hasEnv
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/auth/setup", adminLoginRateLimiter, async (req, res, next) => {
  try {
    const vaultRows = await query(
      `SELECT id FROM admin_security_vault WHERE id = 'master' LIMIT 1`
    );
    if (vaultRows.length > 0 || env.adminPassword.trim().length > 0) {
      res.status(403).json({
        success: false,
        message: "Admin password is already configured. Please unlock using your password."
      });
      return;
    }
    const password = String(req.body?.password || "").trim();
    if (password.length < 8) {
      res.status(400).json({
        success: false,
        message: "Initial Admin Password must be at least 8 characters long."
      });
      return;
    }
    const { salt, hash } = createVaultPasscodeHash(password);
    await execute(
      `INSERT INTO admin_security_vault (id, passcode_salt, passcode_hash, failed_attempts, updated_by_uid, updated_at)
       VALUES ('master', ?, ?, 0, ?, UTC_TIMESTAMP())`,
      [salt, hash, PRIMARY_ADMIN_ID]
    );
    const adminRow = await ensurePrimaryAdminAccount();
    await execute("UPDATE admins SET last_login_at = UTC_TIMESTAMP() WHERE id = ?", [adminRow.id]);
    const rawToken = await createDbSession(req, "admin", adminRow.id);
    setSessionCookie(req, res, ADMIN_COOKIE_NAME, rawToken);
    await recordLoginLog(req, "admin", adminRow.id, "initial_setup", true);
    res.status(201).json({
      success: true,
      message: "Admin Control Center password initialized.",
      data: {
        admin: {
          id: adminRow.id,
          admin_uid: adminRow.admin_uid,
          full_name: adminRow.full_name,
          email: adminRow.email,
          role_id: Number(adminRow.role_id),
          role_slug: adminRow.role_slug,
          role_name: adminRow.role_name,
          permissions: parsePermissions(adminRow.permissions_json)
        },
        session_token: rawToken
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/auth/login", adminLoginRateLimiter, async (req, res, next) => {
  try {
    const email = sanitizeText(req.body?.email, 190).toLowerCase();
    const password = String(req.body?.password || req.body?.passcode || "").trim();
    if (!password) {
      res.status(400).json({ success: false, message: "Admin password is required." });
      return;
    }
    if (email) {
      const staffRows = await query(
        `SELECT a.*, r.slug AS role_slug, r.name AS role_name, r.permissions_json
         FROM admins a
         INNER JOIN admin_roles r ON r.id = a.role_id
         WHERE LOWER(a.email) = ? LIMIT 1`,
        [email]
      );
      if (!staffRows.length) {
        await recordLoginLog(req, "admin", null, email, false);
        res.status(401).json({ success: false, message: "Invalid administrator credentials." });
        return;
      }
      const staff = staffRows[0];
      if (staff.status !== "active") {
        res.status(403).json({ success: false, message: "This administrator account is suspended." });
        return;
      }
      if (staff.locked_until && new Date(staff.locked_until).getTime() > Date.now()) {
        res.status(429).json({ success: false, message: "Account locked due to failed attempts. Wait 15 minutes." });
        return;
      }
      const ok = await verifyPassword(password, staff.password_hash);
      if (!ok) {
        const nextAttempts = Number(staff.failed_attempts || 0) + 1;
        await execute(
          `UPDATE admins SET failed_attempts = ?, locked_until = IF(?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE), locked_until) WHERE id = ?`,
          [nextAttempts, nextAttempts >= 5 ? 1 : 0, staff.id]
        );
        await recordLoginLog(req, "admin", staff.id, email, false);
        res.status(401).json({ success: false, message: "Invalid administrator credentials." });
        return;
      }
      await execute("UPDATE admins SET failed_attempts = 0, locked_until = NULL, last_login_at = UTC_TIMESTAMP() WHERE id = ?", [
        staff.id
      ]);
      const rawToken2 = await createDbSession(req, "admin", staff.id);
      setSessionCookie(req, res, ADMIN_COOKIE_NAME, rawToken2);
      await recordLoginLog(req, "admin", staff.id, email, true);
      res.json({
        success: true,
        message: "Control Center unlocked.",
        data: {
          admin: {
            id: staff.id,
            admin_uid: staff.admin_uid,
            full_name: staff.full_name,
            email: staff.email,
            role_id: Number(staff.role_id),
            role_slug: staff.role_slug,
            role_name: staff.role_name,
            permissions: parsePermissions(staff.permissions_json)
          },
          session_token: rawToken2
        }
      });
      return;
    }
    const vaultRows = await query(
      `SELECT * FROM admin_security_vault WHERE id = 'master' LIMIT 1`
    );
    const vault = vaultRows[0] || null;
    const hasEnvPassword = env.adminPassword.trim().length > 0;
    if (!vault && !hasEnvPassword) {
      res.status(400).json({
        success: false,
        code: "SETUP_REQUIRED",
        message: "No Admin Password is set yet. Please complete the initial setup."
      });
      return;
    }
    if (vault?.locked_until && new Date(vault.locked_until).getTime() > Date.now()) {
      res.status(429).json({
        success: false,
        message: "Control Center temporarily locked for 15 minutes after repeated failed attempts."
      });
      return;
    }
    let valid = false;
    if (vault) {
      valid = verifyVaultPasscode(password, vault.passcode_salt, vault.passcode_hash);
    } else if (hasEnvPassword) {
      valid = timingSafeStringEqual(password, env.adminPassword.trim());
    }
    if (!valid) {
      if (vault) {
        const nextAttempts = Number(vault.failed_attempts || 0) + 1;
        await execute(
          `UPDATE admin_security_vault
           SET failed_attempts = ?, locked_until = IF(?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE), locked_until)
           WHERE id = 'master'`,
          [nextAttempts, nextAttempts >= 5 ? 1 : 0]
        );
      }
      await recordLoginLog(req, "admin", PRIMARY_ADMIN_ID, "control_center_password", false);
      res.status(401).json({
        success: false,
        message: "\u09AD\u09C1\u09B2 \u0985\u09CD\u09AF\u09BE\u09A1\u09AE\u09BF\u09A8 \u09AA\u09BE\u09B8\u0993\u09AF\u09BC\u09BE\u09B0\u09CD\u09A1\u0964 \u09B8\u09A0\u09BF\u0995 \u09AA\u09BE\u09B8\u0993\u09AF\u09BC\u09BE\u09B0\u09CD\u09A1 \u09A6\u09BF\u09A8\u0964 (Incorrect admin password.)"
      });
      return;
    }
    if (vault) {
      await execute(
        `UPDATE admin_security_vault SET failed_attempts = 0, locked_until = NULL WHERE id = 'master'`
      );
    }
    const adminRow = await ensurePrimaryAdminAccount();
    await execute("UPDATE admins SET last_login_at = UTC_TIMESTAMP() WHERE id = ?", [adminRow.id]);
    const rawToken = await createDbSession(req, "admin", adminRow.id);
    setSessionCookie(req, res, ADMIN_COOKIE_NAME, rawToken);
    await recordLoginLog(req, "admin", adminRow.id, "control_center_password", true);
    res.json({
      success: true,
      message: "Control Center unlocked successfully.",
      data: {
        admin: {
          id: adminRow.id,
          admin_uid: adminRow.admin_uid,
          full_name: adminRow.full_name,
          email: adminRow.email,
          role_id: Number(adminRow.role_id),
          role_slug: adminRow.role_slug,
          role_name: adminRow.role_name,
          permissions: parsePermissions(adminRow.permissions_json)
        },
        session_token: rawToken
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/auth/logout", async (req, res, next) => {
  try {
    const rawCookie = req.cookies?.[ADMIN_COOKIE_NAME];
    const headerToken = typeof req.headers["x-admin-session"] === "string" ? req.headers["x-admin-session"] : void 0;
    await deleteDbSessionByRawToken(rawCookie || headerToken);
    clearSessionCookie(req, res, ADMIN_COOKIE_NAME);
    res.json({ success: true, message: "Signed out of Control Center." });
  } catch (err) {
    next(err);
  }
});
router4.get("/auth/me", async (req, res, next) => {
  try {
    const admin = await resolveAdminFromRequest(req);
    if (!admin) {
      res.status(401).json({ success: false, message: "Not authenticated as administrator." });
      return;
    }
    const notifRows = await query(
      "SELECT COUNT(*) AS cnt FROM admin_notifications WHERE is_read = 0"
    );
    res.json({
      success: true,
      data: {
        admin,
        unread_notifications: Number(notifRows[0]?.cnt || 0)
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.use(requireAdmin);
router4.post("/security/credentials", requirePermission("settings"), async (req, res, next) => {
  try {
    const currentPassword = String(req.body?.current_password || "").trim();
    const newPassword = String(req.body?.new_password || "").trim();
    if (newPassword.length < 8) {
      res.status(400).json({ success: false, message: "New Admin Password must be at least 8 characters." });
      return;
    }
    const vaultRows = await query(
      `SELECT * FROM admin_security_vault WHERE id = 'master' LIMIT 1`
    );
    const vault = vaultRows[0] || null;
    let verified = false;
    if (vault) {
      verified = verifyVaultPasscode(currentPassword, vault.passcode_salt, vault.passcode_hash);
    } else if (env.adminPassword.trim()) {
      verified = timingSafeStringEqual(currentPassword, env.adminPassword.trim());
    }
    if (!verified) {
      res.status(400).json({ success: false, message: "Current Admin Password is incorrect." });
      return;
    }
    const { salt, hash } = createVaultPasscodeHash(newPassword);
    await execute(
      `INSERT INTO admin_security_vault (id, passcode_salt, passcode_hash, failed_attempts, locked_until, updated_by_uid, updated_by_email, updated_at)
       VALUES ('master', ?, ?, 0, NULL, ?, ?, UTC_TIMESTAMP())
       ON DUPLICATE KEY UPDATE
         passcode_salt = VALUES(passcode_salt),
         passcode_hash = VALUES(passcode_hash),
         failed_attempts = 0,
         locked_until = NULL,
         updated_by_uid = VALUES(updated_by_uid),
         updated_by_email = VALUES(updated_by_email),
         updated_at = UTC_TIMESTAMP()`,
      [salt, hash, req.admin.id, req.admin.email]
    );
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "admin_password_rotated",
      entityType: "admin_security_vault",
      entityId: "master",
      newValues: { rotated: true }
    });
    res.json({ success: true, message: "Admin Control Center password updated successfully." });
  } catch (err) {
    next(err);
  }
});
router4.get("/dashboard", requirePermission("dashboard"), async (_req, res, next) => {
  try {
    const [
      userStats,
      depStats,
      wdStats,
      ordStats,
      commStats,
      pendingDeps,
      pendingWds,
      depDaily,
      wdDaily,
      ordDaily
    ] = await Promise.all([
      query(`
        SELECT
          COUNT(*) AS total_users,
          SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_users,
          SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspended_users,
          SUM(CASE WHEN created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR) THEN 1 ELSE 0 END) AS new_today
        FROM users
      `),
      query(`
        SELECT
          COALESCE(SUM(amount_paisa), 0) AS total_deposits,
          COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_paisa ELSE 0 END), 0) AS approved_deposits,
          COALESCE(SUM(CASE WHEN status IN ('pending','processing') THEN amount_paisa ELSE 0 END), 0) AS pending_deposits,
          SUM(CASE WHEN status IN ('pending','processing') THEN 1 ELSE 0 END) AS pending_count
        FROM deposits
      `),
      query(`
        SELECT
          COALESCE(SUM(CASE WHEN status = 'paid' THEN net_amount_paisa ELSE 0 END), 0) AS paid_withdrawals,
          COALESCE(SUM(CASE WHEN status = 'paid' THEN fee_paisa ELSE 0 END), 0) AS withdrawal_fees,
          COALESCE(SUM(CASE WHEN status IN ('pending','processing','approved') THEN amount_paisa ELSE 0 END), 0) AS pending_withdrawals,
          SUM(CASE WHEN status IN ('pending','processing','approved') THEN 1 ELSE 0 END) AS pending_count
        FROM withdrawals
      `),
      query(`
        SELECT
          COUNT(*) AS total_orders,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_orders,
          COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount_paisa ELSE 0 END), 0) AS completed_vol
        FROM orders
      `),
      query(`
        SELECT
          COALESCE(SUM(commission_amount_paisa), 0) AS total_comm,
          COALESCE(SUM(CASE WHEN status = 'credited' THEN commission_amount_paisa ELSE 0 END), 0) AS paid_comm,
          COALESCE(SUM(CASE WHEN status IN ('pending','approved') THEN commission_amount_paisa ELSE 0 END), 0) AS pending_comm
        FROM commissions
      `),
      query(`
        SELECT d.*, u.full_name, u.username, u.uid AS user_uid
        FROM deposits d
        INNER JOIN users u ON u.id = d.user_id
        WHERE d.status IN ('pending','processing')
        ORDER BY d.created_at DESC LIMIT 8
      `),
      query(`
        SELECT w.*, u.full_name, u.username, u.uid AS user_uid
        FROM withdrawals w
        INNER JOIN users u ON u.id = w.user_id
        WHERE w.status IN ('pending','processing','approved')
        ORDER BY w.created_at DESC LIMIT 8
      `),
      query(`
        SELECT DATE_FORMAT(created_at, '%Y-%m-%d') AS d, COALESCE(SUM(amount_paisa), 0) AS total
        FROM deposits WHERE status = 'approved' AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 14 DAY)
        GROUP BY d
      `),
      query(`
        SELECT DATE_FORMAT(created_at, '%Y-%m-%d') AS d, COALESCE(SUM(net_amount_paisa), 0) AS total
        FROM withdrawals WHERE status = 'paid' AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 14 DAY)
        GROUP BY d
      `),
      query(`
        SELECT DATE_FORMAT(created_at, '%Y-%m-%d') AS d, COALESCE(SUM(total_amount_paisa), 0) AS total
        FROM orders WHERE status = 'completed' AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 14 DAY)
        GROUP BY d
      `)
    ]);
    const orderVol = Number(ordStats[0]?.completed_vol || 0);
    const wdFees = Number(wdStats[0]?.withdrawal_fees || 0);
    const paidComm = Number(commStats[0]?.paid_comm || 0);
    const revenuePaisa = Math.max(0, orderVol + wdFees - paidComm);
    const depMap = new Map(depDaily.map((r) => [String(r.d), fromPaisa(r.total)]));
    const wdMap = new Map(wdDaily.map((r) => [String(r.d), fromPaisa(r.total)]));
    const ordMap = new Map(ordDaily.map((r) => [String(r.d), fromPaisa(r.total)]));
    const charts = [];
    for (let i = 13; i >= 0; i--) {
      const dt = new Date(Date.now() - i * 864e5);
      const iso = dt.toISOString().slice(0, 10);
      const ordVal = ordMap.get(iso) || 0;
      charts.push({
        date: iso.slice(5),
        deposits: depMap.get(iso) || 0,
        withdrawals: wdMap.get(iso) || 0,
        orders: ordVal,
        revenue: ordVal
      });
    }
    res.json({
      success: true,
      data: {
        metrics: {
          platform_revenue: fromPaisa(revenuePaisa),
          total_deposits: fromPaisa(depStats[0]?.total_deposits),
          total_approved_deposits: fromPaisa(depStats[0]?.approved_deposits),
          pending_deposits: fromPaisa(depStats[0]?.pending_deposits),
          pending_deposits_count: Number(depStats[0]?.pending_count || 0),
          paid_withdrawals: fromPaisa(wdStats[0]?.paid_withdrawals),
          pending_withdrawals: fromPaisa(wdStats[0]?.pending_withdrawals),
          pending_withdrawals_count: Number(wdStats[0]?.pending_count || 0),
          total_users: Number(userStats[0]?.total_users || 0),
          active_users: Number(userStats[0]?.active_users || 0),
          suspended_users: Number(userStats[0]?.suspended_users || 0),
          new_users_today: Number(userStats[0]?.new_today || 0),
          total_orders: Number(ordStats[0]?.total_orders || 0),
          completed_orders: Number(ordStats[0]?.completed_orders || 0),
          total_commission: fromPaisa(commStats[0]?.total_comm),
          paid_commission: fromPaisa(paidComm),
          pending_commission: fromPaisa(commStats[0]?.pending_comm)
        },
        charts,
        queues: {
          pending_deposits: pendingDeps.map(mapDeposit),
          pending_withdrawals: pendingWds.map(mapWithdrawal)
        }
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/users", requirePermission("users"), async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 25));
    const offset = (page - 1) * limit;
    const where = ["1=1"];
    const params = [];
    const search = sanitizeText(req.query.search, 120);
    if (search) {
      where.push("(u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR u.uid LIKE ? OR u.referral_code LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like, like, like, like);
    }
    const status = sanitizeText(req.query.status, 32);
    if (status && status !== "all") {
      where.push("u.status = ?");
      params.push(status);
    }
    const minBal = req.query.min_balance !== void 0 && req.query.min_balance !== "" ? Number(req.query.min_balance) : null;
    if (minBal !== null && Number.isFinite(minBal)) {
      where.push("COALESCE(w.balance_paisa, 0) >= ?");
      params.push(toPaisa(minBal));
    }
    const dateFrom = sanitizeText(req.query.date_from, 20);
    if (dateFrom) {
      where.push("DATE(u.created_at) >= ?");
      params.push(dateFrom);
    }
    const whereSql = where.join(" AND ");
    const [countRows, rows] = await Promise.all([
      query(
        `SELECT COUNT(*) AS cnt FROM users u LEFT JOIN wallets w ON w.user_id = u.id WHERE ${whereSql}`,
        params
      ),
      query(
        `SELECT u.*,
                COALESCE(w.balance_paisa, 0) AS balance_paisa,
                COALESCE(w.locked_balance_paisa, 0) AS locked_balance_paisa,
                COALESCE(w.total_deposited_paisa, 0) AS total_deposited_paisa,
                COALESCE(w.total_withdrawn_paisa, 0) AS total_withdrawn_paisa,
                COALESCE(w.total_commission_paisa, 0) AS total_commission_paisa
         FROM users u
         LEFT JOIN wallets w ON w.user_id = u.id
         WHERE ${whereSql}
         ORDER BY u.created_at DESC
         LIMIT ${limit} OFFSET ${offset}`,
        params
      )
    ]);
    const total = Number(countRows[0]?.cnt || 0);
    res.json({
      success: true,
      data: {
        items: rows.map((u) => ({
          ...mapUserPublic(u),
          wallet_balance: fromPaisa(u.balance_paisa),
          locked_balance: fromPaisa(u.locked_balance_paisa),
          total_deposited: fromPaisa(u.total_deposited_paisa),
          total_withdrawn: fromPaisa(u.total_withdrawn_paisa),
          total_commission: fromPaisa(u.total_commission_paisa)
        })),
        pagination: { page, limit, total, total_pages: Math.max(1, Math.ceil(total / limit)) }
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/users/:id", requirePermission("users"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const users = await query(
      `SELECT u.*, su.uid AS sponsor_uid
       FROM users u
       LEFT JOIN users su ON su.id = u.referred_by
       WHERE u.id = ? LIMIT 1`,
      [id]
    );
    if (!users.length) {
      res.status(404).json({ success: false, message: "User not found." });
      return;
    }
    const [walletRows, pendingCommRows, deps, wds, ords, comms, txs, pms, refs, loginLogs, auditLogs] = await Promise.all([
      query("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [id]),
      query(
        `SELECT COALESCE(SUM(commission_amount_paisa), 0) AS total
         FROM commissions WHERE earner_user_id = ? AND status IN ('pending','approved')`,
        [id]
      ),
      query(
        `SELECT d.*, adm.full_name AS reviewed_by_name
         FROM deposits d
         LEFT JOIN admins adm ON adm.id = d.reviewed_by
         WHERE d.user_id = ? ORDER BY d.created_at DESC LIMIT 50`,
        [id]
      ),
      query("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 50", [id]),
      query(
        `SELECT o.*, i.id AS invoice_id, i.invoice_number,
                COALESCE(
                  (SELECT c.status FROM commissions c WHERE c.order_id = o.id ORDER BY c.created_at DESC LIMIT 1),
                  'none'
                ) AS commission_status
         FROM orders o
         LEFT JOIN invoices i ON i.order_id = o.id
         WHERE o.user_id = ? ORDER BY o.created_at DESC LIMIT 50`,
        [id]
      ),
      query(
        `SELECT c.*, o.order_uid,
                eu.username AS earner_username, eu.full_name AS earner_name,
                su.username AS source_username, su.full_name AS source_name
         FROM commissions c
         LEFT JOIN orders o ON o.id = c.order_id
         LEFT JOIN users eu ON eu.id = c.earner_user_id
         LEFT JOIN users su ON su.id = c.source_user_id
         WHERE c.earner_user_id = ? ORDER BY c.created_at DESC LIMIT 50`,
        [id]
      ),
      query("SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50", [id]),
      query(`SELECT * FROM payment_methods WHERE user_id = ? AND status != 'deleted'`, [id]),
      query(
        `SELECT r.*, u.uid AS user_uid, u.full_name, u.username, u.status AS user_status
         FROM referrals r INNER JOIN users u ON u.id = r.referred_user_id
         WHERE r.referrer_user_id = ? ORDER BY r.created_at DESC`,
        [id]
      ),
      query(
        `SELECT id, ip_address, success, created_at
         FROM login_logs WHERE actor_type = 'user' AND actor_id = ?
         ORDER BY created_at DESC LIMIT 30`,
        [id]
      ),
      query(
        `SELECT id, actor_name, action, entity_type, entity_id, old_values, new_values, ip_address, created_at
         FROM audit_logs WHERE entity_id = ? OR (entity_type IN ('user','wallet') AND entity_id = ?)
         ORDER BY created_at DESC LIMIT 30`,
        [id, id]
      )
    ]);
    res.json({
      success: true,
      data: {
        user: {
          ...mapUserPublic(users[0]),
          address: users[0].address || "",
          city: users[0].city || ""
        },
        wallet: mapWallet(walletRows[0] || { user_id: id }, {
          pendingCommissionPaisa: pendingCommRows[0]?.total
        }),
        deposits: deps.map(mapDeposit),
        withdrawals: wds.map(mapWithdrawal),
        orders: ords.map(mapOrder),
        commissions: comms.map(mapCommission),
        transactions: txs.map(mapTransaction),
        payment_methods: pms.map(mapPaymentMethod),
        referrals: refs.map((r) => ({
          id: r.id,
          user_uid: r.user_uid,
          full_name: r.full_name,
          username: r.username,
          level: Number(r.level),
          status: r.user_status,
          user_status: r.user_status,
          created_at: toIso(r.created_at)
        })),
        activity_logs: loginLogs.map((l) => ({
          id: l.id,
          ip_address: l.ip_address,
          success: Boolean(l.success),
          created_at: toIso(l.created_at)
        })),
        audit_logs: auditLogs.map((a) => ({
          id: a.id,
          actor_name: a.actor_name,
          action: a.action,
          entity_type: a.entity_type,
          entity_id: a.entity_id,
          old_values: a.old_values,
          new_values: a.new_values,
          ip_address: a.ip_address,
          created_at: toIso(a.created_at)
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.put("/users/:id", requirePermission("users"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const existing = await query("SELECT * FROM users WHERE id = ? LIMIT 1", [id]);
    if (!existing.length) {
      res.status(404).json({ success: false, message: "User not found." });
      return;
    }
    const cur = existing[0];
    const fullName = req.body?.full_name !== void 0 ? sanitizeText(req.body.full_name, 160) : cur.full_name;
    const email = req.body?.email !== void 0 ? sanitizeText(req.body.email, 190).toLowerCase() : cur.email;
    const phone = req.body?.phone !== void 0 ? sanitizeText(req.body.phone, 32) : cur.phone;
    const adminNote = req.body?.admin_note !== void 0 ? sanitizeText(req.body.admin_note, 1e3) : cur.admin_note || "";
    const statusRaw = req.body?.status !== void 0 ? sanitizeText(req.body.status, 32) : cur.status;
    const status = ["active", "suspended", "pending"].includes(statusRaw) ? statusRaw : cur.status;
    const newPassword = req.body?.new_password ? String(req.body.new_password) : "";
    if (email !== cur.email && !isValidEmail(email)) {
      res.status(400).json({ success: false, message: "Please provide a valid email address." });
      return;
    }
    if (newPassword && newPassword.length < 8) {
      res.status(400).json({ success: false, message: "New user password must be at least 8 characters." });
      return;
    }
    if (newPassword) {
      const pwHash = await hashPassword(newPassword);
      await execute(
        `UPDATE users SET full_name = ?, email = ?, phone = ?, status = ?, admin_note = ?, password_hash = ?, password_reset_required = 0, updated_at = UTC_TIMESTAMP() WHERE id = ?`,
        [fullName, email, phone, status, adminNote, pwHash, id]
      );
    } else {
      await execute(
        `UPDATE users SET full_name = ?, email = ?, phone = ?, status = ?, admin_note = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?`,
        [fullName, email, phone, status, adminNote, id]
      );
    }
    if (status === "suspended") {
      await execute(`DELETE FROM sessions WHERE actor_type = 'user' AND actor_id = ?`, [id]);
    }
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "user_updated",
      entityType: "user",
      entityId: id,
      oldValues: { full_name: cur.full_name, email: cur.email, phone: cur.phone, status: cur.status, admin_note: cur.admin_note || "" },
      newValues: { full_name: fullName, email, phone, status, admin_note: adminNote, password_reset: Boolean(newPassword) }
    });
    res.json({ success: true, message: "User account updated successfully." });
  } catch (err) {
    if (err?.code === "ER_DUP_ENTRY") {
      res.status(409).json({ success: false, message: "That email address is already registered to another user." });
      return;
    }
    next(err);
  }
});
router4.post("/users/:id/reset-password", requirePermission("users"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const newPassword = String(req.body?.new_password || "");
    if (newPassword.length < 8) {
      res.status(400).json({ success: false, message: "New password must be at least 8 characters long." });
      return;
    }
    const existing = await query("SELECT id, uid FROM users WHERE id = ? LIMIT 1", [id]);
    if (!existing.length) {
      res.status(404).json({ success: false, message: "User not found." });
      return;
    }
    const pwHash = await hashPassword(newPassword);
    await execute(
      `UPDATE users
       SET password_hash = ?, password_reset_required = 0, failed_attempts = 0, locked_until = NULL, updated_at = UTC_TIMESTAMP()
       WHERE id = ?`,
      [pwHash, id]
    );
    await execute(`DELETE FROM sessions WHERE actor_type = 'user' AND actor_id = ?`, [id]);
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "user_password_reset_by_admin",
      entityType: "user",
      entityId: id,
      newValues: { password_reset: true, sessions_revoked: true }
    });
    res.json({ success: true, message: "User password reset and active sessions revoked." });
  } catch (err) {
    next(err);
  }
});
router4.post("/users/:id/balance-adjust", requirePermission("wallets"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const directionRaw = sanitizeText(req.body?.direction || "credit", 16);
    const amount = Number(req.body?.amount);
    const asCommission = Boolean(req.body?.as_commission);
    const reason = sanitizeText(req.body?.reason || "Admin balance adjustment", 400);
    if (!["credit", "debit", "set"].includes(directionRaw) || !Number.isFinite(amount) || amount < 0) {
      res.status(400).json({ success: false, message: "Provide a valid direction (credit/debit/set) and non-negative amount." });
      return;
    }
    const updated = await withTransaction(async (conn) => {
      const [uRows] = await conn.execute("SELECT id, full_name, username FROM users WHERE id = ? LIMIT 1", [id]);
      if (!uRows.length) throw Object.assign(new Error("User not found."), { status: 404 });
      const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [id]);
      if (!wRows.length) throw Object.assign(new Error("Wallet not found."), { status: 404 });
      const wallet = wRows[0];
      const before = Number(wallet.balance_paisa);
      const amtPaisa = toPaisa(amount);
      let after = before;
      let ledgerDir = "credit";
      let deltaPaisa = amtPaisa;
      if (directionRaw === "credit") {
        after = before + amtPaisa;
        ledgerDir = "credit";
      } else if (directionRaw === "debit") {
        if (before < amtPaisa) {
          throw Object.assign(new Error("Cannot debit more than user available balance."), { status: 400 });
        }
        after = before - amtPaisa;
        ledgerDir = "debit";
      } else {
        after = amtPaisa;
        deltaPaisa = Math.abs(after - before);
        ledgerDir = after >= before ? "credit" : "debit";
      }
      let nextTotalComm = Number(wallet.total_commission_paisa);
      if (asCommission) {
        nextTotalComm = ledgerDir === "credit" ? nextTotalComm + deltaPaisa : Math.max(0, nextTotalComm - deltaPaisa);
      }
      await conn.execute(
        `UPDATE wallets SET balance_paisa = ?, total_commission_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
        [after, nextTotalComm, id]
      );
      await insertWalletTransaction(conn, {
        userId: id,
        type: asCommission ? "admin_commission_adjustment" : "admin_adjustment",
        direction: ledgerDir,
        amountPaisa: deltaPaisa,
        balanceBeforePaisa: before,
        balanceAfterPaisa: after,
        referenceType: "admin_adjustment",
        referenceId: req.admin.admin_uid,
        description: reason,
        status: "completed",
        createdByAdminId: req.admin.id
      });
      if (asCommission && deltaPaisa > 0) {
        await conn.execute(
          `INSERT INTO commissions
             (id, commission_uid, earner_user_id, source_user_id, order_id, level, rate_percent,
              base_amount_paisa, commission_amount_paisa, status, note, credited_at, created_at, updated_at)
           VALUES (?, ?, ?, ?, NULL, 1, 0, ?, ?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
          [
            genId("com"),
            genCode("COM", 7),
            id,
            id,
            deltaPaisa,
            deltaPaisa,
            ledgerDir === "credit" ? "credited" : "reversed",
            reason
          ]
        );
      }
      await createUserNotification(conn, {
        userId: id,
        type: "wallet",
        title: ledgerDir === "credit" ? "Wallet Balance Credited" : "Wallet Balance Adjusted",
        message: `${reason} \xB7 New Balance: \u09F3${fromPaisa(after).toFixed(2)}`,
        link: "/dashboard/wallet"
      });
      const [fresh] = await conn.execute("SELECT * FROM wallets WHERE user_id = ?", [id]);
      return { before, after, wallet: fresh[0] };
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "wallet_balance_adjusted",
      entityType: "wallet",
      entityId: id,
      oldValues: { balance: fromPaisa(updated.before) },
      newValues: { balance: fromPaisa(updated.after), direction: directionRaw, as_commission: asCommission, reason }
    });
    res.json({
      success: true,
      message: `Wallet updated to \u09F3${fromPaisa(updated.after).toFixed(2)}.`,
      data: mapWallet(updated.wallet)
    });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.put("/users/:id/wallet-direct", requirePermission("wallets"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const reason = sanitizeText(req.body?.reason || "Admin direct wallet override", 400);
    const updated = await withTransaction(async (conn) => {
      const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [id]);
      if (!wRows.length) throw Object.assign(new Error("Wallet not found."), { status: 404 });
      const cur = wRows[0];
      const balVal = req.body?.available_balance ?? req.body?.balance;
      const lockedVal = req.body?.pending_withdrawal ?? req.body?.locked_balance;
      const depVal = req.body?.total_deposits ?? req.body?.total_deposited;
      const wdVal = req.body?.total_withdrawals ?? req.body?.total_withdrawn;
      const commVal = req.body?.total_commission ?? req.body?.total_earnings;
      const nextBal = balVal !== void 0 ? Math.max(0, toPaisa(balVal)) : Number(cur.balance_paisa);
      const nextLocked = lockedVal !== void 0 ? Math.max(0, toPaisa(lockedVal)) : Number(cur.locked_balance_paisa);
      const nextDep = depVal !== void 0 ? Math.max(0, toPaisa(depVal)) : Number(cur.total_deposited_paisa);
      const nextWd = wdVal !== void 0 ? Math.max(0, toPaisa(wdVal)) : Number(cur.total_withdrawn_paisa);
      const nextComm = commVal !== void 0 ? Math.max(0, toPaisa(commVal)) : Number(cur.total_commission_paisa);
      await conn.execute(
        `UPDATE wallets
         SET balance_paisa = ?, locked_balance_paisa = ?, total_deposited_paisa = ?,
             total_withdrawn_paisa = ?, total_commission_paisa = ?, updated_at = UTC_TIMESTAMP()
         WHERE user_id = ?`,
        [nextBal, nextLocked, nextDep, nextWd, nextComm, id]
      );
      if (nextBal !== Number(cur.balance_paisa)) {
        const diff = Math.abs(nextBal - Number(cur.balance_paisa));
        await insertWalletTransaction(conn, {
          userId: id,
          type: "admin_adjustment",
          direction: nextBal >= Number(cur.balance_paisa) ? "credit" : "debit",
          amountPaisa: diff,
          balanceBeforePaisa: Number(cur.balance_paisa),
          balanceAfterPaisa: nextBal,
          referenceType: "wallet_direct",
          referenceId: req.admin.admin_uid,
          description: reason,
          status: "completed",
          createdByAdminId: req.admin.id
        });
      }
      const [fresh] = await conn.execute("SELECT * FROM wallets WHERE user_id = ?", [id]);
      return { oldWallet: cur, newWallet: fresh[0] };
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "wallet_direct_updated",
      entityType: "wallet",
      entityId: id,
      oldValues: mapWallet(updated.oldWallet),
      newValues: { ...mapWallet(updated.newWallet), reason }
    });
    res.json({ success: true, message: "Wallet figures saved successfully.", data: mapWallet(updated.newWallet) });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.post("/users/:id/commission-adjust", requirePermission("wallets"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const amount = Number(req.body?.amount);
    const action = sanitizeText(req.body?.action || "grant", 24);
    const level = Math.max(1, Math.min(2, Number(req.body?.referral_level || req.body?.level || 1)));
    const reqStatus = sanitizeText(req.body?.status || "", 24).toLowerCase();
    const isPending = reqStatus === "pending" || req.body?.credit_wallet === false;
    const isDebit = action === "deduct" || action === "reverse";
    const note = sanitizeText(req.body?.admin_note || req.body?.note || "Admin commission grant", 400);
    if (!Number.isFinite(amount) || amount <= 0) {
      res.status(400).json({ success: false, message: "Commission amount must be greater than zero." });
      return;
    }
    const amtPaisa = toPaisa(amount);
    await withTransaction(async (conn) => {
      const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [id]);
      if (!wRows.length) throw Object.assign(new Error("Wallet not found."), { status: 404 });
      const wallet = wRows[0];
      const commId = genId("com");
      const commUid = genCode("COM", 7);
      const commStatus = isDebit ? "reversed" : isPending ? "pending" : "credited";
      await conn.execute(
        `INSERT INTO commissions
           (id, commission_uid, earner_user_id, source_user_id, order_id, level, rate_percent,
            base_amount_paisa, commission_amount_paisa, status, note, credited_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, NULL, ?, 0, ?, ?, ?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
        [
          commId,
          commUid,
          id,
          id,
          level,
          amtPaisa,
          amtPaisa,
          commStatus,
          note,
          commStatus === "credited" ? /* @__PURE__ */ new Date() : null
        ]
      );
      if (!isPending || isDebit) {
        const balBefore = Number(wallet.balance_paisa);
        const balAfter = isDebit ? Math.max(0, balBefore - amtPaisa) : balBefore + amtPaisa;
        const nextTotalComm = isDebit ? Math.max(0, Number(wallet.total_commission_paisa) - amtPaisa) : Number(wallet.total_commission_paisa) + amtPaisa;
        await conn.execute(
          `UPDATE wallets SET balance_paisa = ?, total_commission_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
          [balAfter, nextTotalComm, id]
        );
        await insertWalletTransaction(conn, {
          userId: id,
          type: "admin_commission_adjustment",
          direction: isDebit ? "debit" : "credit",
          amountPaisa: amtPaisa,
          balanceBeforePaisa: balBefore,
          balanceAfterPaisa: balAfter,
          referenceType: "commission",
          referenceId: commUid,
          description: note,
          status: "completed",
          createdByAdminId: req.admin.id
        });
      }
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "commission_manual_adjust",
      entityType: "user",
      entityId: id,
      newValues: { action, level, status: isDebit ? "reversed" : isPending ? "pending" : "credited", amount, note }
    });
    res.json({ success: true, message: "User commission updated successfully." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.get("/deposits", requirePermission("deposits"), async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 25));
    const offset = (page - 1) * limit;
    const where = ["1=1"];
    const params = [];
    const status = sanitizeText(req.query.status, 32);
    if (status && status !== "all") {
      where.push("d.status = ?");
      params.push(status);
    }
    const method = sanitizeText(req.query.payment_method || req.query.method, 64);
    if (method && method !== "all") {
      where.push("d.payment_method = ?");
      params.push(method);
    }
    const dateFrom = sanitizeText(req.query.date_from, 20);
    if (dateFrom) {
      where.push("DATE(d.created_at) >= ?");
      params.push(dateFrom);
    }
    const search = sanitizeText(req.query.search, 120);
    if (search) {
      where.push(
        "(d.deposit_uid LIKE ? OR d.transaction_id LIKE ? OR d.sender_number LIKE ? OR d.receiver_number LIKE ? OR u.username LIKE ? OR u.uid LIKE ?)"
      );
      const like = `%${search}%`;
      params.push(like, like, like, like, like, like);
    }
    const whereSql = where.join(" AND ");
    const [countRows, rows] = await Promise.all([
      query(
        `SELECT COUNT(*) AS cnt FROM deposits d INNER JOIN users u ON u.id = d.user_id WHERE ${whereSql}`,
        params
      ),
      query(
        `SELECT d.*, u.full_name, u.username, u.uid AS user_uid, u.email,
                adm.full_name AS reviewed_by_name
         FROM deposits d
         INNER JOIN users u ON u.id = d.user_id
         LEFT JOIN admins adm ON adm.id = d.reviewed_by
         WHERE ${whereSql}
         ORDER BY d.created_at DESC
         LIMIT ${limit} OFFSET ${offset}`,
        params
      )
    ]);
    const total = Number(countRows[0]?.cnt || 0);
    res.json({
      success: true,
      data: {
        items: rows.map(mapDeposit),
        pagination: { page, limit, total, total_pages: Math.max(1, Math.ceil(total / limit)) }
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/deposits/:id/processing", requirePermission("deposits"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const etaRaw = sanitizeText(req.body?.eta_hours || "", 24);
    const processingEta = etaRaw === "12" ? "Within 12 Hours" : etaRaw === "24" ? "Within 24 Hours" : etaRaw === "12-24" ? "Within 12\u201324 Hours" : sanitizeText(req.body?.processing_eta || "Within 12\u201324 Hours", 120);
    const noteInput = sanitizeText(req.body?.admin_note || "", 500);
    const note = noteInput || `Payment verification in progress (${processingEta}).`;
    const existing = await query("SELECT * FROM deposits WHERE id = ? LIMIT 1", [id]);
    if (!existing.length) {
      res.status(404).json({ success: false, message: "Deposit not found." });
      return;
    }
    const cur = existing[0];
    if (cur.status !== "pending" && cur.status !== "processing") {
      res.status(400).json({ success: false, message: "Only pending or processing deposits can update processing ETA." });
      return;
    }
    await execute(
      `UPDATE deposits SET status = 'processing', admin_note = ?, processing_eta = ?, reviewed_by = ?, updated_at = UTC_TIMESTAMP()
       WHERE id = ?`,
      [note, processingEta, req.admin.id, id]
    );
    await createUserNotification(null, {
      userId: cur.user_id,
      type: "deposit",
      title: `Deposit Processing (${cur.deposit_uid})`,
      message: `${note} (${processingEta})`,
      link: "/dashboard/deposit"
    });
    res.json({ success: true, message: `Deposit marked as processing (${processingEta}).` });
  } catch (err) {
    next(err);
  }
});
router4.post("/deposits/:id/approve", requirePermission("deposits"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const adminNote = sanitizeText(req.body?.admin_note || "Verified and approved", 500);
    const dep = await withTransaction(async (conn) => {
      const [depRows] = await conn.execute("SELECT * FROM deposits WHERE id = ? FOR UPDATE", [id]);
      if (!depRows.length) throw Object.assign(new Error("Deposit not found."), { status: 404 });
      const d = depRows[0];
      if (d.status !== "pending" && d.status !== "processing") {
        throw Object.assign(new Error("This deposit has already been finalized."), { status: 400 });
      }
      const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
        d.user_id
      ]);
      const wallet = wRows[0];
      const amtPaisa = Number(d.amount_paisa);
      const balBefore = Number(wallet.balance_paisa);
      const balAfter = balBefore + amtPaisa;
      const totalDepAfter = Number(wallet.total_deposited_paisa) + amtPaisa;
      await conn.execute(
        `UPDATE wallets SET balance_paisa = ?, total_deposited_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
        [balAfter, totalDepAfter, d.user_id]
      );
      await conn.execute(
        `UPDATE deposits SET status = 'approved', admin_note = ?, reviewed_by = ?, reviewed_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP() WHERE id = ?`,
        [adminNote, req.admin.id, id]
      );
      await insertWalletTransaction(conn, {
        userId: d.user_id,
        type: "deposit",
        direction: "credit",
        amountPaisa: amtPaisa,
        balanceBeforePaisa: balBefore,
        balanceAfterPaisa: balAfter,
        referenceType: "deposit",
        referenceId: d.deposit_uid,
        paymentMethod: d.payment_method,
        senderNumber: d.sender_number,
        receiverNumber: d.receiver_number,
        description: `Approved ${d.payment_method} deposit (${d.transaction_id})`,
        status: "completed",
        createdByAdminId: req.admin.id
      });
      await createUserNotification(conn, {
        userId: d.user_id,
        type: "deposit",
        title: `Deposit Approved: \u09F3${fromPaisa(amtPaisa).toFixed(2)}`,
        message: `Your ${d.payment_method} deposit (TrxID: ${d.transaction_id}) has been verified and credited to your wallet.`,
        link: "/dashboard/wallet"
      });
      return d;
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "deposit_approved",
      entityType: "deposit",
      entityId: id,
      newValues: { amount: fromPaisa(dep.amount_paisa), trx_id: dep.transaction_id, admin_note: adminNote }
    });
    res.json({ success: true, message: "Deposit approved and user wallet credited." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.post("/deposits/:id/reject", requirePermission("deposits"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const adminNote = sanitizeText(req.body?.reason || req.body?.admin_note || "Payment verification failed", 500);
    const dep = await withTransaction(async (conn) => {
      const [depRows] = await conn.execute("SELECT * FROM deposits WHERE id = ? FOR UPDATE", [id]);
      if (!depRows.length) throw Object.assign(new Error("Deposit not found."), { status: 404 });
      const d = depRows[0];
      if (d.status !== "pending" && d.status !== "processing") {
        throw Object.assign(new Error("This deposit has already been finalized."), { status: 400 });
      }
      await conn.execute(
        `UPDATE deposits SET status = 'rejected', admin_note = ?, reviewed_by = ?, reviewed_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP() WHERE id = ?`,
        [adminNote, req.admin.id, id]
      );
      await conn.execute("DELETE FROM deposit_transaction_locks WHERE deposit_id = ?", [id]);
      await createUserNotification(conn, {
        userId: d.user_id,
        type: "deposit",
        title: `Deposit Rejected (${d.deposit_uid})`,
        message: `Your deposit of \u09F3${fromPaisa(d.amount_paisa).toFixed(2)} was rejected. Reason: ${adminNote}`,
        link: "/dashboard/deposit"
      });
      return d;
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "deposit_rejected",
      entityType: "deposit",
      entityId: id,
      newValues: { trx_id: dep.transaction_id, admin_note: adminNote }
    });
    res.json({ success: true, message: "Deposit rejected." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.get("/withdrawals", requirePermission("withdrawals"), async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 25));
    const offset = (page - 1) * limit;
    const where = ["1=1"];
    const params = [];
    const status = sanitizeText(req.query.status, 32);
    if (status && status !== "all") {
      where.push("w.status = ?");
      params.push(status);
    }
    const method = sanitizeText(req.query.payment_method || req.query.method, 64);
    if (method && method !== "all") {
      where.push("w.payment_method = ?");
      params.push(method);
    }
    const search = sanitizeText(req.query.search, 120);
    if (search) {
      where.push("(w.withdrawal_uid LIKE ? OR w.account_number LIKE ? OR w.payout_reference LIKE ? OR u.username LIKE ? OR u.uid LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like, like, like);
    }
    const whereSql = where.join(" AND ");
    const [countRows, rows] = await Promise.all([
      query(
        `SELECT COUNT(*) AS cnt FROM withdrawals w INNER JOIN users u ON u.id = w.user_id WHERE ${whereSql}`,
        params
      ),
      query(
        `SELECT w.*, u.full_name, u.username, u.uid AS user_uid, u.email
         FROM withdrawals w
         INNER JOIN users u ON u.id = w.user_id
         WHERE ${whereSql}
         ORDER BY w.created_at DESC
         LIMIT ${limit} OFFSET ${offset}`,
        params
      )
    ]);
    const total = Number(countRows[0]?.cnt || 0);
    res.json({
      success: true,
      data: {
        items: rows.map(mapWithdrawal),
        pagination: { page, limit, total, total_pages: Math.max(1, Math.ceil(total / limit)) }
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/withdrawals/:id/approve", requirePermission("withdrawals"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const targetStatus = req.body?.status === "processing" ? "processing" : "approved";
    const adminNote = sanitizeText(
      req.body?.admin_note || (targetStatus === "processing" ? "Withdrawal in processing" : "Approved for payout"),
      500
    );
    const allowedFrom = targetStatus === "processing" ? "('pending')" : "('pending', 'processing')";
    const result = await execute(
      `UPDATE withdrawals SET status = ?, admin_note = ?, reviewed_by = ?, reviewed_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP()
       WHERE id = ? AND status IN ${allowedFrom}`,
      [targetStatus, adminNote, req.admin.id, id]
    );
    if (result.affectedRows === 0) {
      res.status(400).json({ success: false, message: "Withdrawal cannot transition to this status from its current state." });
      return;
    }
    res.json({
      success: true,
      message: targetStatus === "processing" ? "Withdrawal marked as processing." : "Withdrawal approved and ready for payout."
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/withdrawals/:id/paid", requirePermission("withdrawals"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const payoutRef = sanitizeText(req.body?.payout_tx_id || req.body?.payout_reference || req.body?.transaction_id || "", 128);
    const adminNote = sanitizeText(req.body?.admin_note || "Payout settled", 500);
    const paidAmountInput = req.body?.paid_amount !== void 0 && req.body?.paid_amount !== "" ? Number(req.body.paid_amount) : null;
    const paymentDateRaw = sanitizeText(req.body?.payment_date || "", 20);
    const paymentDate = /^\d{4}-\d{2}-\d{2}$/.test(paymentDateRaw) ? paymentDateRaw : (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const wd = await withTransaction(async (conn) => {
      const [wdRows] = await conn.execute("SELECT * FROM withdrawals WHERE id = ? FOR UPDATE", [id]);
      if (!wdRows.length) throw Object.assign(new Error("Withdrawal not found."), { status: 404 });
      const w = wdRows[0];
      if (!["pending", "processing", "approved"].includes(w.status)) {
        throw Object.assign(new Error("This withdrawal has already been finalized."), { status: 400 });
      }
      const [walletRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
        w.user_id
      ]);
      const wallet = walletRows[0];
      const amt = Number(w.amount_paisa);
      const paidPaisa = paidAmountInput !== null && Number.isFinite(paidAmountInput) && paidAmountInput > 0 ? toPaisa(paidAmountInput) : Number(w.net_amount_paisa);
      const lockedAfter = Math.max(0, Number(wallet.locked_balance_paisa) - amt);
      const withdrawnAfter = Number(wallet.total_withdrawn_paisa) + paidPaisa;
      await conn.execute(
        `UPDATE wallets SET locked_balance_paisa = ?, total_withdrawn_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
        [lockedAfter, withdrawnAfter, w.user_id]
      );
      await conn.execute(
        `UPDATE withdrawals
         SET status = 'paid', paid_amount_paisa = ?, payout_reference = ?, admin_note = ?, reviewed_by = ?,
             reviewed_at = COALESCE(reviewed_at, UTC_TIMESTAMP()), paid_at = UTC_TIMESTAMP(), payment_date = ?, updated_at = UTC_TIMESTAMP()
         WHERE id = ?`,
        [paidPaisa, payoutRef, adminNote, req.admin.id, paymentDate, id]
      );
      await conn.execute(
        `UPDATE wallet_transactions SET status = 'completed' WHERE reference_type = 'withdrawal' AND reference_id = ?`,
        [w.withdrawal_uid]
      );
      await createUserNotification(conn, {
        userId: w.user_id,
        type: "withdrawal",
        title: `Withdrawal Paid: \u09F3${fromPaisa(paidPaisa).toFixed(2)}`,
        message: `Payout sent to ${w.payment_method} ${w.account_number}.${payoutRef ? ` Ref: ${payoutRef}` : ""}`,
        link: "/dashboard/withdraw"
      });
      return w;
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "withdrawal_paid",
      entityType: "withdrawal",
      entityId: id,
      newValues: { net_amount: fromPaisa(wd.net_amount_paisa), payout_reference: payoutRef, payment_date: paymentDate }
    });
    res.json({ success: true, message: "Withdrawal marked as paid." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.post("/withdrawals/:id/reject", requirePermission("withdrawals"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const adminNote = sanitizeText(req.body?.reason || req.body?.admin_note || "Withdrawal rejected and refunded", 500);
    const wd = await withTransaction(async (conn) => {
      const [wdRows] = await conn.execute("SELECT * FROM withdrawals WHERE id = ? FOR UPDATE", [id]);
      if (!wdRows.length) throw Object.assign(new Error("Withdrawal not found."), { status: 404 });
      const w = wdRows[0];
      if (!["pending", "processing", "approved"].includes(w.status)) {
        throw Object.assign(new Error("This withdrawal has already been finalized."), { status: 400 });
      }
      const [walletRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
        w.user_id
      ]);
      const wallet = walletRows[0];
      const amt = Number(w.amount_paisa);
      const balBefore = Number(wallet.balance_paisa);
      const balAfter = balBefore + amt;
      const lockedAfter = Math.max(0, Number(wallet.locked_balance_paisa) - amt);
      await conn.execute(
        `UPDATE wallets SET balance_paisa = ?, locked_balance_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
        [balAfter, lockedAfter, w.user_id]
      );
      await conn.execute(
        `UPDATE withdrawals SET status = 'rejected', admin_note = ?, reviewed_by = ?, reviewed_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP() WHERE id = ?`,
        [adminNote, req.admin.id, id]
      );
      await insertWalletTransaction(conn, {
        userId: w.user_id,
        type: "withdrawal_refund",
        direction: "credit",
        amountPaisa: amt,
        balanceBeforePaisa: balBefore,
        balanceAfterPaisa: balAfter,
        referenceType: "withdrawal",
        referenceId: w.withdrawal_uid,
        paymentMethod: w.payment_method,
        receiverNumber: w.account_number,
        description: `Rejected withdrawal ${w.withdrawal_uid} refunded: ${adminNote}`,
        status: "completed",
        createdByAdminId: req.admin.id
      });
      await createUserNotification(conn, {
        userId: w.user_id,
        type: "withdrawal",
        title: `Withdrawal Rejected & Refunded`,
        message: `Your withdrawal ${w.withdrawal_uid} (\u09F3${fromPaisa(amt).toFixed(2)}) was refunded to your wallet. Reason: ${adminNote}`,
        link: "/dashboard/wallet"
      });
      return w;
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "withdrawal_rejected",
      entityType: "withdrawal",
      entityId: id,
      newValues: { refunded_amount: fromPaisa(wd.amount_paisa), admin_note: adminNote }
    });
    res.json({ success: true, message: "Withdrawal rejected and reserved funds returned to user wallet." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.get("/orders", requirePermission("orders"), async (req, res, next) => {
  try {
    const where = ["1=1"];
    const params = [];
    const status = sanitizeText(req.query.status, 32);
    if (status && status !== "all") {
      where.push("o.status = ?");
      params.push(status);
    }
    const search = sanitizeText(req.query.search, 120);
    if (search) {
      where.push("(o.order_uid LIKE ? OR o.product_name LIKE ? OR u.username LIKE ? OR u.uid LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like, like);
    }
    const rows = await query(
      `SELECT o.*, u.full_name, u.username, u.uid AS user_uid, i.id AS invoice_id, i.invoice_number,
              COALESCE(
                (SELECT c.status FROM commissions c WHERE c.order_id = o.id ORDER BY c.created_at DESC LIMIT 1),
                'none'
              ) AS commission_status
       FROM orders o
       INNER JOIN users u ON u.id = o.user_id
       LEFT JOIN invoices i ON i.order_id = o.id
       WHERE ${where.join(" AND ")}
       ORDER BY o.created_at DESC LIMIT 200`,
      params
    );
    res.json({ success: true, data: rows.map(mapOrder) });
  } catch (err) {
    next(err);
  }
});
router4.post("/orders/:id/status", requirePermission("orders"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const nextStatus = sanitizeText(req.body?.status || req.body?.order_status, 32);
    const adminNote = req.body?.admin_note !== void 0 ? sanitizeText(req.body.admin_note, 500) : null;
    if (!["pending", "processing", "completed", "cancelled", "refunded"].includes(nextStatus)) {
      res.status(400).json({ success: false, message: "Invalid order status." });
      return;
    }
    await withTransaction(async (conn) => {
      const [oRows] = await conn.execute("SELECT * FROM orders WHERE id = ? FOR UPDATE", [id]);
      if (!oRows.length) throw Object.assign(new Error("Order not found."), { status: 404 });
      const ord = oRows[0];
      if ((nextStatus === "refunded" || nextStatus === "cancelled") && ord.status !== "refunded" && ord.status !== "cancelled") {
        const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
          ord.user_id
        ]);
        const wallet = wRows[0];
        const refundAmt = Number(ord.total_amount_paisa);
        const balBefore = Number(wallet.balance_paisa);
        const balAfter = balBefore + refundAmt;
        await conn.execute(
          `UPDATE wallets SET balance_paisa = ?, total_spent_paisa = GREATEST(0, total_spent_paisa - ?), updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
          [balAfter, refundAmt, ord.user_id]
        );
        await insertWalletTransaction(conn, {
          userId: ord.user_id,
          type: "order_refund",
          direction: "credit",
          amountPaisa: refundAmt,
          balanceBeforePaisa: balBefore,
          balanceAfterPaisa: balAfter,
          referenceType: "order",
          referenceId: ord.order_uid,
          description: `Refund for ${nextStatus} order ${ord.order_uid}`,
          status: "completed",
          createdByAdminId: req.admin.id
        });
        await conn.execute(
          `UPDATE invoices SET payment_status = 'refunded', invoice_status = 'void', updated_at = UTC_TIMESTAMP() WHERE order_id = ?`,
          [id]
        );
        const [commRows] = await conn.execute(
          `SELECT * FROM commissions WHERE order_id = ? AND status IN ('pending', 'approved', 'credited') FOR UPDATE`,
          [id]
        );
        for (const c of commRows) {
          const commAmt = Number(c.commission_amount_paisa);
          if (c.status === "credited") {
            const [ewRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
              c.earner_user_id
            ]);
            if (ewRows.length) {
              const eBalBefore = Number(ewRows[0].balance_paisa);
              const eBalAfter = Math.max(0, eBalBefore - commAmt);
              await conn.execute(
                `UPDATE wallets SET balance_paisa = ?, total_commission_paisa = GREATEST(0, total_commission_paisa - ?), updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
                [eBalAfter, commAmt, c.earner_user_id]
              );
              await insertWalletTransaction(conn, {
                userId: c.earner_user_id,
                type: "commission_reversal",
                direction: "debit",
                amountPaisa: commAmt,
                balanceBeforePaisa: eBalBefore,
                balanceAfterPaisa: eBalAfter,
                referenceType: "commission",
                referenceId: c.commission_uid,
                description: `Commission reversed due to ${nextStatus} order ${ord.order_uid}`,
                status: "completed",
                createdByAdminId: req.admin.id
              });
            }
          }
          await conn.execute(`UPDATE commissions SET status = 'reversed', updated_at = UTC_TIMESTAMP() WHERE id = ?`, [
            c.id
          ]);
        }
      }
      if (adminNote !== null) {
        await conn.execute("UPDATE orders SET status = ?, notes = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?", [
          nextStatus,
          adminNote,
          id
        ]);
      } else {
        await conn.execute("UPDATE orders SET status = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?", [nextStatus, id]);
      }
    });
    res.json({ success: true, message: `Order status updated to ${nextStatus}.` });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.get("/commissions", requirePermission("commissions"), async (req, res, next) => {
  try {
    const where = ["1=1"];
    const params = [];
    const status = sanitizeText(req.query.status, 32);
    if (status && status !== "all") {
      where.push("c.status = ?");
      params.push(status);
    }
    const rows = await query(
      `SELECT c.*, o.order_uid,
              eu.full_name AS earner_name, eu.username AS earner_username,
              su.full_name AS source_name, su.username AS source_username
       FROM commissions c
       LEFT JOIN orders o ON o.id = c.order_id
       LEFT JOIN users eu ON eu.id = c.earner_user_id
       LEFT JOIN users su ON su.id = c.source_user_id
       WHERE ${where.join(" AND ")}
       ORDER BY c.created_at DESC LIMIT 250`,
      params
    );
    res.json({ success: true, data: rows.map(mapCommission) });
  } catch (err) {
    next(err);
  }
});
router4.post("/commissions/:id/action", requirePermission("commissions"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const action = sanitizeText(req.body?.action, 32);
    await withTransaction(async (conn) => {
      const [cRows] = await conn.execute("SELECT * FROM commissions WHERE id = ? FOR UPDATE", [id]);
      if (!cRows.length) throw Object.assign(new Error("Commission record not found."), { status: 404 });
      const c = cRows[0];
      const amt = Number(c.commission_amount_paisa);
      if ((action === "credit" || action === "approve") && c.status !== "credited") {
        const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
          c.earner_user_id
        ]);
        const wallet = wRows[0];
        const balBefore = Number(wallet.balance_paisa);
        const balAfter = balBefore + amt;
        await conn.execute(
          `UPDATE wallets SET balance_paisa = ?, total_commission_paisa = total_commission_paisa + ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
          [balAfter, amt, c.earner_user_id]
        );
        await conn.execute(
          `UPDATE commissions SET status = 'credited', credited_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP() WHERE id = ?`,
          [id]
        );
        await insertWalletTransaction(conn, {
          userId: c.earner_user_id,
          type: "referral_commission",
          direction: "credit",
          amountPaisa: amt,
          balanceBeforePaisa: balBefore,
          balanceAfterPaisa: balAfter,
          referenceType: "commission",
          referenceId: c.commission_uid,
          description: `Commission ${c.commission_uid} approved & credited`,
          status: "completed",
          createdByAdminId: req.admin.id
        });
      } else if (action === "reverse" || action === "cancel") {
        if (c.status === "credited") {
          const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
            c.earner_user_id
          ]);
          const wallet = wRows[0];
          const balBefore = Number(wallet.balance_paisa);
          const balAfter = Math.max(0, balBefore - amt);
          await conn.execute(
            `UPDATE wallets SET balance_paisa = ?, total_commission_paisa = GREATEST(0, total_commission_paisa - ?), updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
            [balAfter, amt, c.earner_user_id]
          );
          await insertWalletTransaction(conn, {
            userId: c.earner_user_id,
            type: "commission_reversal",
            direction: "debit",
            amountPaisa: amt,
            balanceBeforePaisa: balBefore,
            balanceAfterPaisa: balAfter,
            referenceType: "commission",
            referenceId: c.commission_uid,
            description: `Commission ${c.commission_uid} reversed by admin`,
            status: "completed",
            createdByAdminId: req.admin.id
          });
        }
        await conn.execute(
          `UPDATE commissions SET status = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?`,
          [action === "cancel" ? "cancelled" : "reversed", id]
        );
      } else {
        throw Object.assign(new Error("Unsupported commission action."), { status: 400 });
      }
    });
    res.json({ success: true, message: "Commission updated successfully." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.put("/commissions/:id", requirePermission("commissions"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const newAmt = Number(req.body?.commission_amount ?? req.body?.amount);
    const note = sanitizeText(req.body?.admin_note || req.body?.note || "", 400);
    if (!Number.isFinite(newAmt) || newAmt < 0) {
      res.status(400).json({ success: false, message: "Valid commission amount is required." });
      return;
    }
    const newPaisa = toPaisa(newAmt);
    await withTransaction(async (conn) => {
      const [cRows] = await conn.execute("SELECT * FROM commissions WHERE id = ? FOR UPDATE", [id]);
      if (!cRows.length) throw Object.assign(new Error("Commission not found."), { status: 404 });
      const c = cRows[0];
      const delta = newPaisa - Number(c.commission_amount_paisa);
      await conn.execute(
        `UPDATE commissions SET commission_amount_paisa = ?, note = COALESCE(NULLIF(?, ''), note), updated_at = UTC_TIMESTAMP() WHERE id = ?`,
        [newPaisa, note, id]
      );
      if (c.status === "credited" && delta !== 0) {
        const [wRows] = await conn.execute("SELECT * FROM wallets WHERE user_id = ? FOR UPDATE", [
          c.earner_user_id
        ]);
        const wallet = wRows[0];
        const balBefore = Number(wallet.balance_paisa);
        const balAfter = Math.max(0, balBefore + delta);
        const nextTotalComm = Math.max(0, Number(wallet.total_commission_paisa) + delta);
        await conn.execute(
          `UPDATE wallets SET balance_paisa = ?, total_commission_paisa = ?, updated_at = UTC_TIMESTAMP() WHERE user_id = ?`,
          [balAfter, nextTotalComm, c.earner_user_id]
        );
        await insertWalletTransaction(conn, {
          userId: c.earner_user_id,
          type: "admin_commission_adjustment",
          direction: delta >= 0 ? "credit" : "debit",
          amountPaisa: Math.abs(delta),
          balanceBeforePaisa: balBefore,
          balanceAfterPaisa: balAfter,
          referenceType: "commission",
          referenceId: c.commission_uid,
          description: note || `Admin edited commission ${c.commission_uid}`,
          status: "completed",
          createdByAdminId: req.admin.id
        });
      }
    });
    res.json({ success: true, message: "Commission amount updated." });
  } catch (err) {
    if (err?.status) {
      res.status(err.status).json({ success: false, message: err.message });
      return;
    }
    next(err);
  }
});
router4.get("/referrals", requirePermission("referrals"), async (_req, res, next) => {
  try {
    const rows = await query(
      `SELECT r.*,
              ru.full_name AS referrer_name, ru.username AS referrer_username, ru.uid AS referrer_uid, ru.referral_code AS referral_code,
              tu.full_name AS referred_name, tu.username AS referred_username, tu.uid AS referred_uid, tu.status AS referred_status,
              (SELECT COUNT(*) FROM orders o WHERE o.user_id = tu.id AND o.status = 'completed') AS completed_orders
       FROM referrals r
       INNER JOIN users ru ON ru.id = r.referrer_user_id
       INNER JOIN users tu ON tu.id = r.referred_user_id
       ORDER BY r.created_at DESC LIMIT 250`
    );
    res.json({
      success: true,
      data: rows.map((r) => ({
        id: r.id,
        level: Number(r.level),
        referral_code: r.referral_code,
        referrer_name: r.referrer_name,
        referrer_username: r.referrer_username,
        referrer_uid: r.referrer_uid,
        referred_name: r.referred_name,
        referred_username: r.referred_username,
        referred_uid: r.referred_uid,
        completed_orders: Number(r.completed_orders || 0),
        status: r.referred_status,
        referred_status: r.referred_status,
        created_at: toIso(r.created_at)
      }))
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/transactions", requirePermission("transactions"), async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 25));
    const offset = (page - 1) * limit;
    const where = ["1=1"];
    const params = [];
    const search = sanitizeText(req.query.search, 120);
    if (search) {
      where.push("(t.tx_uid LIKE ? OR t.reference_id LIKE ? OR t.description LIKE ? OR u.username LIKE ? OR u.uid LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like, like, like);
    }
    const type = sanitizeText(req.query.type, 64);
    if (type && type !== "all") {
      where.push("t.type = ?");
      params.push(type);
    }
    const status = sanitizeText(req.query.status, 32);
    if (status && status !== "all") {
      where.push("t.status = ?");
      params.push(status);
    }
    const dateFrom = sanitizeText(req.query.date_from, 20);
    if (dateFrom) {
      where.push("DATE(t.created_at) >= ?");
      params.push(dateFrom);
    }
    const dateTo = sanitizeText(req.query.date_to, 20);
    if (dateTo) {
      where.push("DATE(t.created_at) <= ?");
      params.push(dateTo);
    }
    const whereSql = where.join(" AND ");
    const [countRows, rows] = await Promise.all([
      query(
        `SELECT COUNT(*) AS cnt FROM wallet_transactions t INNER JOIN users u ON u.id = t.user_id WHERE ${whereSql}`,
        params
      ),
      query(
        `SELECT t.*, u.full_name, u.username, u.uid AS user_uid
         FROM wallet_transactions t
         INNER JOIN users u ON u.id = t.user_id
         WHERE ${whereSql}
         ORDER BY t.created_at DESC
         LIMIT ${limit} OFFSET ${offset}`,
        params
      )
    ]);
    const total = Number(countRows[0]?.cnt || 0);
    res.json({
      success: true,
      data: {
        items: rows.map(mapTransaction),
        pagination: { page, limit, total, total_pages: Math.max(1, Math.ceil(total / limit)) }
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/wallets", requirePermission("wallets"), async (_req, res, next) => {
  try {
    const [rows, aggRows, commAggRows] = await Promise.all([
      query(
        `SELECT w.*, u.uid, u.full_name, u.username, u.email, u.status
         FROM wallets w
         INNER JOIN users u ON u.id = w.user_id
         ORDER BY w.balance_paisa DESC LIMIT 250`
      ),
      query(
        `SELECT
           COALESCE(SUM(balance_paisa), 0) AS total_available,
           COALESCE(SUM(locked_balance_paisa), 0) AS total_pending_withdrawal,
           COALESCE(SUM(total_deposited_paisa), 0) AS total_deposits
         FROM wallets`
      ),
      query(
        `SELECT COALESCE(SUM(commission_amount_paisa), 0) AS total_pending_commission
         FROM commissions WHERE status IN ('pending','approved')`
      )
    ]);
    res.json({
      success: true,
      data: {
        totals: {
          total_available: fromPaisa(aggRows[0]?.total_available),
          total_pending_withdrawal: fromPaisa(aggRows[0]?.total_pending_withdrawal),
          total_pending_commission: fromPaisa(commAggRows[0]?.total_pending_commission),
          total_deposits: fromPaisa(aggRows[0]?.total_deposits)
        },
        items: rows.map((r) => ({
          ...mapWallet(r),
          id: r.user_id,
          uid: r.uid,
          user_uid: r.uid,
          full_name: r.full_name,
          username: r.username,
          email: r.email,
          status: r.status
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/payment-settings", requirePermission("payment_settings"), async (_req, res, next) => {
  try {
    const rows = await query("SELECT * FROM payment_settings ORDER BY display_order ASC, created_at ASC");
    res.json({ success: true, data: rows.map(mapPaymentSetting) });
  } catch (err) {
    next(err);
  }
});
router4.post("/payment-settings", requirePermission("payment_settings"), async (req, res, next) => {
  try {
    const id = genId("pay");
    const methodType = sanitizeText(req.body?.method_name || req.body?.method_type, 64);
    const accountTitle = sanitizeText(req.body?.account_holder_name || req.body?.account_title, 160);
    const accountNumber = sanitizeText(req.body?.receiving_number || req.body?.account_number, 64);
    const accountType = sanitizeText(req.body?.account_type || "personal", 32);
    const bankName = sanitizeText(req.body?.bank_name, 160);
    const branchName = sanitizeText(req.body?.branch_name, 160);
    const routingNumber = sanitizeText(req.body?.routing_number, 64);
    const instructions = sanitizeText(req.body?.instructions, 1e3);
    const minDep = toPaisa(Number(req.body?.min_deposit || 100));
    const maxDep = toPaisa(Number(req.body?.max_deposit || 5e5));
    const isActive = (req.body?.deposit_enabled ?? req.body?.is_active) !== false ? 1 : 0;
    const withdrawalEnabled = req.body?.withdrawal_enabled !== false ? 1 : 0;
    const displayOrder = Number(req.body?.display_order || 0);
    if (!methodType || !accountTitle || !accountNumber) {
      res.status(400).json({ success: false, message: "Method type, title, and account number are required." });
      return;
    }
    await execute(
      `INSERT INTO payment_settings
         (id, method_type, account_title, account_number, account_type, bank_name, branch_name, routing_number,
          instructions, min_deposit_paisa, max_deposit_paisa, is_active, withdrawal_enabled, display_order, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
      [
        id,
        methodType,
        accountTitle,
        accountNumber,
        accountType,
        bankName || null,
        branchName || null,
        routingNumber || null,
        instructions,
        minDep,
        maxDep,
        isActive,
        withdrawalEnabled,
        displayOrder
      ]
    );
    const rows = await query("SELECT * FROM payment_settings WHERE id = ?", [id]);
    res.status(201).json({ success: true, message: "Receiving payment channel added.", data: mapPaymentSetting(rows[0]) });
  } catch (err) {
    next(err);
  }
});
router4.put("/payment-settings/:id", requirePermission("payment_settings"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const existing = await query("SELECT * FROM payment_settings WHERE id = ? LIMIT 1", [id]);
    if (!existing.length) {
      res.status(404).json({ success: false, message: "Payment channel not found." });
      return;
    }
    const cur = existing[0];
    const depFlag = req.body?.deposit_enabled ?? req.body?.is_active;
    await execute(
      `UPDATE payment_settings
       SET method_type = ?, account_title = ?, account_number = ?, account_type = ?,
           bank_name = ?, branch_name = ?, routing_number = ?, instructions = ?,
           min_deposit_paisa = ?, max_deposit_paisa = ?, is_active = ?, withdrawal_enabled = ?, display_order = ?, updated_at = UTC_TIMESTAMP()
       WHERE id = ?`,
      [
        sanitizeText(req.body?.method_name ?? req.body?.method_type ?? cur.method_type, 64),
        sanitizeText(req.body?.account_holder_name ?? req.body?.account_title ?? cur.account_title, 160),
        sanitizeText(req.body?.receiving_number ?? req.body?.account_number ?? cur.account_number, 64),
        sanitizeText(req.body?.account_type ?? cur.account_type, 32),
        sanitizeText(req.body?.bank_name ?? cur.bank_name, 160) || null,
        sanitizeText(req.body?.branch_name ?? cur.branch_name, 160) || null,
        sanitizeText(req.body?.routing_number ?? cur.routing_number, 64) || null,
        sanitizeText(req.body?.instructions ?? cur.instructions, 1e3),
        req.body?.min_deposit !== void 0 ? toPaisa(req.body.min_deposit) : Number(cur.min_deposit_paisa),
        req.body?.max_deposit !== void 0 ? toPaisa(req.body.max_deposit) : Number(cur.max_deposit_paisa),
        depFlag !== void 0 ? depFlag ? 1 : 0 : Number(cur.is_active),
        req.body?.withdrawal_enabled !== void 0 ? req.body.withdrawal_enabled ? 1 : 0 : Number(cur.withdrawal_enabled ?? 1),
        req.body?.display_order !== void 0 ? Number(req.body.display_order) : Number(cur.display_order),
        id
      ]
    );
    res.json({ success: true, message: "Payment channel updated." });
  } catch (err) {
    next(err);
  }
});
router4.delete("/payment-settings/:id", requirePermission("payment_settings"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    await execute("DELETE FROM payment_settings WHERE id = ?", [id]);
    res.json({ success: true, message: "Payment channel deleted." });
  } catch (err) {
    next(err);
  }
});
router4.get("/payment-methods", requirePermission("payment_settings"), async (_req, res, next) => {
  try {
    const rows = await query(
      `SELECT pm.*, u.full_name, u.username, u.uid AS user_uid
       FROM payment_methods pm
       INNER JOIN users u ON u.id = pm.user_id
       WHERE pm.status != 'deleted'
       ORDER BY pm.created_at DESC LIMIT 250`
    );
    res.json({ success: true, data: rows.map(mapPaymentMethod) });
  } catch (err) {
    next(err);
  }
});
router4.get("/invoices", requirePermission("invoices"), async (req, res, next) => {
  try {
    const where = ["1=1"];
    const params = [];
    const search = sanitizeText(req.query.search, 120);
    if (search) {
      where.push("(i.invoice_number LIKE ? OR i.customer_name LIKE ? OR u.uid LIKE ? OR o.order_uid LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like, like);
    }
    const rows = await query(
      `SELECT i.*, u.uid AS customer_uid, o.order_uid, o.payment_source AS payment_method
       FROM invoices i
       INNER JOIN users u ON u.id = i.user_id
       LEFT JOIN orders o ON o.id = i.order_id
       WHERE ${where.join(" AND ")}
       ORDER BY i.issued_at DESC LIMIT 200`,
      params
    );
    res.json({ success: true, data: rows.map(mapInvoice) });
  } catch (err) {
    next(err);
  }
});
router4.get("/invoices/:id", requirePermission("invoices"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const rows = await query(
      `SELECT i.*, u.uid AS customer_uid, o.order_uid, o.payment_source AS payment_method
       FROM invoices i
       INNER JOIN users u ON u.id = i.user_id
       LEFT JOIN orders o ON o.id = i.order_id
       WHERE i.id = ? LIMIT 1`,
      [id]
    );
    if (!rows.length) {
      res.status(404).json({ success: false, message: "Invoice not found." });
      return;
    }
    const mapped = mapInvoice(rows[0]);
    res.json({ success: true, data: { invoice: mapped, items: mapped.items } });
  } catch (err) {
    next(err);
  }
});
router4.put("/invoices/:id", requirePermission("invoices"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const invStatusRaw = sanitizeText(req.body?.invoice_status || "", 32).toLowerCase();
    const payStatusRaw = sanitizeText(req.body?.payment_status || "", 32).toLowerCase();
    const dueDateRaw = sanitizeText(req.body?.due_date || "", 20);
    const dueDate = /^\d{4}-\d{2}-\d{2}$/.test(dueDateRaw) ? dueDateRaw : null;
    const notes = sanitizeText(req.body?.notes, 1e3);
    const mappedPaymentStatus = payStatusRaw && ["paid", "unpaid", "refunded"].includes(payStatusRaw) ? payStatusRaw : invStatusRaw === "void" ? "refunded" : invStatusRaw === "draft" || invStatusRaw === "issued" ? "unpaid" : invStatusRaw === "paid" ? "paid" : "";
    const mappedInvoiceStatus = ["draft", "issued", "paid", "void"].includes(invStatusRaw) ? invStatusRaw : "";
    await execute(
      `UPDATE invoices
       SET payment_status = IF(? != '', ?, payment_status),
           invoice_status = IF(? != '', ?, invoice_status),
           due_date = COALESCE(?, due_date),
           notes = ?,
           updated_at = UTC_TIMESTAMP()
       WHERE id = ?`,
      [mappedPaymentStatus, mappedPaymentStatus, mappedInvoiceStatus, mappedInvoiceStatus, dueDate, notes, id]
    );
    res.json({ success: true, message: "Invoice updated." });
  } catch (err) {
    next(err);
  }
});
router4.get("/reports", requirePermission("reports"), async (req, res, next) => {
  try {
    const period = sanitizeText(req.query.period || "all", 24);
    const dateFrom = sanitizeText(req.query.date_from, 20);
    const dateTo = sanitizeText(req.query.date_to, 20);
    let dateCond = "1=1";
    const dateParams = [];
    if (period === "daily") {
      dateCond = "DATE(created_at) = UTC_DATE()";
    } else if (period === "weekly") {
      dateCond = "created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)";
    } else if (period === "monthly") {
      dateCond = "created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY)";
    } else if (period === "yearly") {
      dateCond = "created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 365 DAY)";
    } else if (period === "custom" && dateFrom && dateTo) {
      dateCond = "DATE(created_at) BETWEEN ? AND ?";
      dateParams.push(dateFrom, dateTo);
    }
    const [depSum, wdSum, ordSum, commSum, walletLiab, senderRows, receiverRows] = await Promise.all([
      query(
        `SELECT
           COALESCE(SUM(amount_paisa), 0) AS total_dep,
           COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_paisa ELSE 0 END), 0) AS approved_dep,
           COALESCE(SUM(CASE WHEN status IN ('pending','processing') THEN amount_paisa ELSE 0 END), 0) AS pending_dep,
           COALESCE(SUM(CASE WHEN status = 'rejected' THEN amount_paisa ELSE 0 END), 0) AS rejected_dep
         FROM deposits WHERE ${dateCond}`,
        dateParams
      ),
      query(
        `SELECT
           COALESCE(SUM(amount_paisa), 0) AS total_wd,
           COALESCE(SUM(CASE WHEN status = 'paid' THEN net_amount_paisa ELSE 0 END), 0) AS paid_wd,
           COALESCE(SUM(CASE WHEN status = 'paid' THEN fee_paisa ELSE 0 END), 0) AS wd_fees
         FROM withdrawals WHERE ${dateCond}`,
        dateParams
      ),
      query(
        `SELECT
           COUNT(CASE WHEN status = 'completed' THEN 1 END) AS total_orders,
           COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount_paisa ELSE 0 END), 0) AS order_vol,
           COALESCE(SUM(CASE WHEN status = 'refunded' THEN total_amount_paisa ELSE 0 END), 0) AS refunds
         FROM orders WHERE ${dateCond}`,
        dateParams
      ),
      query(
        `SELECT
           COALESCE(SUM(commission_amount_paisa), 0) AS total_comm,
           COALESCE(SUM(CASE WHEN status = 'credited' THEN commission_amount_paisa ELSE 0 END), 0) AS paid_comm,
           COALESCE(SUM(CASE WHEN status IN ('pending','approved') THEN commission_amount_paisa ELSE 0 END), 0) AS uncredited_comm
         FROM commissions WHERE ${dateCond}`,
        dateParams
      ),
      query(
        `SELECT
           COALESCE(SUM(balance_paisa), 0) AS wallet_liab,
           COALESCE(SUM(locked_balance_paisa), 0) AS pending_liab
         FROM wallets`
      ),
      query(
        `SELECT
           sender_number,
           COUNT(*) AS total_requests,
           SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_count,
           SUM(CASE WHEN status IN ('pending','processing') THEN 1 ELSE 0 END) AS pending_count,
           SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_count,
           COALESCE(SUM(amount_paisa), 0) AS total_submitted,
           COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_paisa ELSE 0 END), 0) AS total_approved,
           MIN(created_at) AS first_tx_date,
           MAX(created_at) AS last_tx_date
         FROM deposits
         WHERE ${dateCond}
         GROUP BY sender_number
         ORDER BY total_approved DESC LIMIT 200`,
        dateParams
      ),
      query(
        `SELECT
           receiver_number AS receiving_number,
           payment_method,
           COUNT(*) AS total_deposits,
           SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_deposits,
           SUM(CASE WHEN status IN ('pending','processing') THEN 1 ELSE 0 END) AS pending_deposits,
           SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_deposits,
           COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_paisa ELSE 0 END), 0) AS total_received,
           MIN(created_at) AS first_used,
           MAX(created_at) AS last_used
         FROM deposits
         WHERE ${dateCond}
         GROUP BY receiver_number, payment_method
         ORDER BY total_received DESC LIMIT 200`,
        dateParams
      )
    ]);
    const approvedDep = Number(depSum[0]?.approved_dep || 0);
    const paidWd = Number(wdSum[0]?.paid_wd || 0);
    const orderVol = Number(ordSum[0]?.order_vol || 0);
    const wdFees = Number(wdSum[0]?.wd_fees || 0);
    const paidComm = Number(commSum[0]?.paid_comm || 0);
    res.json({
      success: true,
      data: {
        cash_flow: {
          money_received: fromPaisa(approvedDep),
          money_paid: fromPaisa(paidWd),
          net_cash_flow: fromPaisa(approvedDep - paidWd),
          user_wallet_liabilities: fromPaisa(walletLiab[0]?.wallet_liab),
          pending_liabilities: fromPaisa(walletLiab[0]?.pending_liab),
          commission_liability: fromPaisa(commSum[0]?.uncredited_comm)
        },
        financial_summary: {
          total_deposits: fromPaisa(depSum[0]?.total_dep),
          total_approved_deposits: fromPaisa(approvedDep),
          total_pending_deposits: fromPaisa(depSum[0]?.pending_dep),
          total_rejected_deposits: fromPaisa(depSum[0]?.rejected_dep),
          total_withdrawals: fromPaisa(wdSum[0]?.total_wd),
          total_paid_withdrawals: fromPaisa(paidWd),
          total_orders: Number(ordSum[0]?.total_orders || 0),
          total_order_volume: fromPaisa(orderVol),
          total_refunds: fromPaisa(ordSum[0]?.refunds),
          total_commission: fromPaisa(commSum[0]?.total_comm),
          total_commission_paid: fromPaisa(paidComm),
          total_platform_revenue: fromPaisa(Math.max(0, orderVol + wdFees - paidComm))
        },
        sender_number_report: senderRows.map((r) => ({
          sender_number: r.sender_number,
          total_requests: Number(r.total_requests),
          approved_count: Number(r.approved_count),
          pending_count: Number(r.pending_count),
          rejected_count: Number(r.rejected_count),
          total_submitted: fromPaisa(r.total_submitted),
          total_approved: fromPaisa(r.total_approved),
          first_tx_date: toIso(r.first_tx_date),
          last_tx_date: toIso(r.last_tx_date)
        })),
        receiving_number_report: receiverRows.map((r) => ({
          receiving_number: r.receiving_number,
          payment_method: r.payment_method,
          total_deposits: Number(r.total_deposits),
          approved_deposits: Number(r.approved_deposits),
          pending_deposits: Number(r.pending_deposits),
          rejected_deposits: Number(r.rejected_deposits),
          total_received: fromPaisa(r.total_received),
          first_used: toIso(r.first_used),
          last_used: toIso(r.last_used)
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/reports/payment-search", requirePermission("reports"), async (req, res, next) => {
  try {
    const q = sanitizeText(req.query.q, 120);
    const sender = sanitizeText(req.query.sender, 64);
    const receiver = sanitizeText(req.query.receiver, 64);
    if (sender) {
      const deps2 = await query(
        `SELECT d.*, u.full_name, u.username, u.uid AS user_uid
         FROM deposits d INNER JOIN users u ON u.id = d.user_id
         WHERE d.sender_number = ? ORDER BY d.created_at DESC LIMIT 200`,
        [sender]
      );
      res.json({ success: true, data: { deposits: deps2.map(mapDeposit), transactions: [] } });
      return;
    }
    if (receiver) {
      const deps2 = await query(
        `SELECT d.*, u.full_name, u.username, u.uid AS user_uid
         FROM deposits d INNER JOIN users u ON u.id = d.user_id
         WHERE d.receiver_number = ? ORDER BY d.created_at DESC LIMIT 200`,
        [receiver]
      );
      res.json({ success: true, data: { deposits: deps2.map(mapDeposit), transactions: [] } });
      return;
    }
    const like = `%${q}%`;
    const [deps, txs] = await Promise.all([
      query(
        `SELECT d.*, u.full_name, u.username, u.uid AS user_uid
         FROM deposits d INNER JOIN users u ON u.id = d.user_id
         WHERE d.transaction_id LIKE ? OR d.sender_number LIKE ? OR d.receiver_number LIKE ?
            OR d.deposit_uid LIKE ? OR u.username LIKE ? OR u.uid LIKE ?
         ORDER BY d.created_at DESC LIMIT 100`,
        [like, like, like, like, like, like]
      ),
      query(
        `SELECT t.*, u.full_name, u.username, u.uid AS user_uid
         FROM wallet_transactions t INNER JOIN users u ON u.id = t.user_id
         WHERE t.tx_uid LIKE ? OR t.reference_id LIKE ? OR t.sender_number LIKE ?
            OR t.receiver_number LIKE ? OR u.username LIKE ? OR u.uid LIKE ?
         ORDER BY t.created_at DESC LIMIT 100`,
        [like, like, like, like, like, like]
      )
    ]);
    res.json({
      success: true,
      data: {
        deposits: deps.map(mapDeposit),
        transactions: txs.map(mapTransaction)
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/notifications", requirePermission("notifications"), async (_req, res, next) => {
  try {
    const rows = await query(
      "SELECT * FROM admin_notifications ORDER BY created_at DESC LIMIT 100"
    );
    res.json({
      success: true,
      data: rows.map((n) => ({
        id: n.id,
        type: n.type,
        title: n.title,
        message: n.message,
        link: n.link || null,
        is_read: Boolean(n.is_read),
        created_at: toIso(n.created_at)
      }))
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/notifications/read", requirePermission("notifications"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.body?.id, 128);
    if (id) {
      await execute("UPDATE admin_notifications SET is_read = 1 WHERE id = ?", [id]);
    } else {
      await execute("UPDATE admin_notifications SET is_read = 1");
    }
    res.json({ success: true, message: "Admin notifications marked as read." });
  } catch (err) {
    next(err);
  }
});
router4.post("/notifications/broadcast", requirePermission("notifications"), async (req, res, next) => {
  try {
    const title = sanitizeText(req.body?.title, 200);
    const message = sanitizeText(req.body?.message, 2e3);
    const targetUserId = sanitizeText(req.body?.user_id, 128);
    if (!title || !message) {
      res.status(400).json({ success: false, message: "Title and message are required." });
      return;
    }
    if (targetUserId) {
      await createUserNotification(null, { userId: targetUserId, type: "announcement", title, message });
    } else {
      const users = await query(`SELECT id FROM users WHERE status = 'active'`);
      for (const u of users) {
        await createUserNotification(null, { userId: u.id, type: "announcement", title, message });
      }
    }
    res.json({ success: true, message: "Announcement dispatched successfully." });
  } catch (err) {
    next(err);
  }
});
router4.get("/support", requirePermission("support"), async (_req, res, next) => {
  try {
    const tickets = await query(
      `SELECT t.*, u.full_name, u.username, u.uid AS user_uid, u.email
       FROM support_tickets t
       INNER JOIN users u ON u.id = t.user_id
       ORDER BY t.updated_at DESC LIMIT 200`
    );
    res.json({
      success: true,
      data: tickets.map((t) => ({
        ...t,
        user_name: t.full_name,
        user_email: t.email,
        internal_note: t.internal_note || "",
        created_at: toIso(t.created_at),
        updated_at: toIso(t.updated_at)
      }))
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/support/contacts", requirePermission("support"), async (_req, res, next) => {
  try {
    const contacts = await query("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 100");
    res.json({
      success: true,
      data: contacts.map((c) => ({ ...c, created_at: toIso(c.created_at) }))
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/support/:id", requirePermission("support"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const tickets = await query(
      `SELECT t.*, u.full_name, u.username, u.uid AS user_uid, u.email
       FROM support_tickets t INNER JOIN users u ON u.id = t.user_id
       WHERE t.id = ? LIMIT 1`,
      [id]
    );
    if (!tickets.length) {
      res.status(404).json({ success: false, message: "Ticket not found." });
      return;
    }
    const msgs = await query(
      "SELECT * FROM support_messages WHERE ticket_id = ? ORDER BY created_at ASC",
      [id]
    );
    res.json({
      success: true,
      data: {
        ticket: {
          ...tickets[0],
          user_name: tickets[0].full_name,
          user_email: tickets[0].email,
          internal_note: tickets[0].internal_note || "",
          created_at: toIso(tickets[0].created_at),
          updated_at: toIso(tickets[0].updated_at)
        },
        messages: msgs.map((m) => ({ ...m, created_at: toIso(m.created_at) }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/support/:id/reply", requirePermission("support"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    const message = sanitizeText(req.body?.message, 3e3);
    const status = sanitizeText(req.body?.status, 32);
    const internalNote = req.body?.internal_note !== void 0 ? sanitizeText(req.body.internal_note, 2e3) : null;
    const tickets = await query("SELECT * FROM support_tickets WHERE id = ? LIMIT 1", [id]);
    if (!tickets.length) {
      res.status(404).json({ success: false, message: "Ticket not found." });
      return;
    }
    const ticket = tickets[0];
    if (message) {
      await execute(
        `INSERT INTO support_messages (id, ticket_id, sender_type, sender_id, sender_name, message, created_at)
         VALUES (?, ?, 'admin', ?, ?, ?, UTC_TIMESTAMP())`,
        [genId("smsg"), id, req.admin.id, req.admin.full_name, message]
      );
      await createUserNotification(null, {
        userId: ticket.user_id,
        type: "support",
        title: `Support Reply: ${ticket.ticket_uid}`,
        message: `GO PAY BD Support replied to "${ticket.subject}".`,
        link: "/dashboard/support"
      });
    }
    const nextStatus = ["open", "in_progress", "answered", "resolved", "closed"].includes(status) ? status : message ? "answered" : "in_progress";
    await execute(
      "UPDATE support_tickets SET status = ?, internal_note = COALESCE(?, internal_note), assigned_admin_id = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?",
      [nextStatus, internalNote, req.admin.id, id]
    );
    res.json({ success: true, message: "Support ticket updated." });
  } catch (err) {
    next(err);
  }
});
router4.get("/staff", requirePermission("staff"), async (_req, res, next) => {
  try {
    const [roles, staff] = await Promise.all([
      query("SELECT * FROM admin_roles ORDER BY id ASC"),
      query(
        `SELECT a.id, a.admin_uid, a.full_name, a.email, a.role_id, a.status, a.last_login_at, a.created_at,
                r.name AS role_name, r.slug AS role_slug
         FROM admins a
         INNER JOIN admin_roles r ON r.id = a.role_id
         ORDER BY a.created_at ASC`
      )
    ]);
    res.json({
      success: true,
      data: {
        roles: roles.map((r) => ({
          id: Number(r.id),
          slug: r.slug,
          name: r.name,
          description: r.description,
          permissions: parsePermissions(r.permissions_json)
        })),
        staff: staff.map((s) => ({
          id: s.id,
          admin_uid: s.admin_uid,
          full_name: s.full_name,
          email: s.email,
          role_id: Number(s.role_id),
          role_name: s.role_name,
          role_slug: s.role_slug,
          status: s.status,
          last_login_at: toIso(s.last_login_at),
          created_at: toIso(s.created_at)
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.post("/staff", requirePermission("staff"), async (req, res, next) => {
  try {
    const fullName = sanitizeText(req.body?.full_name, 160);
    const email = sanitizeText(req.body?.email, 190).toLowerCase();
    const password = String(req.body?.password || "");
    const pin = sanitizeText(req.body?.pin, 16);
    const roleId = Number(req.body?.role_id || 2);
    if (!fullName || !isValidEmail(email) || password.length < 8) {
      res.status(400).json({ success: false, message: "Name, valid email, and password (8+ chars) are required." });
      return;
    }
    const pwHash = await hashPassword(password);
    const pinHash = pin ? await hashPassword(pin) : null;
    const id = genId("adm");
    const adminUid = genCode("ADM", 4);
    await execute(
      `INSERT INTO admins (id, admin_uid, full_name, email, password_hash, pin_hash, role_id, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'active', UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
      [id, adminUid, fullName, email, pwHash, pinHash, roleId]
    );
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "staff_created",
      entityType: "admin",
      entityId: id,
      newValues: { full_name: fullName, email, role_id: roleId }
    });
    res.status(201).json({ success: true, message: "Admin staff account created." });
  } catch (err) {
    if (err?.code === "ER_DUP_ENTRY") {
      res.status(409).json({ success: false, message: "A staff account with this email already exists." });
      return;
    }
    next(err);
  }
});
router4.put("/staff/:id", requirePermission("staff"), async (req, res, next) => {
  try {
    const id = sanitizeText(req.params.id, 128);
    if (id === PRIMARY_ADMIN_ID && req.body?.status === "suspended") {
      res.status(400).json({ success: false, message: "Cannot suspend the primary administrator account." });
      return;
    }
    const status = req.body?.status === "suspended" ? "suspended" : "active";
    await execute("UPDATE admins SET status = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?", [status, id]);
    if (status === "suspended") {
      await execute(`DELETE FROM sessions WHERE actor_type = 'admin' AND actor_id = ?`, [id]);
    }
    res.json({ success: true, message: `Staff account ${status}.` });
  } catch (err) {
    next(err);
  }
});
router4.get("/audit-logs", requirePermission("audit"), async (_req, res, next) => {
  try {
    const [auditRows, loginRows] = await Promise.all([
      query("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 200"),
      query("SELECT * FROM login_logs ORDER BY created_at DESC LIMIT 200")
    ]);
    const mappedAudits = auditRows.map((a) => ({
      id: a.id,
      actor_type: a.actor_type,
      actor_name: a.actor_name,
      admin_name: a.actor_name,
      action: a.action,
      entity_type: a.entity_type,
      entity_id: a.entity_id,
      old_values: a.old_values,
      new_values: a.new_values,
      ip_address: a.ip_address,
      created_at: toIso(a.created_at)
    }));
    res.json({
      success: true,
      data: {
        audit_logs: mappedAudits,
        activity_logs: mappedAudits.filter((a) => a.actor_type === "admin"),
        login_logs: loginRows.map((l) => ({
          id: l.id,
          actor_type: l.actor_type,
          identifier: l.identifier,
          success: Boolean(l.success),
          ip_address: l.ip_address,
          created_at: toIso(l.created_at)
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});
router4.get("/settings", requirePermission("settings"), async (_req, res, next) => {
  try {
    const settings = await getPlatformSettings();
    res.json({ success: true, data: settings });
  } catch (err) {
    next(err);
  }
});
router4.put("/settings", requirePermission("settings"), async (req, res, next) => {
  try {
    const incoming = req.body?.settings && typeof req.body.settings === "object" ? req.body.settings : req.body;
    if (!incoming || typeof incoming !== "object") {
      res.status(400).json({ success: false, message: "Settings object is required." });
      return;
    }
    await withTransaction(async (conn) => {
      for (const [key, val] of Object.entries(incoming)) {
        const cleanKey = sanitizeText(key, 120).replace(/[^a-zA-Z0-9_]/g, "");
        if (!cleanKey) continue;
        const cleanVal = sanitizeText(val, 2e3);
        await conn.execute(
          `INSERT INTO platform_settings (setting_key, setting_value, updated_at)
           VALUES (?, ?, UTC_TIMESTAMP())
           ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP()`,
          [cleanKey, cleanVal]
        );
      }
    });
    await recordAuditLog({
      req,
      actorType: "admin",
      actorId: req.admin.id,
      actorName: req.admin.full_name,
      action: "platform_settings_updated",
      entityType: "platform_settings",
      entityId: "global",
      newValues: incoming
    });
    const fresh = await getPlatformSettings();
    res.json({ success: true, message: "Platform settings saved successfully.", data: fresh });
  } catch (err) {
    next(err);
  }
});
var adminRoutes_default = router4;

// server.ts
async function startServer() {
  const app = express();
  app.set("trust proxy", 1);
  app.disable("x-powered-by");
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      frameguard: false
    })
  );
  if (env.isProd && env.allowedOrigins.size === 0) {
    console.warn("[GO PAY BD] Warning: APP_URL / FRONTEND_URL / ALLOWED_ORIGINS not set; cross-origin CORS and Origin checks will reject untrusted origins.");
  }
  app.use(
    cors({
      origin: (origin, cb) => {
        if (!origin) return cb(null, true);
        if (isTrustedOrigin(origin)) {
          return cb(null, true);
        }
        return cb(null, false);
      },
      credentials: true
    })
  );
  app.use(cookieParser());
  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ extended: true, limit: "2mb" }));
  fs3.mkdirSync(env.uploadDir, { recursive: true });
  app.get("/uploads/:subdir/:filename", async (req, res, next) => {
    try {
      const subdir = String(req.params.subdir || "").toLowerCase();
      if (subdir !== "avatars" && subdir !== "deposits" && subdir !== "support") {
        res.status(404).json({ success: false, message: "File not found." });
        return;
      }
      const safePath = resolveSafeUploadPath(subdir, req.params.filename);
      if (!safePath) {
        res.status(404).json({ success: false, message: "File not found." });
        return;
      }
      if (subdir === "avatars") {
        if (!fs3.existsSync(safePath)) {
          res.status(404).json({ success: false, message: "File not found." });
          return;
        }
        res.setHeader("X-Content-Type-Options", "nosniff");
        res.setHeader("Cache-Control", "public, max-age=604800");
        res.sendFile(safePath);
        return;
      }
      const [admin, user] = await Promise.all([
        resolveAdminFromRequest(req, { allowQueryToken: true }),
        resolveUserFromRequest(req, { allowQueryToken: true })
      ]);
      const activeAdmin = admin && admin.status === "active" ? admin : null;
      const activeUser = user && user.status !== "suspended" ? user : null;
      if (!activeAdmin && !activeUser) {
        res.status(401).json({ success: false, message: "Authentication required to view this file." });
        return;
      }
      if (!activeAdmin && activeUser) {
        const publicUrl = `/uploads/${subdir}/${path4.basename(safePath)}`;
        if (subdir === "deposits") {
          const rows = await query(
            `SELECT id FROM deposits WHERE user_id = ? AND screenshot_url = ? LIMIT 1`,
            [activeUser.id, publicUrl]
          );
          if (!rows.length) {
            res.status(403).json({ success: false, message: "Access denied to this deposit receipt." });
            return;
          }
        } else if (subdir === "support") {
          const rows = await query(
            `SELECT sm.id
             FROM support_messages sm
             INNER JOIN support_tickets st ON st.id = sm.ticket_id
             WHERE st.user_id = ? AND sm.attachment_url = ?
             LIMIT 1`,
            [activeUser.id, publicUrl]
          );
          if (!rows.length) {
            res.status(403).json({ success: false, message: "Access denied to this support attachment." });
            return;
          }
        }
      }
      if (!fs3.existsSync(safePath)) {
        res.status(404).json({ success: false, message: "File not found." });
        return;
      }
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Cache-Control", "private, no-store");
      res.sendFile(safePath);
    } catch (err) {
      next(err);
    }
  });
  app.get("/auth/google/callback", handleGoogleOAuthCallback);
  app.get("/auth/google/callback/", handleGoogleOAuthCallback);
  app.use("/api", generalApiLimiter);
  app.use("/api", csrfProtection);
  app.use("/api", publicRoutes_default);
  app.use("/api/auth", authRoutes_default);
  app.use("/api/admin", adminRoutes_default);
  const memberPrefixes = [
    "/dashboard",
    "/wallet",
    "/deposit-methods",
    "/deposits",
    "/payment-methods",
    "/withdrawal-rules",
    "/withdrawals",
    "/referrals",
    "/orders",
    "/invoices",
    "/notifications",
    "/support",
    "/profile"
  ];
  app.use("/api/user", userRoutes_default);
  app.use(
    memberPrefixes.map((p) => `/api${p}`),
    (req, res, next) => {
      req.url = req.baseUrl.replace(/^\/api/, "") + (req.url === "/" ? "" : req.url);
      userRoutes_default(req, res, next);
    }
  );
  app.all("/api/*", (_req, res) => {
    res.status(404).json({
      success: false,
      message: "API endpoint not found."
    });
  });
  app.use((err, _req, res, _next) => {
    if (err instanceof DatabaseUnavailableError || err?.status === 503) {
      res.status(503).json({
        success: false,
        message: err.message || "Database service unavailable."
      });
      return;
    }
    if (err?.name === "MulterError") {
      res.status(400).json({
        success: false,
        message: err.code === "LIMIT_FILE_SIZE" ? "Uploaded file is too large (max 5MB)." : err.message
      });
      return;
    }
    const status = Number(err?.status) || 500;
    if (status >= 500) {
      console.error("[SERVER ERROR]", err?.message || err);
    }
    res.status(status).json({
      success: false,
      message: status >= 500 ? "Internal server error. Please try again." : err.message || "Request failed."
    });
  });
  if (!env.isProd) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path4.resolve(process.cwd(), "dist");
    const indexHtml = path4.join(distDir, "index.html");
    if (fs3.existsSync(distDir)) {
      app.use(express.static(distDir, { index: false, maxAge: "7d" }));
    }
    app.get("*", (_req, res) => {
      if (fs3.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(503).send('Frontend build not found. Run "npm run build" first.');
      }
    });
  }
  const dbInit = await initializeDatabase();
  if (env.isProd && !dbInit.connected) {
    console.error(
      `[GO PAY BD] FATAL STARTUP ERROR: MySQL database is required in production (${dbInit.error || "CONNECTION_FAILED"}). Configure DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD and retry.`
    );
    await closeDatabasePool();
    process.exit(1);
  }
  const server = app.listen(env.port, "0.0.0.0", () => {
    console.log(`[GO PAY BD] Server listening on port ${env.port} (${env.nodeEnv})`);
  });
  const shutdown = async (signal) => {
    console.log(`[GO PAY BD] Received ${signal}. Shutting down cleanly...`);
    server.close(async () => {
      await closeDatabasePool();
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5e3).unref();
  };
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
}
startServer().catch((err) => {
  console.error("[GO PAY BD] Fatal startup error:", err);
  process.exit(1);
});
